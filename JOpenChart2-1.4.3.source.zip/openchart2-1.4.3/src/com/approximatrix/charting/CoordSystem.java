/*
    OpenChart2 Java Charting Library and Toolkit
    Copyright (C) 2005-2007 Approximatrix, LLC
    Copyright (C) 2001  Sebastian M�ller
    http://www.approximatrix.com

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 
    ClassicCoordSystem.java
    Created on 26. Juni 2001, 22:49
 */

package com.approximatrix.charting;


import java.text.DecimalFormat;

import com.approximatrix.charting.coordsystem.ClassicCoordSystem;
import com.approximatrix.charting.model.ChartDataModel;

/** This class defines a coordinate system. The ClassicCoordSystem class computes
 * an AffineTransform for each y-axis, which translates the user space
 * coordinates (ie. the data value coordinates) into pixel space coordinates.
 * These AffineTransform classes make the PixelToPointTranslator obsolete,
 * since it provides more flexibility. <code>getDefaultTransform</code> always
 * computes the default transformation, whereas you can set another
 * transformation via <code>setTransform</code>. This will be used to implement
 * zooming and panning in the Swing classes.<p>
 * All classes incl. this one, which render data will use the transformations
 * to translate the coordinates. The transformations are not set up on
 * instantiation of a ClassicCoordSystem, instead they're computed when setBounds
 * is called, because they need this information of course. Afterwards you
 * can set your own transformation or even better you can manipulate the
 * existing ones by pre- or postconcatenating another AffineTransform.
 * 
 * @deprecated As of version 1.4, specific rendering coordinate systems should be used.  This will be removed in version 1.5
 */
public class CoordSystem extends ClassicCoordSystem {

	public CoordSystem(ChartDataModel c, DecimalFormat yAxisFormat, boolean drawArrows, boolean paintAltYTick, boolean paintOnlyYTick) {
		super(c, yAxisFormat, drawArrows, paintAltYTick, paintOnlyYTick);
		// TODO Auto-generated constructor stub
	}

	public CoordSystem(ChartDataModel c, String xunit, String yunit) {
		super(c, xunit, yunit);
		// TODO Auto-generated constructor stub
	}

	public CoordSystem(ChartDataModel cdm) {
		super(cdm);
		// TODO Auto-generated constructor stub
	}
}
