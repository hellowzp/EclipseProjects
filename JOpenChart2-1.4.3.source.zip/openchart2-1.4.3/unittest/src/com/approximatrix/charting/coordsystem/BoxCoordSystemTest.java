/*
    OpenChart2 Java Charting Library and Toolkit
    Copyright (C) 2005-2008 Approximatrix, LLC
    Copyright (C) 2001  Sebastian M�ller
    http://www.approximatrix.com

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 
    BoxCoordSystemTest.java 
 */

package com.approximatrix.charting.coordsystem;

import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static org.junit.Assert.*;

import com.approximatrix.charting.model.ObjectChartDataModel;
import com.approximatrix.charting.model.ScatterDataModel;

import com.approximatrix.charting.fixtures.ModelData;

import java.awt.Font;

public class BoxCoordSystemTest {

    private ObjectChartDataModel objectModel = null;
    private ScatterDataModel numericModel = null;
    
    @Before
    public void setup() {
        objectModel = new ObjectChartDataModel(ModelData.doubleData,ModelData.stringAxis,ModelData.seriesLabels);
        numericModel = new ScatterDataModel(ModelData.doubleData,ModelData.doubleAxis,ModelData.seriesLabels);
    }
    
    @After
    public void teardown() {
        objectModel = null;
        numericModel = null;
    }

    @Test
    public void testBoxCoordSystem() {
        BoxCoordSystem coord = new BoxCoordSystem(objectModel);
        
        assertTrue(coord.isPaintAxes());
        assertTrue("labels should be centered for non-numeric axes",coord.isCenterLabelsBetweenTicks());
        assertFalse(coord.isPaintGrid());
        assertTrue(coord.isPaintLabels());
        
        coord = new BoxCoordSystem(numericModel);
        assertFalse("labels should be on ticks for numeric axes",coord.isCenterLabelsBetweenTicks());
    }
    
    @Test
    public void testSetGetFonts() {
        BoxCoordSystem coord = new BoxCoordSystem(objectModel);

        assertNotNull(coord.getUnitFont());
        assertNotNull(coord.getTickFont());
        
        Font current = coord.getUnitFont();
        
        Font unit = current.deriveFont(100.0f);
        Font tick = current.deriveFont(Font.ITALIC);
        
        coord.setUnitFont(unit);
        coord.setTickFont(tick);
        
        assertEquals(unit,coord.getUnitFont());
        assertEquals(tick,coord.getTickFont());
    }
    
    @Test
    public void testSetGetMaximumTicks() {
        BoxCoordSystem coord = new BoxCoordSystem(objectModel);
        
        int defx = coord.getMaximumXTicks();
        int defy = coord.getMaximumYTicks();
        
        coord.setMaximumXTicks(2000);
        coord.setMaximumYTicks(1100);
        
        assertEquals(2000,coord.getMaximumXTicks());
        assertEquals(1100,coord.getMaximumYTicks());
        
        coord.resetMaximumXTicks();
        assertEquals(defx,coord.getMaximumXTicks());
        assertEquals(1100,coord.getMaximumYTicks());
        
        coord.setMaximumXTicks(2000);
        coord.resetMaximumYTicks();
        assertEquals(2000,coord.getMaximumXTicks());
        assertEquals(defy,coord.getMaximumYTicks());
   
    }
}
