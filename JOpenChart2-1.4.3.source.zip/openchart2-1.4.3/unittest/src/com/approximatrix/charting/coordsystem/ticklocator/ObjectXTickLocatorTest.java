package com.approximatrix.charting.coordsystem.ticklocator;

import static org.junit.Assert.*;

import org.junit.Test;

public class ObjectXTickLocatorTest {

	@Test
	public void testGetTickMarkLocationsAsPairs() {
		ObjectXTickLocator loc = new ObjectXTickLocator(1,10,12,true);
		
		float[] pairs = loc.getTickMarkLocationsAsPairs(1);
		assertEquals(20,pairs.length);
		for(int i=1;i<pairs.length;i+=2)
			assertEquals(1.0f,pairs[i]);
	}

	@Test
	public void testGetTickMarkLocations() {
		ObjectXTickLocator loc = new ObjectXTickLocator(1,10,12,false);
		assertTrue(loc.getTickMarkLocations().length < 12);
		
		loc = new ObjectXTickLocator(1,10,8,false);
		assertTrue(loc.getTickMarkLocations().length < 8);
		
		loc = new ObjectXTickLocator(0,9,8,true);
		assertEquals(10,loc.getTickMarkLocations().length);
		for(int i=0;i<10;i++)
			assertEquals(i,loc.getTickMarkLocations()[i]);
	}

}
