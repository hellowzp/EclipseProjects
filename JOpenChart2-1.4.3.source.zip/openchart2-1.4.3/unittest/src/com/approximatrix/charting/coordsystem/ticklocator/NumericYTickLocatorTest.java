package com.approximatrix.charting.coordsystem.ticklocator;

import static org.junit.Assert.*;

import org.junit.Test;

import com.approximatrix.charting.fixtures.ModelData;

public class NumericYTickLocatorTest {

	@Test
	public void testGetTickMarkLocationsAsPairs() {
		NumericYTickLocator loc = new NumericYTickLocator(10.0,1.0,10,12,false);
		double[] values = loc.getTickMarkLocationsAsPairs(1.0);
		
		assertEquals(20,values.length);
		
		for(int i=0; i<values.length; i+=2)
			assertEquals(1.0,values[i]);
	}

	@Test
	public void testGetTickMarkLocations() {
		NumericYTickLocator loc = new NumericYTickLocator(10.0,1.0,10,12,false);
		assertEquals(10,loc.getTickMarkLocations().length);
		assertClose(1.0,ModelData.Smallest(loc.getTickMarkLocations()));
		assertClose(10.0,ModelData.Largest(loc.getTickMarkLocations()));
		
		loc = new NumericYTickLocator(10.0,1.0,10,8,false);
		assertTrue(loc.getTickMarkLocations().length <= 8);
		
		// Check decimal places...
		loc = new NumericYTickLocator(0.1,0.01,10,12,false);
		assertEquals(10,loc.getTickMarkLocations().length);
		
		assertClose(0.01,ModelData.Smallest(loc.getTickMarkLocations()));
		assertClose(0.1,ModelData.Largest(loc.getTickMarkLocations()));
		
		loc = new NumericYTickLocator(0.1,0.01,9,12,true);
		assertEquals(9,loc.getTickMarkLocations().length);
		
	}
	
	private void assertClose(double exp, double actual) {
		assertTrue(Math.abs(exp-actual) <= 1E-6);
	}

}
