/*
    OpenChart2 Java Charting Library and Toolkit
    Copyright (C) 2005-2008 Approximatrix, LLC
    Copyright (C) 2001  Sebastian M�ller
    http://www.approximatrix.com

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

    DotPlotDataModelConstraintsTest.java
*/

package com.approximatrix.charting.model.threedimensional;

import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static org.junit.Assert.*;

import com.approximatrix.charting.fixtures.ModelData;

import com.approximatrix.charting.coordsystem.CoordSystem;

public class DotPlotDataModelConstraintsTest {
    
    private ColorDotPlotDataModel model = null;
        
    @Before
    public void setup() {
        model = new ColorDotPlotDataModel(ModelData.doubleAxis,ModelData.doubleAxis2,ModelData.colorData);
    }
    
    @After
    public void teardown() {
        model = null;
    }

    @Test
    public void testGetMaximumXY() {
        DotPlotDataModelConstraints constraints = new DotPlotDataModelConstraints(model,CoordSystem.FIRST_YAXIS);
        
        assertEquals(ModelData.Largest(ModelData.doubleAxis), constraints.getMaximumX().doubleValue());
        assertEquals(ModelData.Largest(ModelData.doubleAxis2),constraints.getMaximumY().doubleValue());
        
        model.setAutoScale(false);
        
        model.setMaximumValueY(new Double(12.0));
        model.setMaximumValueX(new Double(1.0));

        assertEquals(1.0, constraints.getMaximumX().doubleValue());
        assertEquals(12.0,constraints.getMaximumY().doubleValue());
        
    }
    
    @Test
    public void testGetMinimumXY() {
        DotPlotDataModelConstraints constraints = new DotPlotDataModelConstraints(model,CoordSystem.FIRST_YAXIS);
        
        assertEquals(ModelData.Smallest(ModelData.doubleAxis), constraints.getMinimumX().doubleValue());
        assertEquals(ModelData.Smallest(ModelData.doubleAxis2),constraints.getMinimumY().doubleValue());
        
        model.setAutoScale(false);
        
        model.setMinimumValueY(new Double(12.0));
        model.setMinimumValueX(new Double(1.0));

        assertEquals(1.0, constraints.getMinimumX().doubleValue());
        assertEquals(12.0,constraints.getMinimumY().doubleValue());
        
    }

}
