/*
    OpenChart2 Java Charting Library and Toolkit
    Copyright (C) 2005-2008 Approximatrix, LLC
    Copyright (C) 2001  Sebastian M�ller
    http://www.approximatrix.com

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

    MultiScatterDataModelConstraintsTest.java
*/

package com.approximatrix.charting.model;

import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static org.junit.Assert.*;

import com.approximatrix.charting.fixtures.ModelData;

import com.approximatrix.charting.model.MultiScatterDataModel;

public class MultiScatterDataModelConstraintsTest {
    
    private MultiScatterDataModel numericModel = null;
    
    @Before
    public void setup() {
        numericModel = new MultiScatterDataModel();
        numericModel.addData(ModelData.doubleAxis,ModelData.doubleData[0],ModelData.seriesLabels[0]);
        numericModel.addData(ModelData.doubleAxis,ModelData.doubleData[1],ModelData.seriesLabels[1]);
    }
    
    @After
    public void teardown() {
        numericModel = null;
    }

    @Test
    public void testGetMaximumXY() {
        MultiScatterDataModelConstraints constraints = new MultiScatterDataModelConstraints(numericModel);
        
        assertEquals(ModelData.Largest(ModelData.doubleAxis), constraints.getMaximumX().doubleValue());
        assertEquals(ModelData.Largest(ModelData.doubleData), constraints.getMaximumY().doubleValue());
        
        numericModel.setAutoScale(false);
        
        numericModel.setMaximumValueY(new Double(12.0));
        numericModel.setMaximumValueX(new Double(1.0));

        assertEquals(1.0, constraints.getMaximumX().doubleValue());
        assertEquals(12.0,constraints.getMaximumY().doubleValue());
        
    }

    @Test
    public void testGetMinimumXY() {
        MultiScatterDataModelConstraints constraints = new MultiScatterDataModelConstraints(numericModel);
        
        assertEquals(ModelData.Smallest(ModelData.doubleAxis), constraints.getMinimumX().doubleValue());
        assertEquals(ModelData.Smallest(ModelData.doubleData), constraints.getMinimumY().doubleValue());
        
        numericModel.setAutoScale(false);
        
        numericModel.setMinimumValueY(new Double(12.0));
        numericModel.setMinimumValueX(new Double(1.0));

        assertEquals(1.0, constraints.getMinimumX().doubleValue());
        assertEquals(12.0,constraints.getMinimumY().doubleValue());
        
    }

}
