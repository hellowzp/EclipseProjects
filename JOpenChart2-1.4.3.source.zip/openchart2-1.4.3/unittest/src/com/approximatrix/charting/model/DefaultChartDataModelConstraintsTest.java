/*
    OpenChart2 Java Charting Library and Toolkit
    Copyright (C) 2005-2008 Approximatrix, LLC
    Copyright (C) 2001  Sebastian M�ller
    http://www.approximatrix.com

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

    DefaultChartDataModelConstraintsTest.java
*/

package com.approximatrix.charting.model;

import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static org.junit.Assert.*;

import com.approximatrix.charting.fixtures.ModelData;

import com.approximatrix.charting.coordsystem.CoordSystem;
import com.approximatrix.charting.model.ObjectChartDataModel;
import com.approximatrix.charting.model.ScatterDataModel;

public class DefaultChartDataModelConstraintsTest {
    
    private ObjectChartDataModel objectModel = null;
    private ScatterDataModel numericModel = null;
    
    @Before
    public void setup() {
        objectModel = new ObjectChartDataModel(ModelData.doubleData,ModelData.stringAxis,ModelData.seriesLabels);
        numericModel = new ScatterDataModel(ModelData.doubleData,ModelData.doubleAxis,ModelData.seriesLabels);
    }
    
    @After
    public void teardown() {
        objectModel = null;
        numericModel = null;
    }

    @Test
    public void testGetMaximumXY() {
        DefaultChartDataModelConstraints constraints = new DefaultChartDataModelConstraints(objectModel,CoordSystem.FIRST_YAXIS);
        
        assertEquals((double)ModelData.stringAxis.length, constraints.getMaximumX().doubleValue());
        assertEquals(ModelData.Largest(ModelData.doubleData),constraints.getMaximumY().doubleValue());
        
        objectModel.setAutoScale(false);
        
        objectModel.setMaximumValueX(new Double(1.0));
        objectModel.setMaximumValueY(new Double(12.0));
        
        assertEquals(1.0, constraints.getMaximumX().doubleValue());
        assertEquals(12.0,constraints.getMaximumY().doubleValue());
        
        constraints = new DefaultChartDataModelConstraints(numericModel,CoordSystem.FIRST_YAXIS);
        assertEquals(ModelData.Largest(ModelData.doubleAxis), constraints.getMaximumX().doubleValue());

    }

    @Test
    public void testGetMinimumXY() {
        DefaultChartDataModelConstraints constraints = new DefaultChartDataModelConstraints(objectModel,CoordSystem.FIRST_YAXIS);
        
        assertEquals(0.0, constraints.getMinimumX().doubleValue());
        assertEquals(ModelData.Smallest(ModelData.doubleData),constraints.getMinimumY().doubleValue());
        
        objectModel.setAutoScale(false);
        
        objectModel.setMinimumValueY(new Double(12.0));
        objectModel.setMinimumValueX(new Double(1.0));

        assertEquals(1.0, constraints.getMinimumX().doubleValue());
        assertEquals(12.0,constraints.getMinimumY().doubleValue());
        
        constraints = new DefaultChartDataModelConstraints(numericModel,CoordSystem.FIRST_YAXIS);
        assertEquals(ModelData.Smallest(ModelData.doubleAxis), constraints.getMinimumX().doubleValue());

    }

}
