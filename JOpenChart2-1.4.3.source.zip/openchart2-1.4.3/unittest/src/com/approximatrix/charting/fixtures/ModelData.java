/*
    OpenChart2 Java Charting Library and Toolkit
    Copyright (C) 2005-2008 Approximatrix, LLC
    Copyright (C) 2001  Sebastian M�ller
    http://www.approximatrix.com

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 
    ModelData.java 
 */

package com.approximatrix.charting.fixtures; 

import java.awt.Color;

public class ModelData {

    public static double[][] doubleData = {{1.0,2.0,3.0,4.0},
                                           {5.0,6.0,7.0,8.0}};
                                           
    public static String[] stringAxis = {"A","B","C","D"};
    public static double[] doubleAxis = {0.0,10.0,20.0,30.0};
    
    public static double[] doubleAxis2 = {0.0,100.0,200.0,300.0};
    
    public static Color[] colorData = { Color.WHITE,Color.BLACK,Color.BLUE,Color.GREEN};
    
    public static String[] seriesLabels = {"Series1","Series2"};
    
    public static double Largest(double[][] data) {
        double largest = -1.0*Double.MAX_VALUE;
        for(int i=0;i<data.length;i++)
            largest = Math.max(largest,Largest(data[i]));
        return largest;
    }

    public static double Smallest(double[][] data) {
        double smallest = Double.MAX_VALUE;
        for(int i=0;i<data.length;i++)
            smallest = Math.min(smallest,Smallest(data[i]));
        return smallest;
    }
    
    public static double Largest(double[] data) {
        double largest = -1.0*Double.MAX_VALUE;    
        for(int i=0; i<data.length; i++) 
            largest = Math.max(largest, data[i]);
        return largest;
    }

    public static double Smallest(double[] data) {
        double smallest = Double.MAX_VALUE;    
        for(int i=0; i<data.length; i++) 
            smallest = Math.min(smallest, data[i]);
        return smallest;
    }
}
