/*
 * Created on Jun 16, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.triveratech.helloworld.project;

import org.eclipse.jface.wizard.Wizard;
import org.eclipse.jface.wizard.WizardPage;

/**
 * @author carlos
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class HelloWorldCustomWizard extends Wizard {

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.jface.wizard.IWizard#performFinish()
     */
    public boolean performFinish() {
        return true;
    }

    public void addPages() {
        String pageName = "HelloWorld Custom Wizard Page";
        String title = "HelloWorld Custom Wizard";
        String description = "This is the first and only page of this custom wizard.";

        WizardPage page1 = new HelloWorldWizardPage(pageName);
        page1.setTitle(title);
        page1.setDescription(description);

        addPage(page1);
    }

}