/*
 * Created on Jun 16, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.triveratech.helloworld.project;

import org.eclipse.core.resources.ICommand;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IProjectNature;
import org.eclipse.core.runtime.CoreException;

/**
 * @author carlos
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class HelloWorldNature implements IProjectNature {

    private IProject _project;

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.core.resources.IProjectNature#configure()
     */
    public void configure() throws CoreException {
        IProjectDescription projectDesc = _project.getDescription();
        ICommand[] buildSpec = projectDesc.getBuildSpec();
        boolean hasBuilder = false;

        for (int i = 0; i < buildSpec.length; ++i) {
            if (buildSpec[i]
                .getBuilderName()
                .equals("com.triveratech.helloworld.project.helloworldbuilder")) {
                hasBuilder = true;
                break;
            }
        }

        if (hasBuilder == false) {
            ICommand newCommand = projectDesc.newCommand();
            newCommand.setBuilderName("com.triveratech.helloworld.project.helloworldbuilder");
            ICommand[] buildSpecs = new ICommand[buildSpec.length + 1];

            System.arraycopy(buildSpec, 0, buildSpecs, 1, buildSpec.length);
            buildSpecs[0] = newCommand;
            projectDesc.setBuildSpec(buildSpecs);
            _project.setDescription(projectDesc, null);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.core.resources.IProjectNature#deconfigure()
     */
    public void deconfigure() throws CoreException {
        // TODO Auto-generated method stub

    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.core.resources.IProjectNature#getProject()
     */
    public IProject getProject() {
        // TODO Auto-generated method stub
        return _project;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.core.resources.IProjectNature#setProject(org.eclipse.core.resources.IProject)
     */
    public void setProject(IProject project) {
        // TODO Auto-generated method stub
        _project = project;
    }

}