/*
 * Created on Jun 16, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.triveratech.helloworld.project;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.dialogs.WizardNewProjectCreationPage;

/**
 * @author carlos
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class HelloWorldWizard extends Wizard implements INewWizard {

    private WizardNewProjectCreationPage _page;

    /**
     *  
     */
    public HelloWorldWizard() {
        super();
        // TODO Auto-generated constructor stub
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.jface.wizard.IWizard#addPages()
     */
    public void addPages() {
        _page = new WizardNewProjectCreationPage("page1");
        _page.setDescription("Page 1 of Helloworld New Wizard");
        _page.setTitle("HelloWorld Wizard");
        addPage(_page);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.jface.wizard.IWizard#performFinish()
     */
    public boolean performFinish() {
        boolean result = false;

        System.out.println("project page.name = " + _page.getProjectName());
        System.out.println("project page.path = " + _page.getLocationPath());
        IProject project = _page.getProjectHandle();
        try {
            project.create(null);
            result = true;
        } catch (CoreException e) {
            e.printStackTrace();
        }

        IProjectDescription projectDesc = null;
        try {
            project.open(null);
            projectDesc = project.getDescription();
        } catch (CoreException e1) {
            e1.printStackTrace();
        }

        String[] natureIds = projectDesc.getNatureIds();
        String[] newNatureIds = new String[natureIds.length + 1];
        System.arraycopy(natureIds, 0, newNatureIds, 0, natureIds.length);
        newNatureIds[natureIds.length] = "com.triveratech.helloworld.project.helloworldnature";
        projectDesc.setNatureIds(newNatureIds);
        try {
            project.setDescription(projectDesc, null);
        } catch (CoreException e2) {
            e2.printStackTrace();
        }

        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.IWorkbenchWizard#init(org.eclipse.ui.IWorkbench,
     *      org.eclipse.jface.viewers.IStructuredSelection)
     */
    public void init(IWorkbench workbench, IStructuredSelection selection) {
        // TODO Auto-generated method stub

    }

}