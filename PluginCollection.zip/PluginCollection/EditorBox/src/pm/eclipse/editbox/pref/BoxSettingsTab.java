/*     */ package pm.eclipse.editbox.pref;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jface.preference.ColorSelector;
/*     */ import org.eclipse.jface.util.IPropertyChangeListener;
/*     */ import org.eclipse.jface.util.PropertyChangeEvent;
/*     */ import org.eclipse.swt.custom.StyledText;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.RGB;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Combo;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.FileDialog;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.MessageBox;
/*     */ import org.eclipse.swt.widgets.Scale;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Spinner;
/*     */ import org.eclipse.ui.IWorkbench;
/*     */ import pm.eclipse.editbox.EditBoxActivator;
/*     */ import pm.eclipse.editbox.IBoxDecorator;
/*     */ import pm.eclipse.editbox.IBoxProvider;
/*     */ import pm.eclipse.editbox.IBoxSettings;
/*     */ import pm.eclipse.editbox.IBoxSettings.PropertiesKeys;
/*     */ import pm.eclipse.editbox.IBoxSettingsStore;
/*     */ 
/*     */ public class BoxSettingsTab
/*     */ {
/*     */   protected IWorkbench workbench;
/*     */   protected IBoxProvider provider;
/*     */   protected IBoxSettingsStore store;
/*     */   protected IBoxSettings settings;
/*     */   protected IBoxDecorator decorator;
/*     */   private Button enabled;
/*     */   private Combo combo;
/*     */   private Combo borderWidth;
/*     */   private Button roundBox;
/*     */   private Combo highlightWidth;
/*     */   private Button highlightOne;
/*     */   private ColorSelector fillSelectedColor;
/*     */   private Button fillSelected;
/*     */   private Combo builderCombo;
/*     */   private ColorSelector fromColorLab;
/*     */   private ColorSelector toColorLab;
/*     */   private StyledText st;
/*     */   private Button bordertDrawLine;
/*     */   private Button highlightDrawLine;
/*     */   private Button fillGradient;
/*     */   private ColorSelector fillGradientColor;
/*     */   private Button fillOnMove;
/*     */   private Button circulateColors;
/*     */   private Combo levels;
/*     */   private Combo fillKey;
/*     */   protected boolean changed;
/*     */   private Composite composite;
/*     */   private ColorSelector borderColorSelector;
/*     */   private Combo borderColorType;
/*     */   private Combo highlightColorType;
/*     */   private ColorSelector highlightColorSelector;
/*     */   private Button genGradientBut;
/*     */   private Combo borderLineStyle;
/*     */   private Combo highlightLineStyle;
/*     */   private Button noBackground;
/*     */   private Button eolBox;
/*     */   private Scale scale;
/*     */   private Spinner spinner;
/*     */ 
/*     */   public Control createContro(Composite parent, IBoxProvider provider0)
/*     */   {
/*  84 */     this.provider = provider0;
/*  85 */     if (this.provider == null) {
/*  86 */       Label l = new Label(parent, 0);
/*  87 */       l.setText("Error - cannot make configuration");
/*  88 */       return l;
/*     */     }
/*  90 */     this.store = this.provider.getSettingsStore();
/*  91 */     this.settings = this.provider.createSettings();
/*  92 */     this.decorator = this.provider.createDecorator();
/*  93 */     this.decorator.setSettings(this.settings);
/*  94 */     Control result = createContents0(parent);
/*  95 */     updateContents();
/*  96 */     this.decorator.setStyledText(this.st);
/*  97 */     this.decorator.decorate(true);
/*  98 */     this.decorator.enableUpdates(true);
/*  99 */     this.settings.addPropertyChangeListener(new IPropertyChangeListener() {
/*     */       public void propertyChange(PropertyChangeEvent event) {
/* 101 */         BoxSettingsTab.this.changed = true;
/* 102 */         if (event.getProperty().equals(IBoxSettings.PropertiesKeys.Color.name())) {
/* 103 */           BoxSettingsTab.this.updateFromToColors();
/*     */         }
/* 105 */         BoxSettingsTab.this.provider.getEditorsBoxSettings().copyFrom(BoxSettingsTab.this.settings);
/*     */       }
/*     */     });
/* 109 */     return result;
/*     */   }
/*     */ 
/*     */   protected Control createContents0(Composite parent)
/*     */   {
/* 114 */     int N = 6;
/* 115 */     Composite c = new Composite(parent, 0);
/* 116 */     this.composite = c;
/* 117 */     GridLayout layout = new GridLayout();
/* 118 */     layout.horizontalSpacing = 1;
/* 119 */     layout.marginWidth = 1;
/* 120 */     layout.numColumns = N;
/* 121 */     c.setLayout(layout);
/* 122 */     c.setSize(200, 400);
/*     */ 
/* 124 */     this.enabled = new Button(c, 32);
/* 125 */     GridData gd = new GridData();
/* 126 */     this.enabled.setLayoutData(gd);
/* 127 */     this.enabled.setText("Enabled");
/* 128 */     this.enabled.setAlignment(131072);
/* 129 */     this.enabled.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 132 */         BoxSettingsTab.this.settings.setEnabled(BoxSettingsTab.this.enabled.getSelection());
/*     */       }
/*     */     });
/* 136 */     newButton(c, "Export", new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 139 */         FileDialog dialog = new FileDialog(BoxSettingsTab.this.getShell(), 8192);
/* 140 */         dialog.setFileName(BoxSettingsTab.this.settings.getName());
/* 141 */         dialog.setFilterExtensions(new String[] { "*.eb" });
/* 142 */         dialog.setText("Editbox settings");
/* 143 */         String file = dialog.open();
/* 144 */         if (file != null) {
/*     */           try {
/* 146 */             BoxSettingsTab.this.settings.export(new FileOutputStream(file));
/*     */           } catch (Exception ex) {
/* 148 */             EditBoxActivator.logError(this, "Failed to export EditBox setttings", ex);
/* 149 */             MessageBox mb = new MessageBox(BoxSettingsTab.this.getShell(), 1);
/* 150 */             mb.setText("Failed to export configuration: " + ex.getMessage());
/* 151 */             mb.open();
/*     */           }
/*     */         }
/*     */ 
/* 155 */         super.widgetSelected(e);
/*     */       }
/*     */     });
/* 160 */     Button importConfig = newButton(c, "Import", new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 163 */         FileDialog dialog = new FileDialog(BoxSettingsTab.this.getShell(), 4096);
/* 164 */         dialog.setFileName(BoxSettingsTab.this.settings.getName());
/* 165 */         dialog.setFilterExtensions(new String[] { "*.eb" });
/* 166 */         dialog.setText("Editbox settings");
/* 167 */         String file = dialog.open();
/* 168 */         if (file != null)
/*     */           try {
/* 170 */             IBoxSettings newSettings = BoxSettingsTab.this.provider.createSettings();
/* 171 */             newSettings.load(new FileInputStream(file));
/* 172 */             newSettings.setEnabled(BoxSettingsTab.this.settings.getEnabled());
/* 173 */             BoxSettingsTab.this.settings.copyFrom(newSettings);
/* 174 */             BoxSettingsTab.this.updateContents();
/*     */           } catch (Exception ex) {
/* 176 */             EditBoxActivator.logError(this, "Failed to import EditBox setttings", ex);
/* 177 */             MessageBox mb = new MessageBox(BoxSettingsTab.this.getShell(), 1);
/* 178 */             mb.setText("Failed to load configuration: " + ex.getMessage());
/* 179 */             mb.open();
/*     */           }
/*     */       }
/*     */     });
/* 186 */     gd = new GridData();
/* 187 */     gd.horizontalSpan = 4;
/* 188 */     importConfig.setLayoutData(gd);
/*     */ 
/* 190 */     newLabel(c, "Enter/select theme");
/* 191 */     this.combo = new Combo(c, 4);
/* 192 */     gd = new GridData(1);
/* 193 */     gd.widthHint = 150;
/* 194 */     gd.horizontalSpan = 4;
/* 195 */     gd.horizontalAlignment = 4;
/* 196 */     this.combo.setLayoutData(gd);
/* 197 */     this.combo.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 200 */         String s = BoxSettingsTab.this.combo.getText();
/* 201 */         if ((s != null) && (s.length() > 0)) {
/* 202 */           BoxSettingsTab.this.decorator.enableUpdates(false);
/* 203 */           BoxSettingsTab.this.store.load(s, BoxSettingsTab.this.settings);
/* 204 */           BoxSettingsTab.this.updateContents();
/* 205 */           BoxSettingsTab.this.decorator.enableUpdates(true);
/*     */         }
/*     */       }
/*     */     });
/* 210 */     Button removeConfig = new Button(c, 0);
/* 211 */     removeConfig.setText("Remove");
/* 212 */     removeConfig.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 215 */         String t = BoxSettingsTab.this.combo.getText();
/* 216 */         if ((t != null) && (t.length() > 0)) {
/* 217 */           int si = BoxSettingsTab.this.combo.indexOf(t);
/* 218 */           if (si > -1) {
/* 219 */             BoxSettingsTab.this.combo.remove(si);
/* 220 */             BoxSettingsTab.this.store.remove(t);
/*     */           } else {
/* 222 */             BoxSettingsTab.this.combo.setText("");
/*     */           }
/*     */         }
/*     */       }
/*     */     });
/* 228 */     Label bl = newLabel(c, "Box border:");
/* 229 */     gd = new GridData();
/* 230 */     gd.horizontalSpan = N;
/* 231 */     gd.horizontalAlignment = 4;
/* 232 */     bl.setLayoutData(gd);
/*     */ 
/* 234 */     Composite c1 = new Composite(c, 0);
/* 235 */     GridLayout ly = new GridLayout();
/* 236 */     ly.horizontalSpacing = 0;
/* 237 */     ly.marginWidth = 0;
/* 238 */     ly.numColumns = 2;
/* 239 */     c1.setLayout(layout);
/* 240 */     c1.setLayoutData(new GridData());
/*     */ 
/* 242 */     newLabel(c1, " style");
/* 243 */     this.borderLineStyle = newCombo(c1, new String[] { "Solid", "Dot", "Dash", "DashDot", "DashDotDot" }, new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 246 */         BoxSettingsTab.this.settings.setBorderLineStyle(BoxSettingsTab.this.borderLineStyle.getSelectionIndex());
/*     */       }
/*     */     });
/* 249 */     this.borderLineStyle.select(0);
/*     */ 
/* 251 */     Composite c2 = new Composite(c, 0);
/* 252 */     GridLayout ly2 = new GridLayout();
/* 253 */     ly2.horizontalSpacing = 0;
/* 254 */     ly2.numColumns = 2;
/* 255 */     c2.setLayout(layout);
/* 256 */     c2.setLayoutData(new GridData());
/*     */ 
/* 258 */     newLabel(c2, "color");
/* 259 */     this.borderColorType = newCombo(c2, new String[] { "Custom", "Dark", "Darker", "Darkest" }, new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 262 */         int idx = BoxSettingsTab.this.borderColorType.getSelectionIndex();
/* 263 */         BoxSettingsTab.this.settings.setBorderColorType(idx);
/* 264 */         BoxSettingsTab.this.borderColorSelector.getButton().setEnabled(idx == 0);
/*     */       }
/*     */     });
/* 267 */     this.borderColorType.select(0);
/*     */ 
/* 269 */     this.borderColorSelector = new ColorSelector(c);
/* 270 */     this.borderColorSelector.addListener(new IPropertyChangeListener() {
/*     */       public void propertyChange(PropertyChangeEvent event) {
/* 272 */         BoxSettingsTab.this.settings.setBorderRGB(BoxSettingsTab.this.borderColorSelector.getColorValue());
/*     */       }
/*     */     });
/* 276 */     Label l0 = newLabel(c, "width");
/* 277 */     l0.setLayoutData(new GridData(128));
/* 278 */     this.borderWidth = newCombo(c, new String[] { "0", "1", "2", "3", "4", "5" }, new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e)
/*     */       {
/* 282 */         BoxSettingsTab.this.settings.setBorderWidth(BoxSettingsTab.this.borderWidth.getSelectionIndex());
/*     */       }
/*     */     });
/* 286 */     this.bordertDrawLine = new Button(c, 32);
/* 287 */     this.bordertDrawLine.setText("Line");
/* 288 */     this.bordertDrawLine.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 291 */         BoxSettingsTab.this.settings.setBorderDrawLine(BoxSettingsTab.this.bordertDrawLine.getSelection());
/*     */       }
/*     */     });
/* 296 */     Label hl = newLabel(c, "Highlight selected box:");
/* 297 */     gd = new GridData();
/* 298 */     gd.horizontalSpan = N;
/* 299 */     gd.horizontalAlignment = 4;
/* 300 */     hl.setLayoutData(gd);
/*     */ 
/* 302 */     Composite c3 = new Composite(c, 0);
/* 303 */     GridLayout ly3 = new GridLayout();
/* 304 */     ly3.horizontalSpacing = 0;
/* 305 */     ly3.marginWidth = 0;
/* 306 */     ly3.numColumns = 2;
/* 307 */     c3.setLayout(layout);
/* 308 */     c3.setLayoutData(new GridData());
/*     */ 
/* 310 */     newLabel(c3, " style");
/* 311 */     this.highlightLineStyle = newCombo(c3, new String[] { "Solid", "Dot", "Dash", "DashDot", "DashDotDot" }, new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 314 */         BoxSettingsTab.this.settings.setHighlightLineStyle(BoxSettingsTab.this.highlightLineStyle.getSelectionIndex());
/*     */       }
/*     */     });
/* 317 */     this.highlightLineStyle.select(0);
/*     */ 
/* 319 */     Composite c4 = new Composite(c, 0);
/* 320 */     GridLayout ly5 = new GridLayout();
/* 321 */     ly5.horizontalSpacing = 0;
/* 322 */     ly5.numColumns = 2;
/* 323 */     c4.setLayout(layout);
/* 324 */     c4.setLayoutData(new GridData());
/*     */ 
/* 327 */     newLabel(c4, "color");
/* 328 */     this.highlightColorType = newCombo(c4, new String[] { "Custom", "Dark", "Darker", "Darkest" }, new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 331 */         int idx = BoxSettingsTab.this.highlightColorType.getSelectionIndex();
/* 332 */         BoxSettingsTab.this.settings.setHighlightColorType(idx);
/* 333 */         BoxSettingsTab.this.highlightColorSelector.getButton().setEnabled(idx == 0);
/*     */       }
/*     */     });
/* 336 */     this.highlightColorType.select(0);
/*     */ 
/* 338 */     this.highlightColorSelector = new ColorSelector(c);
/* 339 */     this.highlightColorSelector.addListener(new IPropertyChangeListener() {
/*     */       public void propertyChange(PropertyChangeEvent event) {
/* 341 */         BoxSettingsTab.this.settings.setHighlightRGB(BoxSettingsTab.this.highlightColorSelector.getColorValue());
/*     */       }
/*     */     });
/* 345 */     Label l = newLabel(c, "width");
/* 346 */     l.setLayoutData(new GridData(128));
/* 347 */     this.highlightWidth = newCombo(c, new String[] { "0", "1", "2", "3", "4", "5" }, new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e)
/*     */       {
/* 351 */         BoxSettingsTab.this.settings.setHighlightWidth(BoxSettingsTab.this.highlightWidth.getSelectionIndex());
/*     */       }
/*     */     });
/* 355 */     this.highlightDrawLine = new Button(c, 32);
/* 356 */     this.highlightDrawLine.setText("Line");
/* 357 */     this.highlightDrawLine.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 360 */         BoxSettingsTab.this.settings.setHighlightDrawLine(BoxSettingsTab.this.highlightDrawLine.getSelection());
/*     */       }
/*     */     });
/* 364 */     this.roundBox = new Button(c, 32);
/* 365 */     this.roundBox.setText("Round box");
/* 366 */     this.roundBox.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e)
/*     */       {
/* 370 */         BoxSettingsTab.this.settings.setRoundBox(BoxSettingsTab.this.roundBox.getSelection());
/* 371 */         if (BoxSettingsTab.this.roundBox.getSelection()) {
/* 372 */           BoxSettingsTab.this.fillGradient.setSelection(false);
/* 373 */           BoxSettingsTab.this.settings.setFillGradient(false);
/*     */         }
/*     */       }
/*     */     });
/* 378 */     this.highlightOne = new Button(c, 32);
/* 379 */     this.highlightOne.setText("Highlight one");
/* 380 */     this.highlightOne.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 383 */         BoxSettingsTab.this.settings.setHighlightOne(BoxSettingsTab.this.highlightOne.getSelection());
/*     */       }
/*     */     });
/* 387 */     this.eolBox = new Button(c, 32);
/* 388 */     this.eolBox.setText("Expand box");
/* 389 */     this.eolBox.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 392 */         BoxSettingsTab.this.settings.setExpandBox(BoxSettingsTab.this.eolBox.getSelection());
/*     */       }
/*     */     });
/* 396 */     gd = new GridData();
/* 397 */     gd.horizontalSpan = 2;
/* 398 */     this.eolBox.setLayoutData(gd);
/*     */ 
/* 400 */     this.noBackground = new Button(c, 32);
/* 401 */     this.noBackground.setText("No background");
/* 402 */     this.noBackground.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 405 */         BoxSettingsTab.this.settings.setNoBackground(BoxSettingsTab.this.noBackground.getSelection());
/*     */       }
/*     */     });
/* 409 */     gd = new GridData();
/* 410 */     gd.horizontalSpan = 2;
/* 411 */     this.noBackground.setLayoutData(gd);
/*     */ 
/* 413 */     this.fillSelected = new Button(c, 32);
/* 414 */     this.fillSelected.setText("Fill selected box");
/* 415 */     this.fillSelected.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e)
/*     */       {
/* 419 */         BoxSettingsTab.this.settings.setFillSelected(BoxSettingsTab.this.fillSelected.getSelection());
/*     */       }
/*     */     });
/* 423 */     this.fillSelectedColor = new ColorSelector(c);
/* 424 */     this.fillSelectedColor.addListener(new IPropertyChangeListener() {
/*     */       public void propertyChange(PropertyChangeEvent e) {
/* 426 */         BoxSettingsTab.this.settings.setFillSelectedRGB(BoxSettingsTab.this.fillSelectedColor.getColorValue());
/*     */       }
/*     */     });
/* 429 */     this.fillSelectedColor.getButton().setLayoutData(new GridData(1));
/*     */ 
/* 431 */     this.fillOnMove = new Button(c, 32);
/* 432 */     this.fillOnMove.setText("On move");
/* 433 */     this.fillOnMove.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 436 */         BoxSettingsTab.this.settings.setFillOnMove(BoxSettingsTab.this.fillOnMove.getSelection());
/*     */       }
/*     */     });
/* 440 */     newLabel(c, "with key");
/* 441 */     gd = new GridData();
/* 442 */     gd.horizontalSpan = 2;
/* 443 */     this.fillOnMove.setLayoutData(gd);
/*     */ 
/* 445 */     this.fillKey = newCombo(c, new String[] { "", "Alt", "Ctrl", "Shift" }, new SelectionAdapter() {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 447 */         BoxSettingsTab.this.settings.setFillKeyModifier(BoxSettingsTab.this.fillKey.getText());
/*     */       }
/*     */     });
/* 451 */     this.fillGradient = new Button(c, 32);
/* 452 */     this.fillGradient.setText("Make gradient");
/* 453 */     this.fillGradient.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e)
/*     */       {
/* 457 */         BoxSettingsTab.this.settings.setFillGradient(BoxSettingsTab.this.fillGradient.getSelection());
/* 458 */         if (BoxSettingsTab.this.fillGradient.getSelection()) {
/* 459 */           BoxSettingsTab.this.roundBox.setSelection(false);
/* 460 */           BoxSettingsTab.this.settings.setRoundBox(false);
/*     */         }
/*     */       }
/*     */     });
/* 465 */     this.fillGradientColor = new ColorSelector(c);
/* 466 */     this.fillGradientColor.addListener(new IPropertyChangeListener()
/*     */     {
/*     */       public void propertyChange(PropertyChangeEvent event) {
/* 469 */         BoxSettingsTab.this.settings.setFillGradientColorRGB(BoxSettingsTab.this.fillGradientColor.getColorValue());
/*     */       }
/*     */     });
/* 474 */     Label la = newLabel(c, "Alpha blending");
/* 475 */     la.setToolTipText("Can slow down box drawing");
/* 476 */     gd = new GridData();
/* 477 */     gd.horizontalSpan = 2;
/* 478 */     la.setLayoutData(gd);
/*     */ 
/* 480 */     this.scale = new Scale(c, 256);
/* 481 */     this.scale.setToolTipText("Can slow down box drawing");
/* 482 */     gd = new GridData();
/* 483 */     gd.horizontalSpan = 1;
/* 484 */     gd.widthHint = 80;
/* 485 */     this.scale.setLayoutData(gd);
/* 486 */     this.scale.setMinimum(0);
/* 487 */     this.scale.setMinimum(255);
/* 488 */     this.scale.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 491 */         int alpha = BoxSettingsTab.this.scale.getSelection() * 255 / 100;
/* 492 */         BoxSettingsTab.this.spinner.setSelection(alpha);
/* 493 */         BoxSettingsTab.this.settings.setAlpha(alpha);
/*     */       }
/*     */     });
/* 497 */     this.spinner = new Spinner(c, 0);
/* 498 */     this.spinner.setToolTipText("Can slow down box drawing");
/* 499 */     this.spinner.setMinimum(0);
/* 500 */     this.spinner.setMaximum(255);
/* 501 */     this.spinner.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 504 */         BoxSettingsTab.this.scale.setSelection(BoxSettingsTab.this.spinner.getSelection() * 100 / 255);
/* 505 */         BoxSettingsTab.this.settings.setAlpha(BoxSettingsTab.this.spinner.getSelection());
/*     */       }
/*     */     });
/* 509 */     gd = new GridData();
/* 510 */     gd.horizontalSpan = 1;
/* 511 */     this.spinner.setLayoutData(gd);
/*     */ 
/* 513 */     newLabel(c, "Color levels");
/* 514 */     this.levels = newCombo(c, new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14" }, new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 517 */         BoxSettingsTab.this.settings.setColorsSize(BoxSettingsTab.this.levels.getSelectionIndex());
/* 518 */         BoxSettingsTab.this.st.setText(BoxSettingsTab.this.generateIndentText(BoxSettingsTab.this.settings.getColorsSize() + 1));
/*     */       }
/*     */     });
/* 522 */     this.circulateColors = new Button(c, 32);
/* 523 */     this.circulateColors.setText("Circulate colors");
/* 524 */     this.circulateColors.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 527 */         BoxSettingsTab.this.settings.setCirculateLevelColors(BoxSettingsTab.this.circulateColors.getSelection());
/*     */       }
/*     */     });
/* 531 */     gd = new GridData();
/* 532 */     gd.horizontalSpan = 4;
/* 533 */     this.circulateColors.setLayoutData(gd);
/*     */ 
/* 536 */     newLabel(c, "Syntax");
/* 537 */     this.builderCombo = new Combo(c, 8);
/* 538 */     gd = new GridData(1);
/* 539 */     gd.horizontalSpan = 5;
/* 540 */     this.builderCombo.setLayoutData(gd);
/* 541 */     this.builderCombo.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e)
/*     */       {
/* 545 */         BoxSettingsTab.this.settings.setBuilder(BoxSettingsTab.this.builderCombo.getText());
/*     */       }
/*     */     });
/* 549 */     newLabel(c, "Gradient tool");
/*     */ 
/* 551 */     Composite c6 = new Composite(c, 0);
/* 552 */     GridLayout ly6 = new GridLayout();
/* 553 */     ly6.horizontalSpacing = 0;
/* 554 */     ly6.marginWidth = 0;
/* 555 */     ly6.numColumns = 2;
/* 556 */     c6.setLayout(layout);
/* 557 */     c6.setLayoutData(new GridData());
/*     */ 
/* 559 */     newLabel(c6, "from color");
/*     */ 
/* 561 */     this.fromColorLab = new ColorSelector(c6);
/* 562 */     this.fromColorLab.getButton().setLayoutData(new GridData(32));
/*     */ 
/* 564 */     newLabel(c, "to");
/* 565 */     this.toColorLab = new ColorSelector(c);
/*     */ 
/* 567 */     IPropertyChangeListener listener = new IPropertyChangeListener() {
/*     */       public void propertyChange(PropertyChangeEvent event) {
/* 569 */         BoxSettingsTab.this.genGradientBut.setEnabled((BoxSettingsTab.this.toColorLab.getColorValue() != null) && (BoxSettingsTab.this.fromColorLab.getColorValue() != null));
/*     */       }
/*     */     };
/* 572 */     this.fromColorLab.addListener(listener);
/* 573 */     this.toColorLab.addListener(listener);
/*     */ 
/* 575 */     this.genGradientBut = newButton(c, "Generate", new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e)
/*     */       {
/* 579 */         if ((BoxSettingsTab.this.fromColorLab.getColorValue() == null) || (BoxSettingsTab.this.toColorLab.getColorValue() == null))
/* 580 */           return;
/* 581 */         Color[] colors = BoxSettingsTab.this.settings.getColors();
/* 582 */         if ((colors == null) || (colors.length < 2))
/* 583 */           return;
/* 584 */         BoxSettingsTab.this.settings.setColorsRGB(BoxSettingsTab.this.rgbGradient(colors));
/*     */       }
/*     */     });
/* 588 */     Label l1 = newLabel(c, "Preview - double click on any box to change color:");
/* 589 */     gd = new GridData();
/* 590 */     gd.horizontalSpan = N;
/* 591 */     gd.horizontalAlignment = 4;
/* 592 */     l1.setLayoutData(gd);
/*     */ 
/* 594 */     this.st = new StyledText(c, 68360);
/* 595 */     gd = new GridData();
/* 596 */     gd.horizontalSpan = N;
/* 597 */     gd.grabExcessVerticalSpace = true;
/* 598 */     gd.verticalAlignment = 4;
/* 599 */     gd.horizontalAlignment = 4;
/* 600 */     gd.heightHint = 50;
/* 601 */     this.st.setLayoutData(gd);
/* 602 */     this.st.setEditable(false);
/* 603 */     this.st.setToolTipText("Double click to change color");
/* 604 */     return c;
/*     */   }
/*     */ 
/*     */   protected Shell getShell() {
/* 608 */     if (this.composite != null)
/* 609 */       return this.composite.getShell();
/* 610 */     return null;
/*     */   }
/*     */ 
/*     */   protected Combo newCombo(Composite c, String[] items, SelectionListener listener) {
/* 614 */     Combo combo1 = new Combo(c, 8);
/* 615 */     combo1.setItems(items);
/* 616 */     combo1.addSelectionListener(listener);
/* 617 */     return combo1;
/*     */   }
/*     */ 
/*     */   protected Button newButton(Composite c, String name, SelectionAdapter selectionAdapter) {
/* 621 */     Button b = new Button(c, 0);
/* 622 */     b.setText(name);
/* 623 */     b.addSelectionListener(selectionAdapter);
/* 624 */     return b;
/*     */   }
/*     */ 
/*     */   protected Label newLabel(Composite c, String msg) {
/* 628 */     Label l = new Label(c, 0);
/* 629 */     l.setText(msg);
/* 630 */     Color bc = c.getBackground();
/* 631 */     if (bc != null)
/* 632 */       l.setBackground(new Color(null, bc.getRGB()));
/* 633 */     return l;
/*     */   }
/*     */ 
/*     */   protected void updateContents()
/*     */   {
/* 638 */     this.enabled.setSelection(this.settings.getEnabled());
/* 639 */     this.combo.setItems((String[])this.store.getCatalog().toArray(new String[0]));
/* 640 */     if (this.settings.getName() != null) {
/* 641 */       int idx = this.combo.indexOf(this.settings.getName());
/* 642 */       if (idx > -1)
/* 643 */         this.combo.select(idx);
/* 644 */       else this.combo.setText(this.settings.getName());
/*     */     }
/* 646 */     if (this.settings.getBorderColor() != null)
/* 647 */       this.borderColorSelector.setColorValue(this.settings.getBorderColor().getRGB());
/* 648 */     this.borderWidth.select(this.settings.getBorderWidth());
/* 649 */     this.roundBox.setSelection(this.settings.getRoundBox());
/* 650 */     if (this.settings.getHighlightColor() != null)
/* 651 */       this.highlightColorSelector.setColorValue(this.settings.getHighlightColor().getRGB());
/* 652 */     this.highlightWidth.select(this.settings.getHighlightWidth());
/* 653 */     this.highlightOne.setSelection(this.settings.getHighlightOne());
/* 654 */     this.fillSelected.setSelection(this.settings.getFillSelected());
/* 655 */     if (this.settings.getFillSelectedColor() != null)
/* 656 */       this.fillSelectedColor.setColorValue(this.settings.getFillSelectedColor().getRGB());
/* 657 */     this.builderCombo.setItems((String[])this.provider.getBuilders().toArray(new String[0]));
/* 658 */     int i = -1;
/* 659 */     if (this.settings.getBuilder() != null)
/* 660 */       i = this.builderCombo.indexOf(this.settings.getBuilder());
/* 661 */     this.builderCombo.select(i == -1 ? 0 : i);
/* 662 */     this.st.setText(generateIndentText(this.settings.getColorsSize() + 1));
/* 663 */     updateFromToColors();
/* 664 */     this.bordertDrawLine.setSelection(this.settings.getBorderDrawLine());
/* 665 */     this.highlightDrawLine.setSelection(this.settings.getHighlightDrawLine());
/* 666 */     this.fillGradient.setSelection(this.settings.getFillGradient());
/* 667 */     if (this.settings.getFillGradientColor() != null)
/* 668 */       this.fillGradientColor.setColorValue(this.settings.getFillGradientColor().getRGB());
/* 669 */     this.fillOnMove.setSelection(this.settings.getFillOnMove());
/* 670 */     this.circulateColors.setSelection(this.settings.getCirculateLevelColors());
/* 671 */     this.levels.select(this.settings.getColorsSize());
/* 672 */     this.fillKey.setText(this.settings.getFillKeyModifier() == null ? "" : this.settings.getFillKeyModifier());
/* 673 */     this.borderColorType.select(this.settings.getBorderColorType());
/* 674 */     this.highlightColorType.select(this.settings.getHighlightColorType());
/* 675 */     this.highlightColorSelector.getButton().setEnabled(this.settings.getHighlightColorType() == 0);
/* 676 */     this.borderColorSelector.getButton().setEnabled(this.settings.getBorderColorType() == 0);
/* 677 */     this.borderLineStyle.select(this.settings.getBorderLineStyle());
/* 678 */     this.highlightLineStyle.select(this.settings.getHighlightLineStyle());
/* 679 */     this.noBackground.setSelection(this.settings.getNoBackground());
/* 680 */     this.eolBox.setSelection(this.settings.getExpandBox());
/* 681 */     this.spinner.setSelection(this.settings.getAlpha());
/* 682 */     this.scale.setSelection(this.settings.getAlpha() * 100 / 255);
/*     */   }
/*     */ 
/*     */   private void updateFromToColors() {
/* 686 */     Color[] c = this.settings.getColors();
/* 687 */     if ((c != null) && (c.length > 1)) {
/* 688 */       updateBackground(this.fromColorLab, c[0]);
/* 689 */       updateBackground(this.toColorLab, c[(c.length - 1)]);
/*     */     } else {
/* 691 */       this.genGradientBut.setEnabled(false);
/*     */     }
/*     */   }
/*     */ 
/* 695 */   protected void updateBackground(ColorSelector ctrl, Color c) { if (c == null)
/* 696 */       this.genGradientBut.setEnabled(false);
/*     */     else
/* 698 */       ctrl.setColorValue(c.getRGB()); }
/*     */ 
/*     */   protected void disposeColor(Color oldColor)
/*     */   {
/* 702 */     if (oldColor != null)
/* 703 */       oldColor.dispose();
/*     */   }
/*     */ 
/*     */   public void dispose() {
/* 707 */     if (this.settings != null)
/* 708 */       this.settings.dispose();
/*     */   }
/*     */ 
/*     */   private RGB[] rgbGradient(Color[] c) {
/* 712 */     int n = c.length - 1;
/* 713 */     RGB c1 = this.fromColorLab.getColorValue();
/* 714 */     RGB c2 = this.toColorLab.getColorValue();
/* 715 */     int VR = (c2.red - c1.red) / n;
/* 716 */     int VG = (c2.green - c1.green) / n;
/* 717 */     int VB = (c2.blue - c1.blue) / n;
/*     */ 
/* 719 */     RGB[] gradient = new RGB[n + 1];
/* 720 */     gradient[0] = c1;
/* 721 */     for (int i = 1; i <= n; i++) {
/* 722 */       RGB prev = gradient[(i - 1)];
/* 723 */       gradient[i] = new RGB(prev.red + VR, prev.green + VG, prev.blue + VB);
/*     */     }
/* 725 */     return gradient;
/*     */   }
/*     */ 
/*     */   String generateIndentText(int n) {
/* 729 */     StringBuilder sb = new StringBuilder();
/* 730 */     for (int i = 0; i < n; i++) {
/* 731 */       for (int j = 0; j < i; j++)
/* 732 */         sb.append("  ");
/* 733 */       sb.append("level " + (i + 1 == n ? "n" : Integer.valueOf(i + 1)));
/* 734 */       sb.append("\n");
/*     */     }
/* 736 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public IBoxProvider getProvider() {
/* 740 */     return this.provider;
/*     */   }
/*     */ 
/*     */   public IBoxSettings getSettings() {
/* 744 */     return this.settings;
/*     */   }
/*     */ 
/*     */   public String validate() {
/* 748 */     this.settings.setName(this.combo.getText());
/* 749 */     if ((this.settings.getName() == null) || (this.settings.getName().length() == 0)) {
/* 750 */       return "Enter configuration name";
/*     */     }
/* 752 */     return null;
/*     */   }
/*     */ 
/*     */   public void save() {
/* 756 */     if (this.changed) {
/* 757 */       this.store.saveDefaults(this.settings);
/* 758 */       this.provider.getEditorsBoxSettings().copyFrom(this.settings);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void cancel() {
/* 763 */     if (this.changed)
/* 764 */       this.store.loadDefaults(this.provider.getEditorsBoxSettings());
/*     */   }
/*     */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.pref.BoxSettingsTab
 * JD-Core Version:    0.6.2
 */