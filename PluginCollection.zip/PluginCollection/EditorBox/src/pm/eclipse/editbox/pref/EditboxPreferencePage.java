/*     */ package pm.eclipse.editbox.pref;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import org.eclipse.jface.dialogs.IInputValidator;
/*     */ import org.eclipse.jface.dialogs.InputDialog;
/*     */ import org.eclipse.jface.preference.PreferencePage;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.FontData;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Link;
/*     */ import org.eclipse.swt.widgets.List;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.TabFolder;
/*     */ import org.eclipse.swt.widgets.TabItem;
/*     */ import org.eclipse.ui.IWorkbench;
/*     */ import org.eclipse.ui.IWorkbenchPreferencePage;
/*     */ import org.eclipse.ui.preferences.IWorkbenchPreferenceContainer;
/*     */ import pm.eclipse.editbox.EditBoxActivator;
/*     */ import pm.eclipse.editbox.IBoxProvider;
/*     */ import pm.eclipse.editbox.IBoxSettings;
/*     */ import pm.eclipse.editbox.impl.BoxProviderRegistry;
/*     */ 
/*     */ public class EditboxPreferencePage extends PreferencePage
/*     */   implements IWorkbenchPreferencePage
/*     */ {
/*     */   private List categoryList;
/*     */   private TabFolder folder;
/*     */   private Map<String, LinkedHashSet<String>> categoryFiles;
/*     */   private List namesList;
/*     */   private Button bAddFile;
/*     */   private boolean providersChanged;
/*     */ 
/*     */   protected Control createContents(Composite parent)
/*     */   {
/*  47 */     noDefaultAndApplyButton();
/*     */ 
/*  49 */     Composite c = new Composite(parent, 0);
/*  50 */     c.setLayout(new GridLayout(1, false));
/*  51 */     Link link = new Link(c, 0);
/*  52 */     link.setText("Turn off current line highlighting <A>here</A>.");
/*  53 */     FontData[] fontData = link.getFont().getFontData();
/*  54 */     for (FontData fd : fontData) {
/*  55 */       fd.setHeight(10);
/*  56 */       fd.setStyle(1);
/*     */     }
/*  58 */     link.setFont(new Font(getShell().getDisplay(), fontData));
/*  59 */     link.addSelectionListener(new SelectionAdapter() {
/*     */       public void widgetSelected(SelectionEvent e) {
/*  61 */         IWorkbenchPreferenceContainer container = (IWorkbenchPreferenceContainer)EditboxPreferencePage.this.getContainer();
/*  62 */         container.openPage("org.eclipse.ui.preferencePages.GeneralTextEditor", null);
/*     */       }
/*     */     });
/*  66 */     this.folder = new TabFolder(c, 0);
/*  67 */     this.folder.setLayoutData(new GridData(1808));
/*  68 */     TabItem ti = new TabItem(this.folder, 0);
/*  69 */     ti.setText("Themes");
/*  70 */     ti.setControl(createCategoryControl(this.folder));
/*  71 */     this.folder.pack();
/*  72 */     return c;
/*     */   }
/*     */ 
/*     */   protected Control createCategoryControl(Composite parent) {
/*  76 */     Composite c = new Composite(parent, 0);
/*  77 */     c.setLayout(new GridLayout(2, true));
/*     */ 
/*  79 */     Label categoryLabel = new Label(c, 0);
/*  80 */     categoryLabel.setText("Themes");
/*     */ 
/*  82 */     Label namesLabel = new Label(c, 0);
/*  83 */     namesLabel.setText("Associated file names");
/*  84 */     namesLabel.setAlignment(131072);
/*     */ 
/*  86 */     this.categoryList = new List(c, 2560);
/*  87 */     this.categoryList.setLayoutData(new GridData(1808));
/*  88 */     this.categoryList.addSelectionListener(new SelectCategory());
/*  89 */     this.namesList = new List(c, 2560);
/*  90 */     this.namesList.setLayoutData(new GridData(1808));
/*     */ 
/*  92 */     Composite cLeft = new Composite(c, 0);
/*  93 */     cLeft.setLayout(new GridLayout(2, true));
/*  94 */     Button bAddCategory = new Button(cLeft, 0);
/*  95 */     bAddCategory.setText("Add");
/*  96 */     bAddCategory.addSelectionListener(new AddCategory());
/*  97 */     bAddCategory.setLayoutData(new GridData(1808));
/*  98 */     Button bRemoveCategory = new Button(cLeft, 0);
/*  99 */     bRemoveCategory.setText("Remove");
/* 100 */     bRemoveCategory.setLayoutData(new GridData(1808));
/* 101 */     bRemoveCategory.addSelectionListener(new RemoveCategory());
/*     */ 
/* 103 */     Composite cRight = new Composite(c, 0);
/* 104 */     cRight.setLayoutData(new GridData(128));
/* 105 */     cRight.setLayout(new GridLayout(2, true));
/* 106 */     this.bAddFile = new Button(cRight, 0);
/* 107 */     this.bAddFile.setText("Add");
/* 108 */     this.bAddFile.setLayoutData(new GridData(1808));
/* 109 */     this.bAddFile.addSelectionListener(new AddFile());
/* 110 */     this.bAddFile.setEnabled(false);
/* 111 */     Button bRemoveFile = new Button(cRight, 0);
/* 112 */     bRemoveFile.setText("Remove");
/* 113 */     bRemoveFile.setLayoutData(new GridData(1808));
/* 114 */     bRemoveFile.addSelectionListener(new RemoveFile());
/*     */ 
/* 116 */     loadData();
/*     */ 
/* 118 */     return c;
/*     */   }
/*     */ 
/*     */   protected void loadData() {
/* 122 */     Collection boxProviders = EditBoxActivator.getDefault().getProviderRegistry().getBoxProviders();
/* 123 */     for (IBoxProvider provider : boxProviders)
/* 124 */       newTab(provider.getName());
/*     */   }
/*     */ 
/*     */   public void init(IWorkbench workbench) {
/*     */   }
/*     */ 
/*     */   protected boolean contains(String[] items, String newText) {
/* 131 */     if ((items == null) || (items.length == 0))
/* 132 */       return false;
/* 133 */     for (String s : items)
/* 134 */       if (s.equalsIgnoreCase(newText))
/* 135 */         return true;
/* 136 */     return false;
/*     */   }
/*     */ 
/*     */   protected void newTab(String value) {
/* 140 */     this.categoryList.add(value);
/* 141 */     TabItem item = new TabItem(this.folder, 0);
/* 142 */     item.setText(value);
/* 143 */     BoxSettingsTab p = new BoxSettingsTab();
/* 144 */     IBoxProvider provider = EditBoxActivator.getDefault().getProviderRegistry().providerForName(value);
/* 145 */     item.setControl(p.createContro(this.folder, provider));
/* 146 */     item.setData(p);
/* 147 */     if (this.categoryFiles == null)
/* 148 */       this.categoryFiles = new LinkedHashMap();
/* 149 */     Collection fileNames = p.getSettings().getFileNames();
/* 150 */     if (fileNames == null)
/* 151 */       fileNames = Collections.emptyList();
/* 152 */     this.categoryFiles.put(value, new LinkedHashSet(fileNames));
/* 153 */     this.categoryList.setSelection(new String[] { value });
/* 154 */     this.namesList.setItems((String[])fileNames.toArray(new String[0]));
/* 155 */     this.bAddFile.setEnabled(true);
/*     */   }
/*     */ 
/*     */   public String[] namesArray(String name) {
/* 159 */     LinkedHashSet set = (LinkedHashSet)this.categoryFiles.get(name);
/* 160 */     if ((set == null) || (set.isEmpty()))
/* 161 */       return new String[0];
/* 162 */     return (String[])set.toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   public void addFileName(String value) {
/* 166 */     int i = this.categoryList.getSelectionIndex();
/* 167 */     if (i > -1) {
/* 168 */       String categoryName = this.categoryList.getItem(i);
/* 169 */       LinkedHashSet fileNames = (LinkedHashSet)this.categoryFiles.get(categoryName);
/* 170 */       fileNames.add(value);
/* 171 */       this.namesList.add(value);
/* 172 */       Object o = this.folder.getItem(i + 1).getData();
/* 173 */       if ((o instanceof BoxSettingsTab))
/* 174 */         ((BoxSettingsTab)o).getSettings().setFileNames(fileNames);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean performOk()
/*     */   {
/* 180 */     TabItem[] items = this.folder.getItems();
/* 181 */     for (int i = 1; i < items.length; i++) {
/* 182 */       Object o = items[i].getData();
/* 183 */       if ((o instanceof BoxSettingsTab)) {
/* 184 */         BoxSettingsTab pref = (BoxSettingsTab)o;
/* 185 */         String msg = pref.validate();
/* 186 */         if (msg != null) {
/* 187 */           this.folder.setSelection(i);
/* 188 */           setMessage(msg);
/* 189 */           return false;
/*     */         }
/* 191 */         pref.save();
/*     */       }
/*     */     }
/* 194 */     if (this.providersChanged)
/* 195 */       EditBoxActivator.getDefault().getProviderRegistry().storeProviders();
/* 196 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean performCancel()
/*     */   {
/* 201 */     TabItem[] items = this.folder.getItems();
/* 202 */     for (int i = 1; i < items.length; i++) {
/* 203 */       Object o = items[i].getData();
/* 204 */       if ((o instanceof BoxSettingsTab)) {
/* 205 */         ((BoxSettingsTab)o).cancel();
/*     */       }
/*     */     }
/*     */ 
/* 209 */     if (this.providersChanged)
/* 210 */       EditBoxActivator.getDefault().getProviderRegistry().setProvideres(null);
/* 211 */     return true;
/*     */   }
/*     */   class AddCategory extends SelectionAdapter {
/*     */     AddCategory() {
/*     */     }
/*     */ 
/*     */     public void widgetSelected(SelectionEvent e) {
/* 218 */       InputDialog dialog = new InputDialog(EditboxPreferencePage.this.getShell(), "New Catagory", "Name:", null, new IInputValidator() {
/*     */         public String isValid(String newText) {
/* 220 */           if ((newText != null) && (newText.trim().length() > 0) && (!EditboxPreferencePage.this.contains(EditboxPreferencePage.this.categoryList.getItems(), newText)))
/* 221 */             return null;
/* 222 */           return "Unique name required";
/*     */         }
/*     */       });
/* 226 */       if (dialog.open() == 0) {
/* 227 */         EditboxPreferencePage.this.newTab(dialog.getValue());
/* 228 */         EditboxPreferencePage.this.providersChanged = true;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   class AddFile extends SelectionAdapter
/*     */   {
/*     */     AddFile()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void widgetSelected(SelectionEvent e)
/*     */     {
/* 278 */       InputDialog dialog = new InputDialog(EditboxPreferencePage.this.getShell(), "New Name", "File name pattern like *.java, my.xml:", null, new IInputValidator()
/*     */       {
/*     */         public String isValid(String newText) {
/* 281 */           if ((newText != null) && (newText.trim().length() > 0))
/* 282 */             return null;
/* 283 */           return "";
/*     */         }
/*     */       });
/* 287 */       if (dialog.open() == 0)
/* 288 */         EditboxPreferencePage.this.addFileName(dialog.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   class RemoveCategory extends SelectionAdapter
/*     */   {
/*     */     RemoveCategory()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void widgetSelected(SelectionEvent e)
/*     */     {
/* 239 */       int i = EditboxPreferencePage.this.categoryList.getSelectionIndex();
/* 240 */       if (i > -1) {
/* 241 */         String name = EditboxPreferencePage.this.categoryList.getItem(i);
/* 242 */         EditboxPreferencePage.this.categoryList.remove(i);
/* 243 */         EditboxPreferencePage.this.categoryFiles.remove(name);
/* 244 */         EditboxPreferencePage.this.namesList.setItems(new String[0]);
/* 245 */         EditboxPreferencePage.this.bAddFile.setEnabled(false);
/* 246 */         TabItem ti = EditboxPreferencePage.this.folder.getItem(i + 1);
/* 247 */         Object o = ti.getData();
/* 248 */         ti.dispose();
/* 249 */         if ((o instanceof BoxSettingsTab)) {
/* 250 */           ((BoxSettingsTab)o).dispose();
/*     */         }
/* 252 */         EditBoxActivator.getDefault().getProviderRegistry().removeProvider(name);
/* 253 */         EditboxPreferencePage.this.providersChanged = true;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   class RemoveFile extends SelectionAdapter
/*     */   {
/*     */     RemoveFile()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void widgetSelected(SelectionEvent e)
/*     */     {
/* 298 */       int i = EditboxPreferencePage.this.namesList.getSelectionIndex();
/* 299 */       if (i > -1) {
/* 300 */         int n = EditboxPreferencePage.this.categoryList.getSelectionIndex();
/* 301 */         if (n > -1) {
/* 302 */           String key = EditboxPreferencePage.this.categoryList.getItem(n);
/* 303 */           String value = EditboxPreferencePage.this.namesList.getItem(i);
/* 304 */           LinkedHashSet fNames = (LinkedHashSet)EditboxPreferencePage.this.categoryFiles.get(key);
/* 305 */           fNames.remove(value);
/* 306 */           EditboxPreferencePage.this.namesList.remove(i);
/* 307 */           Object o = EditboxPreferencePage.this.folder.getItem(n + 1).getData();
/* 308 */           if ((o instanceof BoxSettingsTab))
/* 309 */             ((BoxSettingsTab)o).getSettings().setFileNames(new ArrayList(fNames));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   class SelectCategory extends SelectionAdapter
/*     */   {
/*     */     SelectCategory()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void widgetSelected(SelectionEvent e)
/*     */     {
/* 262 */       int i = EditboxPreferencePage.this.categoryList.getSelectionIndex();
/* 263 */       if (i > -1) {
/* 264 */         String name = EditboxPreferencePage.this.categoryList.getItem(i);
/* 265 */         EditboxPreferencePage.this.namesList.setItems(EditboxPreferencePage.this.namesArray(name));
/* 266 */         EditboxPreferencePage.this.bAddFile.setEnabled(true);
/*     */       } else {
/* 268 */         EditboxPreferencePage.this.namesList.setItems(new String[0]);
/* 269 */         EditboxPreferencePage.this.bAddFile.setEnabled(false);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.pref.EditboxPreferencePage
 * JD-Core Version:    0.6.2
 */