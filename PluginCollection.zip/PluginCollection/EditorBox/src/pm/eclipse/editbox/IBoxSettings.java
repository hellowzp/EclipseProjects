/*    */ package pm.eclipse.editbox;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.util.Collection;
/*    */ import org.eclipse.jface.util.IPropertyChangeListener;
/*    */ import org.eclipse.swt.graphics.Color;
/*    */ import org.eclipse.swt.graphics.RGB;
/*    */ 
/*    */ public abstract interface IBoxSettings
/*    */ {
/*    */   public abstract void addPropertyChangeListener(IPropertyChangeListener paramIPropertyChangeListener);
/*    */ 
/*    */   public abstract void removePropertyChangeListener(IPropertyChangeListener paramIPropertyChangeListener);
/*    */ 
/*    */   public abstract String getName();
/*    */ 
/*    */   public abstract void setName(String paramString);
/*    */ 
/*    */   public abstract boolean getEnabled();
/*    */ 
/*    */   public abstract void setEnabled(boolean paramBoolean);
/*    */ 
/*    */   public abstract void setFileNames(Collection<String> paramCollection);
/*    */ 
/*    */   public abstract Collection<String> getFileNames();
/*    */ 
/*    */   public abstract String getText();
/*    */ 
/*    */   public abstract void setText(String paramString);
/*    */ 
/*    */   public abstract void copyFrom(IBoxSettings paramIBoxSettings);
/*    */ 
/*    */   public abstract void load(String paramString);
/*    */ 
/*    */   public abstract String export();
/*    */ 
/*    */   public abstract void export(OutputStream paramOutputStream)
/*    */     throws Exception;
/*    */ 
/*    */   public abstract void load(InputStream paramInputStream)
/*    */     throws Exception;
/*    */ 
/*    */   public abstract void dispose();
/*    */ 
/*    */   public abstract void setBorderRGB(RGB paramRGB);
/*    */ 
/*    */   public abstract Color getBorderColor();
/*    */ 
/*    */   public abstract void setBorderWidth(int paramInt);
/*    */ 
/*    */   public abstract int getBorderWidth();
/*    */ 
/*    */   public abstract void setRoundBox(boolean paramBoolean);
/*    */ 
/*    */   public abstract boolean getRoundBox();
/*    */ 
/*    */   public abstract void setHighlightRGB(RGB paramRGB);
/*    */ 
/*    */   public abstract void setHighlightWidth(int paramInt);
/*    */ 
/*    */   public abstract void setHighlightOne(boolean paramBoolean);
/*    */ 
/*    */   public abstract Color getHighlightColor();
/*    */ 
/*    */   public abstract int getHighlightWidth();
/*    */ 
/*    */   public abstract boolean getHighlightOne();
/*    */ 
/*    */   public abstract void setFillSelectedRGB(RGB paramRGB);
/*    */ 
/*    */   public abstract void setFillSelected(boolean paramBoolean);
/*    */ 
/*    */   public abstract boolean getFillSelected();
/*    */ 
/*    */   public abstract Color getFillSelectedColor();
/*    */ 
/*    */   public abstract void setBuilder(String paramString);
/*    */ 
/*    */   public abstract String getBuilder();
/*    */ 
/*    */   public abstract Color[] getColors();
/*    */ 
/*    */   public abstract void setColorsRGB(RGB[] paramArrayOfRGB);
/*    */ 
/*    */   public abstract int getColorsSize();
/*    */ 
/*    */   public abstract void setColorsSize(int paramInt);
/*    */ 
/*    */   public abstract Color getColor(int paramInt);
/*    */ 
/*    */   public abstract void setColor(int paramInt, RGB paramRGB);
/*    */ 
/*    */   public abstract void setHighlightDrawLine(boolean paramBoolean);
/*    */ 
/*    */   public abstract boolean getHighlightDrawLine();
/*    */ 
/*    */   public abstract void setBorderDrawLine(boolean paramBoolean);
/*    */ 
/*    */   public abstract boolean getBorderDrawLine();
/*    */ 
/*    */   public abstract void setFillGradient(boolean paramBoolean);
/*    */ 
/*    */   public abstract boolean getFillGradient();
/*    */ 
/*    */   public abstract void setFillGradientColorRGB(RGB paramRGB);
/*    */ 
/*    */   public abstract Color getFillGradientColor();
/*    */ 
/*    */   public abstract void setFillOnMove(boolean paramBoolean);
/*    */ 
/*    */   public abstract boolean getFillOnMove();
/*    */ 
/*    */   public abstract boolean getCirculateLevelColors();
/*    */ 
/*    */   public abstract void setCirculateLevelColors(boolean paramBoolean);
/*    */ 
/*    */   public abstract void setFillKeyModifier(String paramString);
/*    */ 
/*    */   public abstract String getFillKeyModifier();
/*    */ 
/*    */   public abstract int getFillKeyModifierSWTInt();
/*    */ 
/*    */   public abstract Color getBorderColor(int paramInt);
/*    */ 
/*    */   public abstract Color getHighlightColor(int paramInt);
/*    */ 
/*    */   public abstract void setBorderColorType(int paramInt);
/*    */ 
/*    */   public abstract int getBorderColorType();
/*    */ 
/*    */   public abstract void setHighlightColorType(int paramInt);
/*    */ 
/*    */   public abstract int getHighlightColorType();
/*    */ 
/*    */   public abstract void setBorderLineStyle(int paramInt);
/*    */ 
/*    */   public abstract void setHighlightLineStyle(int paramInt);
/*    */ 
/*    */   public abstract int getBorderLineStyle();
/*    */ 
/*    */   public abstract int getBorderLineStyleSWTInt();
/*    */ 
/*    */   public abstract int getHighlightLineStyle();
/*    */ 
/*    */   public abstract int getHighlightLineStyleSWTInt();
/*    */ 
/*    */   public abstract boolean getNoBackground();
/*    */ 
/*    */   public abstract void setNoBackground(boolean paramBoolean);
/*    */ 
/*    */   public abstract boolean getExpandBox();
/*    */ 
/*    */   public abstract void setExpandBox(boolean paramBoolean);
/*    */ 
/*    */   public abstract int getAlpha();
/*    */ 
/*    */   public abstract void setAlpha(int paramInt);
/*    */ 
/*    */   public static enum PropertiesKeys
/*    */   {
/* 15 */     ALL, Enabled, Name, BorderColor, HighlightColor, BorderWidth, HighlightWidth, RoundBox, HighlightOne, FillSelected, FillSelectedColor, Builder, Colors, Color, 
/* 16 */     HighlightDrawLine, BorderDrawLine, FillGradient, FillGradientColor, FillOnMove, CirculateLevelColors, FillKeyModifier, FileNames, HighlightColorType, BorderColorType, 
/* 17 */     HighlightLineStyle, BorderLineStyle, NoBackground, ExpandBox, Alpha;
/*    */   }
/*    */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.IBoxSettings
 * JD-Core Version:    0.6.2
 */