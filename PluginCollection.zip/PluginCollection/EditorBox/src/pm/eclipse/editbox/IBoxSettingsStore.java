package pm.eclipse.editbox;

import java.util.Set;

public abstract interface IBoxSettingsStore
{
  public abstract void setProviderId(String paramString);

  public abstract void loadDefaults(IBoxSettings paramIBoxSettings);

  public abstract void load(String paramString, IBoxSettings paramIBoxSettings);

  public abstract void saveDefaults(IBoxSettings paramIBoxSettings);

  public abstract Set<String> getCatalog();

  public abstract void remove(String paramString);
}

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.IBoxSettingsStore
 * JD-Core Version:    0.6.2
 */