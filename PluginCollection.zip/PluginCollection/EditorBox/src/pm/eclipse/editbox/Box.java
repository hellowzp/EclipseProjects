/*    */ package pm.eclipse.editbox;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.eclipse.swt.graphics.Rectangle;
/*    */ 
/*    */ public class Box
/*    */ {
/*    */   public int start;
/*    */   public int offset;
/*    */   public int end;
/*    */   public Box parent;
/*    */   public Rectangle rec;
/*    */   public boolean isOn;
/*    */   public int maxEndOffset;
/*    */   public int maxLineLen;
/*    */   public int level;
/* 17 */   public int tabsStart = -1;
/*    */   public boolean hasChildren;
/*    */   private List<Box> children;
/*    */   public Object data;
/*    */ 
/*    */   public String toString()
/*    */   {
/* 24 */     return "[" + this.start + "," + this.end + "," + this.offset + "," + this.maxEndOffset + "]";
/*    */   }
/*    */ 
/*    */   public boolean intersects(int s, int e) {
/* 28 */     return (between(s, this.start, this.end)) || (between(e, this.start, this.end)) || (between(this.start, s, e)) || (between(this.end, s, e));
/*    */   }
/*    */ 
/*    */   protected boolean between(int m, int s, int e) {
/* 32 */     return (s <= m) && (e >= m);
/*    */   }
/*    */ 
/*    */   public List<Box> children() {
/* 36 */     return this.children != null ? this.children : Collections.EMPTY_LIST;
/*    */   }
/*    */ 
/*    */   public void addChild(Box box) {
/* 40 */     if (this.children == null)
/* 41 */       this.children = new ArrayList();
/* 42 */     this.children.add(box);
/*    */   }
/*    */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.Box
 * JD-Core Version:    0.6.2
 */