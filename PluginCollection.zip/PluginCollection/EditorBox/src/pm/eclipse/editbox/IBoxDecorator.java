package pm.eclipse.editbox;

import org.eclipse.swt.custom.StyledText;

public abstract interface IBoxDecorator
{
  public abstract IBoxProvider getProvider();

  public abstract void setProvider(IBoxProvider paramIBoxProvider);

  public abstract void setStyledText(StyledText paramStyledText);

  public abstract void setSettings(IBoxSettings paramIBoxSettings);

  public abstract void enableUpdates(boolean paramBoolean);

  public abstract void decorate(boolean paramBoolean);

  public abstract void undecorate();

  public abstract void selectCurrentBox();

  public abstract void unselectCurrentBox();
}

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.IBoxDecorator
 * JD-Core Version:    0.6.2
 */