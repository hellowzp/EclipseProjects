/*    */ package pm.eclipse.editbox;
/*    */ 
/*    */ import org.eclipse.core.runtime.ILog;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.jface.preference.IPreferenceStore;
/*    */ import org.eclipse.jface.resource.ImageDescriptor;
/*    */ import org.eclipse.ui.plugin.AbstractUIPlugin;
/*    */ import org.osgi.framework.BundleContext;
/*    */ import pm.eclipse.editbox.impl.BoxProviderRegistry;
/*    */ 
/*    */ public class EditBoxActivator extends AbstractUIPlugin
/*    */ {
/*    */   private static final String ENABLED = "ENABLED";
/*    */   public static final String PLUGIN_ID = "pm.eclipse.editbox";
/*    */   private static EditBoxActivator plugin;
/*    */   private BoxProviderRegistry registry;
/*    */ 
/*    */   public void start(BundleContext context)
/*    */     throws Exception
/*    */   {
/* 25 */     super.start(context);
/* 26 */     plugin = this;
/*    */   }
/*    */ 
/*    */   public void stop(BundleContext context) throws Exception {
/* 30 */     plugin = null;
/* 31 */     super.stop(context);
/*    */   }
/*    */ 
/*    */   public static EditBoxActivator getDefault() {
/* 35 */     return plugin;
/*    */   }
/*    */ 
/*    */   public static ImageDescriptor getImageDescriptor(String path) {
/* 39 */     return imageDescriptorFromPlugin("pm.eclipse.editbox", path);
/*    */   }
/*    */ 
/*    */   public BoxProviderRegistry getProviderRegistry() {
/* 43 */     return this.registry == null ? (this.registry = new BoxProviderRegistry()) : this.registry;
/*    */   }
/*    */ 
/*    */   public boolean isEnabled() {
/* 47 */     if (getPreferenceStore().contains("ENABLED"))
/* 48 */       return getPreferenceStore().getBoolean("ENABLED");
/* 49 */     return false;
/*    */   }
/*    */ 
/*    */   public void setEnabled(boolean flag) {
/* 53 */     getPreferenceStore().setValue("ENABLED", flag);
/*    */   }
/*    */ 
/*    */   public static void logError(Object source, String msg, Throwable error) {
/* 57 */     String src = "";
/* 58 */     if ((source instanceof Class))
/* 59 */       src = ((Class)source).getName();
/* 60 */     else if (source != null)
/* 61 */       src = source.getClass().getName();
/* 62 */     getDefault().getLog().log(new Status(4, "pm.eclipse.editbox", 1, "[" + src + "] " + msg, error));
/*    */   }
/*    */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.EditBox
 * JD-Core Version:    0.6.2
 */