package pm.eclipse.editbox;

import java.util.List;

public abstract interface IBoxBuilder
{
  public abstract String getName();

  public abstract void setName(String paramString);

  public abstract void setTabSize(int paramInt);

  public abstract int getTabSize();

  public abstract void setCaretOffset(int paramInt);

  public abstract int getCaretOffset();

  public abstract void setText(StringBuilder paramStringBuilder);

  public abstract List<Box> build();
}

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.IBoxBuilder
 * JD-Core Version:    0.6.2
 */