/*     */ package pm.eclipse.editbox.impl;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import pm.eclipse.editbox.Box;
/*     */ 
/*     */ public class BoxBuilderImpl extends AbstractBoxBuilder
/*     */ {
/*     */   protected List<Box> boxes;
/*     */   protected Box currentbox;
/*     */   protected boolean emptyPrevLine;
/*     */   protected boolean lineHasStartTab;
/*     */ 
/*     */   public List<Box> build()
/*     */   {
/*  17 */     this.boxes = new LinkedList();
/*  18 */     int len = this.text.length() - 1;
/*  19 */     this.currentbox = newbox(0, len, -1, null);
/*  20 */     this.boxes.clear();
/*     */ 
/*  22 */     this.emptyPrevLine = false;
/*  23 */     int start = 0;
/*  24 */     int offset = 0;
/*  25 */     boolean startline = true;
/*  26 */     this.lineHasStartTab = false;
/*  27 */     boolean empty = true;
/*     */ 
/*  29 */     checkCarret();
/*     */ 
/*  31 */     for (int i = 0; i <= len; i++) {
/*  32 */       char c = this.text.charAt(i);
/*  33 */       boolean isWhitespace = (Character.isWhitespace(c)) && (i != this.caretOffset);
/*  34 */       empty = (empty) && (isWhitespace);
/*  35 */       if ((c == '\n') || (i == len)) {
/*  36 */         if (startline) start = i;
/*  37 */         addLine(start, i, offset, empty);
/*  38 */         startline = true;
/*  39 */         offset = 0;
/*  40 */         start = i;
/*  41 */         this.lineHasStartTab = false;
/*  42 */         empty = true;
/*     */       }
/*  44 */       else if (startline) {
/*  45 */         if (isWhitespace) {
/*  46 */           if (c == '\t') {
/*  47 */             offset += this.tabSize;
/*  48 */             this.lineHasStartTab = true;
/*     */           } else {
/*  50 */             offset++;
/*     */           }
/*     */         } else { start = i;
/*  53 */           startline = false;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  58 */     return this.boxes;
/*     */   }
/*     */ 
/*     */   private void checkCarret() {
/*  62 */     if (this.caretOffset < 0) return;
/*     */ 
/*  64 */     if ((this.caretOffset > 0) && (this.text.charAt(this.caretOffset - 1) == '\n')) {
/*  65 */       this.caretOffset = -1;
/*  66 */       return;
/*     */     }
/*     */ 
/*  69 */     int end = this.text.length();
/*  70 */     for (int i = this.caretOffset; i < end; i++) {
/*  71 */       char c = this.text.charAt(i);
/*  72 */       if (!Character.isWhitespace(c)) {
/*  73 */         this.caretOffset = -1;
/*  74 */         return;
/*     */       }
/*  76 */       if (c == '\n')
/*  77 */         return;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void addLine(int start, int end, int offset, boolean empty) {
/*  82 */     if (!empty) {
/*  83 */       addbox0(start, end, offset);
/*     */     }
/*  85 */     this.emptyPrevLine = empty;
/*     */   }
/*     */ 
/*     */   protected void addbox0(int start, int end, int offset)
/*     */   {
/*  90 */     if (offset == this.currentbox.offset) {
/*  91 */       if ((this.emptyPrevLine) && (this.currentbox.parent != null)) {
/*  92 */         this.currentbox = newbox(start, end, offset, this.currentbox.parent);
/*  93 */         updateParentEnds(this.currentbox);
/*  94 */       } else if (end > this.currentbox.end) {
/*  95 */         this.currentbox.end = end;
/*  96 */         if ((this.currentbox.tabsStart < 0) && (this.lineHasStartTab))
/*  97 */           this.currentbox.tabsStart = start;
/*  98 */         updateMaxEndOffset(start, this.currentbox);
/*  99 */         updateParentEnds(this.currentbox);
/*     */       }
/* 101 */     } else if (offset > this.currentbox.offset) {
/* 102 */       this.currentbox = newbox(start, end, offset, this.currentbox);
/* 103 */       updateParentEnds(this.currentbox);
/* 104 */     } else if (this.currentbox.parent != null) {
/* 105 */       this.currentbox = this.currentbox.parent;
/* 106 */       addbox0(start, end, offset);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void updateMaxEndOffset(int start, Box b)
/*     */   {
/* 113 */     int n = b.end - start + b.offset;
/* 114 */     if (n >= b.maxLineLen) {
/* 115 */       b.maxLineLen = n;
/* 116 */       b.maxEndOffset = b.end;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void updateParentEnds(Box box) {
/* 121 */     Box b = box.parent;
/* 122 */     while ((b != null) && (b.end < box.end)) {
/* 123 */       b.end = box.end;
/* 124 */       if (b.maxLineLen <= box.maxLineLen) {
/* 125 */         b.maxEndOffset = box.maxEndOffset;
/* 126 */         b.maxLineLen = box.maxLineLen;
/*     */       }
/* 128 */       b = b.parent;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Box newbox(int start, int end, int offset, Box parent)
/*     */   {
/* 134 */     Box box = new Box();
/* 135 */     box.end = end;
/* 136 */     box.start = start;
/* 137 */     box.offset = offset;
/* 138 */     box.parent = parent;
/* 139 */     box.maxLineLen = (end - start + offset);
/* 140 */     box.maxEndOffset = end;
/* 141 */     box.level = (parent != null ? parent.level + 1 : -1);
/* 142 */     if (this.lineHasStartTab)
/* 143 */       box.tabsStart = start;
/* 144 */     if (parent != null)
/* 145 */       parent.hasChildren = true;
/* 146 */     this.boxes.add(box);
/* 147 */     return box;
/*     */   }
/*     */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.impl.BoxBuilderImpl
 * JD-Core Version:    0.6.2
 */