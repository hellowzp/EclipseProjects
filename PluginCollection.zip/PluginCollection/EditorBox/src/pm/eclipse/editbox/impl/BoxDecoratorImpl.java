/*     */ package pm.eclipse.editbox.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.eclipse.jface.util.IPropertyChangeListener;
/*     */ import org.eclipse.jface.util.PropertyChangeEvent;
/*     */ import org.eclipse.swt.custom.StyledText;
/*     */ import org.eclipse.swt.custom.StyledTextContent;
/*     */ import org.eclipse.swt.custom.TextChangeListener;
/*     */ import org.eclipse.swt.custom.TextChangedEvent;
/*     */ import org.eclipse.swt.custom.TextChangingEvent;
/*     */ import org.eclipse.swt.events.KeyEvent;
/*     */ import org.eclipse.swt.events.KeyListener;
/*     */ import org.eclipse.swt.events.ModifyEvent;
/*     */ import org.eclipse.swt.events.ModifyListener;
/*     */ import org.eclipse.swt.events.MouseAdapter;
/*     */ import org.eclipse.swt.events.MouseEvent;
/*     */ import org.eclipse.swt.events.MouseMoveListener;
/*     */ import org.eclipse.swt.events.MouseTrackListener;
/*     */ import org.eclipse.swt.events.PaintEvent;
/*     */ import org.eclipse.swt.events.PaintListener;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.RGB;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.ColorDialog;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import pm.eclipse.editbox.Box;
/*     */ import pm.eclipse.editbox.EditBoxActivator;
/*     */ import pm.eclipse.editbox.IBoxBuilder;
/*     */ import pm.eclipse.editbox.IBoxDecorator;
/*     */ import pm.eclipse.editbox.IBoxProvider;
/*     */ import pm.eclipse.editbox.IBoxSettings;
/*     */ 
/*     */ public class BoxDecoratorImpl
/*     */   implements IBoxDecorator
/*     */ {
/*     */   protected static final int ROUND_BOX_ARC = 5;
/*     */   protected IBoxProvider provider;
/*     */   protected boolean visible;
/*     */   protected IBoxSettings settings;
/*     */   protected StyledText boxText;
/*     */   protected BoxKeyListener boxKey;
/*     */   protected BoxModifyListener boxModify;
/*     */   protected BoxPaintListener boxPaint;
/*     */   protected BoxMouseMoveListener boxMouseMove;
/*     */   protected BoxMouseTrackListener boxMouseTrack;
/*     */   protected BoxTextChangeListener boxTextChange;
/*     */   protected BoxMouseClickListener boxMouseClick;
/*     */   protected FillBoxMouseClick fillMouseClick;
/*     */   protected SettingsChangeListener settingsChangeListener;
/*     */   protected RGB oldBackground;
/*     */   protected int oldIndent;
/*     */   protected boolean decorated;
/*     */   protected List<Box> boxes;
/*     */   protected boolean setCaretOffset;
/*     */   protected String builderName;
/*     */   protected IBoxBuilder builder;
/*     */   protected Box currentBox;
/*     */   protected Point oldCaretLoc;
/*  65 */   protected int oldXOffset = -1;
/*  66 */   protected int oldYOffset = -1;
/*     */   protected Rectangle oldClientArea;
/*  68 */   protected int fillBoxStart = -1;
/*  69 */   protected int fillBoxEnd = -1;
/*  70 */   protected int fillBoxLevel = -1;
/*     */   protected int stateMask;
/*     */   public boolean keyPressed;
/*     */   protected int charCount;
/*     */ 
/*     */   public void enableUpdates(boolean flag)
/*     */   {
/*  76 */     boolean update = (flag) && (!this.visible);
/*  77 */     this.visible = flag;
/*  78 */     if (update) {
/*  79 */       this.boxes = null;
/*  80 */       update();
/*     */     }
/*     */   }
/*     */ 
/*     */   public IBoxProvider getProvider() {
/*  85 */     return this.provider;
/*     */   }
/*     */ 
/*     */   public void setProvider(IBoxProvider newProvider) {
/*  89 */     this.provider = newProvider;
/*     */   }
/*     */ 
/*     */   public void setSettings(IBoxSettings newSettings) {
/*  93 */     this.settings = newSettings;
/*  94 */     this.settingsChangeListener = new SettingsChangeListener();
/*  95 */     this.settings.addPropertyChangeListener(this.settingsChangeListener);
/*     */   }
/*     */ 
/*     */   public void setStyledText(StyledText newSt) {
/*  99 */     this.boxText = newSt;
/*     */   }
/*     */ 
/*     */   protected void buildBoxes() {
/* 103 */     IBoxBuilder boxBuilder = getBuilder();
/* 104 */     if (boxBuilder == null) {
/* 105 */       return;
/*     */     }
/* 107 */     this.builder.setTabSize(this.boxText.getTabs());
/* 108 */     this.builder.setCaretOffset(this.setCaretOffset ? this.boxText.getCaretOffset() : -1);
/* 109 */     this.setCaretOffset = false;
/*     */ 
/* 111 */     StringBuilder text = new StringBuilder(this.boxText.getText());
/*     */ 
/* 113 */     if ((text.length() > 0) && (text.charAt(text.length() - 1) != '\n')) {
/* 114 */       text.append(".");
/*     */     }
/* 116 */     boxBuilder.setText(text);
/* 117 */     this.boxes = boxBuilder.build();
/*     */ 
/* 119 */     this.charCount = this.boxText.getCharCount();
/*     */   }
/*     */ 
/*     */   protected void updateOffsetColors() {
/* 123 */     int maxLevel = 0;
/* 124 */     for (Box b : this.boxes)
/* 125 */       if (b.level > maxLevel)
/* 126 */         maxLevel = b.level;
/* 127 */     this.settings.setColorsSize(maxLevel + 2);
/*     */   }
/*     */ 
/*     */   protected IBoxBuilder getBuilder() {
/* 131 */     if (this.settings.getBuilder() == null)
/* 132 */       return null;
/* 133 */     if ((this.builder == null) || (this.builderName == null) || (!this.builderName.equals(this.settings.getBuilder()))) {
/* 134 */       this.builderName = this.settings.getBuilder();
/* 135 */       this.builder = this.provider.createBoxBuilder(this.builderName);
/*     */     }
/* 137 */     return this.builder;
/*     */   }
/*     */ 
/*     */   protected void update() {
/* 141 */     if ((this.decorated) && (this.visible)) {
/* 142 */       if ((this.builder != null) && ((!this.builderName.equals(this.settings.getBuilder())) || (this.builder.getTabSize() != this.boxText.getTabs()))) {
/* 143 */         this.boxes = null;
/*     */       }
/* 145 */       if (this.boxes == null) {
/* 146 */         buildBoxes();
/*     */       }
/* 148 */       offsetMoved();
/* 149 */       updateCaret();
/* 150 */       drawBackgroundBoxes();
/*     */     }
/*     */   }
/*     */ 
/*     */   void drawBackgroundBoxes() {
/* 155 */     if ((this.boxes == null) || (!this.visible)) {
/* 156 */       return;
/*     */     }
/* 158 */     Rectangle r0 = this.boxText.getClientArea();
/*     */ 
/* 160 */     if ((r0.width < 1) || (r0.height < 1)) {
/* 161 */       return;
/*     */     }
/* 163 */     int xOffset = this.boxText.getHorizontalPixel();
/* 164 */     int yOffset = this.boxText.getTopPixel();
/*     */ 
/* 166 */     Image newImage = new Image(null, r0.width, r0.height);
/* 167 */     GC gc = new GC(newImage);
/*     */ 
/* 170 */     Color bc = this.settings.getColor(0);
/* 171 */     if ((this.settings.getNoBackground()) && (this.oldBackground != null))
/* 172 */       bc = new Color(null, this.oldBackground);
/* 173 */     if (bc != null) {
/* 174 */       Rectangle rec = newImage.getBounds();
/* 175 */       fillRectangle(bc, gc, rec.x, rec.y, rec.width, rec.height);
/*     */     }
/*     */ 
/* 178 */     if (this.settings.getAlpha() > 0) {
/* 179 */       gc.setAlpha(this.settings.getAlpha());
/*     */     }
/*     */ 
/* 182 */     Box fillBox = null;
/* 183 */     boolean checkFillbox = !this.settings.getFillOnMove();
/* 184 */     Collection visibleBoxes = visibleBoxes();
/*     */ 
/* 186 */     boolean ex = this.settings.getExpandBox();
/*     */ 
/* 188 */     for (Box b : visibleBoxes) {
/* 189 */       if ((checkFillbox) && (b.level == this.fillBoxLevel) && (b.start <= this.fillBoxStart) && (b.end >= this.fillBoxEnd))
/* 190 */         fillBox = b;
/* 191 */       fillRectangle(this.settings.getColor(b.level + 1), gc, b.rec.x - xOffset, b.rec.y - yOffset, ex ? r0.width : b.rec.width, b.rec.height);
/*     */     }
/*     */ 
/* 195 */     if (this.settings.getFillSelected()) {
/* 196 */       if ((this.settings.getFillOnMove()) && (this.currentBox != null) && (this.stateMask == this.settings.getFillKeyModifierSWTInt()))
/* 197 */         fillRectangle(this.settings.getFillSelectedColor(), gc, this.currentBox.rec.x - xOffset, this.currentBox.rec.y - yOffset, ex ? r0.width : this.currentBox.rec.width + 1, this.currentBox.rec.height + 1);
/* 198 */       else if (fillBox != null) {
/* 199 */         fillRectangle(this.settings.getFillSelectedColor(), gc, fillBox.rec.x - xOffset, fillBox.rec.y - yOffset, ex ? r0.width : fillBox.rec.width + 1, fillBox.rec.height + 1);
/*     */       }
/*     */     }
/* 202 */     for (Box b : visibleBoxes) {
/* 203 */       if (!b.isOn)
/* 204 */         drawBox(gc, yOffset, xOffset, b, r0.width);
/*     */     }
/* 206 */     for (Box b : visibleBoxes) {
/* 207 */       if (b.isOn)
/* 208 */         drawBox(gc, yOffset, xOffset, b, r0.width);
/*     */     }
/* 210 */     Image oldImage = this.boxText.getBackgroundImage();
/* 211 */     this.boxText.setBackgroundImage(newImage);
/* 212 */     if (oldImage != null)
/* 213 */       oldImage.dispose();
/* 214 */     gc.dispose();
/*     */ 
/* 216 */     this.oldClientArea = r0;
/* 217 */     this.oldXOffset = xOffset;
/* 218 */     this.oldYOffset = yOffset;
/*     */   }
/*     */ 
/*     */   protected void drawBox(GC gc, int yOffset, int xOffset, Box b, int exWidth) {
/* 222 */     drawRect(gc, b, b.rec.x - xOffset, b.rec.y - yOffset, this.settings.getExpandBox() ? exWidth : b.rec.width, b.rec.height);
/*     */   }
/*     */ 
/*     */   private void drawRect(GC gc, Box b, int x, int y, int width, int height) {
/* 226 */     if ((b.isOn) && (this.settings.getHighlightWidth() > 0) && (this.settings.getHighlightColor(b.level) != null)) {
/* 227 */       gc.setLineStyle(this.settings.getHighlightLineStyleSWTInt());
/* 228 */       gc.setLineWidth(this.settings.getHighlightWidth());
/* 229 */       gc.setForeground(this.settings.getHighlightColor(b.level));
/* 230 */       if (this.settings.getHighlightDrawLine()) {
/* 231 */         gc.drawLine(x, y, x, y + b.rec.height);
/*     */       }
/*     */       else
/*     */       {
/* 237 */         drawRectangle(gc, x, y, width, height);
/*     */       }
/* 239 */     } else if ((!b.isOn) && (this.settings.getBorderWidth() > 0) && (this.settings.getBorderColor(b.level) != null)) {
/* 240 */       gc.setLineStyle(this.settings.getBorderLineStyleSWTInt());
/* 241 */       gc.setLineWidth(this.settings.getBorderWidth());
/* 242 */       gc.setForeground(this.settings.getBorderColor(b.level));
/* 243 */       if (this.settings.getBorderDrawLine())
/* 244 */         gc.drawLine(x, y + 1, x, y + b.rec.height - 1);
/*     */       else
/* 246 */         drawRectangle(gc, x, y, width, height);
/*     */     }
/*     */   }
/*     */ 
/*     */   void drawRectangle(GC gc, int x, int y, int width, int height)
/*     */   {
/* 252 */     if (this.settings.getRoundBox())
/* 253 */       gc.drawRoundRectangle(x, y, width, height, 5, 5);
/*     */     else
/* 255 */       gc.drawRectangle(x, y, width, height);
/*     */   }
/*     */ 
/*     */   void fillRectangle(Color c, GC gc, int x, int y, int width, int height) {
/* 259 */     if (c == null) {
/* 260 */       return;
/*     */     }
/* 262 */     gc.setBackground(c);
/* 263 */     if (this.settings.getRoundBox()) {
/* 264 */       gc.fillRoundRectangle(x, y, width, height, 5, 5);
/*     */     }
/* 267 */     else if ((this.settings.getFillGradient()) && (this.settings.getFillGradientColor() != null)) {
/* 268 */       gc.setBackground(this.settings.getFillGradientColor());
/* 269 */       gc.setForeground(c);
/* 270 */       gc.fillGradientRectangle(x, y, width, height, false);
/*     */     } else {
/* 272 */       gc.fillRectangle(x, y, width, height);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void decorate(boolean mouseDbClickColorChange)
/*     */   {
/* 278 */     this.decorated = false;
/* 279 */     if ((this.boxText == null) || (this.settings == null)) {
/* 280 */       return;
/*     */     }
/* 282 */     this.boxPaint = new BoxPaintListener();
/* 283 */     this.boxMouseMove = new BoxMouseMoveListener();
/* 284 */     this.boxMouseTrack = new BoxMouseTrackListener();
/* 285 */     this.boxTextChange = new BoxTextChangeListener();
/* 286 */     this.fillMouseClick = new FillBoxMouseClick();
/* 287 */     this.boxKey = new BoxKeyListener(null);
/* 288 */     this.boxModify = new BoxModifyListener(null);
/*     */ 
/* 290 */     if (mouseDbClickColorChange) {
/* 291 */       this.boxMouseClick = new BoxMouseClickListener();
/*     */     }
/* 293 */     Color c = this.boxText.getBackground();
/* 294 */     if (c != null)
/* 295 */       this.oldBackground = c.getRGB();
/* 296 */     this.oldIndent = this.boxText.getIndent();
/* 297 */     if (this.oldIndent < 3)
/* 298 */       this.boxText.setIndent(3);
/* 299 */     this.boxText.addPaintListener(this.boxPaint);
/* 300 */     this.boxText.addMouseMoveListener(this.boxMouseMove);
/* 301 */     this.boxText.addMouseTrackListener(this.boxMouseTrack);
/* 302 */     this.boxText.getContent().addTextChangeListener(this.boxTextChange);
/* 303 */     this.boxText.addMouseListener(this.fillMouseClick);
/* 304 */     this.boxText.addModifyListener(this.boxModify);
/* 305 */     this.boxText.addKeyListener(this.boxKey);
/*     */ 
/* 307 */     if (mouseDbClickColorChange) {
/* 308 */       this.boxText.addMouseListener(this.boxMouseClick);
/*     */     }
/* 310 */     this.decorated = true;
/*     */   }
/*     */ 
/*     */   public void undecorate() {
/* 314 */     if ((this.boxText == null) && (!this.decorated))
/* 315 */       return;
/* 316 */     this.decorated = false;
/* 317 */     if (this.boxMouseClick != null)
/* 318 */       this.boxText.removeMouseListener(this.boxMouseClick);
/* 319 */     this.boxText.getContent().removeTextChangeListener(this.boxTextChange);
/* 320 */     this.boxText.removeMouseTrackListener(this.boxMouseTrack);
/* 321 */     this.boxText.removeMouseMoveListener(this.boxMouseMove);
/* 322 */     this.boxText.removePaintListener(this.boxPaint);
/* 323 */     this.boxText.removeMouseListener(this.fillMouseClick);
/* 324 */     this.boxText.removeModifyListener(this.boxModify);
/* 325 */     this.boxText.removeKeyListener(this.boxKey);
/* 326 */     this.boxText.setIndent(this.oldIndent);
/* 327 */     this.boxText.setBackgroundImage(null);
/* 328 */     if (this.oldBackground != null)
/* 329 */       this.boxText.setBackground(new Color(null, this.oldBackground));
/*     */     else
/* 331 */       this.boxText.setBackground(null);
/* 332 */     if (this.settingsChangeListener != null)
/* 333 */       this.settings.removePropertyChangeListener(this.settingsChangeListener);
/*     */   }
/*     */ 
/*     */   protected Collection<Box> visibleBoxes() {
/* 337 */     Rectangle r0 = this.boxText.getClientArea();
/* 338 */     int start = this.boxText.getHorizontalIndex() + this.boxText.getOffsetAtLine(this.boxText.getTopIndex());
/* 339 */     int end = this.boxText.getCharCount() - 1;
/* 340 */     int lineIndex = this.boxText.getLineIndex(r0.height);
/* 341 */     if (lineIndex < this.boxText.getLineCount() - 1) {
/* 342 */       end = this.boxText.getOffsetAtLine(lineIndex);
/*     */     }
/* 344 */     List result = new ArrayList();
/* 345 */     for (Box b : this.boxes) {
/* 346 */       if (b.intersects(start, end))
/* 347 */         result.add(b);
/*     */     }
/* 349 */     calcBounds(result);
/* 350 */     return result;
/*     */   }
/*     */ 
/*     */   protected void calcBounds(Collection<Box> boxes0) {
/* 354 */     int yOffset = this.boxText.getTopPixel();
/* 355 */     int xOffset = this.boxText.getHorizontalPixel();
/* 356 */     for (Box b : boxes0)
/* 357 */       if (b.rec == null) {
/* 358 */         Point s = this.boxText.getLocationAtOffset(b.start);
/* 359 */         if ((b.tabsStart > -1) && (b.tabsStart != b.start)) {
/* 360 */           Point s1 = this.boxText.getLocationAtOffset(b.tabsStart);
/* 361 */           if (s1.x < s.x)
/* 362 */             s.x = s1.x;
/*     */         }
/* 364 */         Point e = this.boxText.getLocationAtOffset(b.end);
/* 365 */         if (b.end != b.maxEndOffset) {
/* 366 */           Point e1 = this.boxText.getLocationAtOffset(b.maxEndOffset);
/* 367 */           e.x = e1.x;
/*     */         }
/* 369 */         Rectangle rec2 = new Rectangle(s.x + xOffset - 2, s.y + yOffset - 1, e.x - s.x + 6, e.y - s.y + this.boxText.getLineHeight(b.end));
/* 370 */         b.rec = rec2;
/* 371 */         updateWidth(b);
/* 372 */         updateWidth3(b);
/*     */       }
/*     */   }
/*     */ 
/*     */   void updateWidth(Box b)
/*     */   {
/* 378 */     Box p = b.parent;
/* 379 */     while ((p != null) && (p.rec != null) && (p.rec.x + p.rec.width <= b.rec.x + b.rec.width)) {
/* 380 */       p.rec.width += 5;
/* 381 */       b = p;
/* 382 */       p = p.parent;
/*     */     }
/*     */   }
/*     */ 
/*     */   void updateWidth3(Box b) {
/* 387 */     Box p = b.parent;
/* 388 */     while ((p != null) && (p.rec != null) && (p.rec.x >= b.rec.x)) {
/* 389 */       p.rec.width += p.rec.x - b.rec.x + 3;
/* 390 */       p.rec.x = (b.rec.x - 3 > 0 ? b.rec.x - 3 : 0);
/* 391 */       b = p;
/* 392 */       p = p.parent;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean turnOnBox(int x0, int y0) {
/* 397 */     if ((this.boxes == null) || (!this.visible)) {
/* 398 */       return false;
/*     */     }
/* 400 */     int x = x0 + this.boxText.getHorizontalPixel();
/* 401 */     int y = y0 + this.boxText.getTopPixel();
/*     */ 
/* 403 */     return this.settings.getHighlightOne() ? turnOnOne(x, y) : turnOnAll(x, y);
/*     */   }
/*     */ 
/*     */   protected boolean turnOnAll(int x, int y) {
/* 407 */     boolean redraw = false;
/*     */ 
/* 409 */     Box newCurrent = null;
/* 410 */     for (Box b : visibleBoxes()) {
/* 411 */       if (contains(b.rec, x, y)) {
/* 412 */         if (!b.isOn) {
/* 413 */           b.isOn = true;
/* 414 */           redraw = true;
/*     */         }
/* 416 */         if ((newCurrent == null) || (newCurrent.offset < b.offset))
/* 417 */           newCurrent = b;
/* 418 */       } else if (b.isOn) {
/* 419 */         b.isOn = false;
/* 420 */         redraw = true;
/*     */       }
/*     */     }
/* 423 */     if (!redraw)
/* 424 */       redraw = newCurrent != this.currentBox;
/* 425 */     this.currentBox = newCurrent;
/*     */ 
/* 427 */     return redraw;
/*     */   }
/*     */ 
/*     */   protected boolean turnOnOne(int x, int y) {
/* 431 */     Box newCurrent = null;
/* 432 */     for (Box b : visibleBoxes()) {
/* 433 */       if (contains(b.rec, x, y))
/* 434 */         newCurrent = b;
/* 435 */       b.isOn = false;
/*     */     }
/* 437 */     if (newCurrent != null)
/* 438 */       newCurrent.isOn = true;
/* 439 */     boolean redraw = newCurrent != this.currentBox;
/* 440 */     this.currentBox = newCurrent;
/* 441 */     return redraw;
/*     */   }
/*     */ 
/*     */   private boolean contains(Rectangle rec, int x, int y) {
/* 445 */     return (x >= rec.x) && (y >= rec.y) && (x - rec.x < rec.width) && (y - rec.y < rec.height);
/*     */   }
/*     */ 
/*     */   boolean redrawIfClientAreaChanged() {
/* 449 */     if ((this.oldClientArea == null) || (!this.oldClientArea.equals(this.boxText.getClientArea()))) {
/* 450 */       drawBackgroundBoxes();
/* 451 */       return true;
/*     */     }
/* 453 */     return false;
/*     */   }
/*     */ 
/*     */   void updateCaret() {
/* 457 */     this.oldCaretLoc = this.boxText.getLocationAtOffset(this.boxText.getCaretOffset());
/* 458 */     turnOnBox(this.oldCaretLoc.x > 0 ? this.oldCaretLoc.x - 1 : this.oldCaretLoc.x, this.oldCaretLoc.y);
/*     */   }
/*     */ 
/*     */   public boolean offsetMoved() {
/* 462 */     int yOffset = this.boxText.getTopPixel();
/* 463 */     int xOffset = this.boxText.getHorizontalPixel();
/* 464 */     if ((xOffset != this.oldXOffset) || (yOffset != this.oldYOffset)) {
/* 465 */       this.oldXOffset = xOffset;
/* 466 */       this.oldYOffset = yOffset;
/* 467 */       return true;
/*     */     }
/* 469 */     return false;
/*     */   }
/*     */ 
/*     */   protected void carretMoved() {
/* 473 */     Point newLoc = this.boxText.getLocationAtOffset(this.boxText.getCaretOffset());
/* 474 */     if ((this.boxes != null) && ((this.oldCaretLoc == null) || (!this.oldCaretLoc.equals(newLoc)))) {
/* 475 */       this.oldCaretLoc = newLoc;
/* 476 */       boolean build = false;
/* 477 */       if ((!this.setCaretOffset) && (this.builder != null) && (this.builder.getCaretOffset() > -1) && (this.builder.getCaretOffset() != this.boxText.getCaretOffset())) {
/* 478 */         buildBoxes();
/* 479 */         build = true;
/*     */       }
/* 481 */       if ((turnOnBox(this.oldCaretLoc.x > 0 ? this.oldCaretLoc.x - 1 : this.oldCaretLoc.x, this.oldCaretLoc.y)) || (build))
/* 482 */         drawBackgroundBoxes();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void selectCurrentBox()
/*     */   {
/* 669 */     if ((this.decorated) && (this.visible) && (this.boxes != null)) {
/* 670 */       Box b = null;
/* 671 */       Point p = this.boxText.getSelection();
/* 672 */       if ((p == null) || (p.x == p.y))
/* 673 */         b = this.currentBox;
/*     */       else {
/* 675 */         for (Box box : this.boxes)
/* 676 */           if ((p.x <= box.start) && (p.y >= box.end - 1)) {
/* 677 */             b = box.parent;
/* 678 */             break;
/*     */           }
/*     */       }
/* 681 */       if (b != null) {
/* 682 */         int end = Character.isWhitespace(this.boxText.getText(b.end - 1, b.end - 1).charAt(0)) ? b.end - 1 : b.end;
/* 683 */         this.boxText.setSelection(b.start, end);
/* 684 */         Event event = new Event();
/* 685 */         event.x = b.start;
/* 686 */         event.y = end;
/* 687 */         this.boxText.notifyListeners(13, event);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void unselectCurrentBox() {
/* 693 */     this.boxText.setSelection(this.boxText.getCaretOffset());
/*     */   }
/*     */ 
/*     */   private final class BoxKeyListener
/*     */     implements KeyListener
/*     */   {
/*     */     private BoxKeyListener()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void keyReleased(KeyEvent e)
/*     */     {
/* 502 */       BoxDecoratorImpl.this.keyPressed = true;
/* 503 */       BoxDecoratorImpl.this.carretMoved();
/*     */     }
/*     */ 
/*     */     public void keyPressed(KeyEvent e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private final class BoxModifyListener
/*     */     implements ModifyListener
/*     */   {
/*     */     private BoxModifyListener()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void modifyText(ModifyEvent e)
/*     */     {
/* 491 */       if (BoxDecoratorImpl.this.boxes == null) {
/* 492 */         BoxDecoratorImpl.this.buildBoxes();
/* 493 */         BoxDecoratorImpl.this.updateCaret();
/* 494 */         BoxDecoratorImpl.this.drawBackgroundBoxes();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   class BoxMouseClickListener extends MouseAdapter
/*     */   {
/*     */     BoxMouseClickListener()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void mouseDoubleClick(MouseEvent e)
/*     */     {
/* 597 */       int x = e.x + BoxDecoratorImpl.this.boxText.getHorizontalPixel();
/* 598 */       int y = e.y + BoxDecoratorImpl.this.boxText.getTopPixel();
/*     */ 
/* 600 */       int level = -1;
/* 601 */       for (Box b : BoxDecoratorImpl.this.visibleBoxes())
/* 602 */         if ((BoxDecoratorImpl.this.contains(b.rec, x, y)) && 
/* 603 */           (level < b.level))
/* 604 */           level = b.level;
/* 605 */       level++;
/*     */ 
/* 607 */       ColorDialog colorDialog = new ColorDialog(BoxDecoratorImpl.this.boxText.getShell());
/* 608 */       Color oldColor1 = BoxDecoratorImpl.this.settings.getColor(level);
/* 609 */       if (oldColor1 != null) {
/* 610 */         colorDialog.setRGB(oldColor1.getRGB());
/*     */       }
/* 612 */       BoxDecoratorImpl.this.settings.setColor(level, colorDialog.open());
/*     */     }
/*     */   }
/*     */ 
/*     */   class BoxMouseMoveListener
/*     */     implements MouseMoveListener
/*     */   {
/*     */     BoxMouseMoveListener()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void mouseMove(MouseEvent e)
/*     */     {
/* 546 */       BoxDecoratorImpl.this.stateMask = e.stateMask;
/* 547 */       if (BoxDecoratorImpl.this.turnOnBox(e.x, e.y))
/* 548 */         BoxDecoratorImpl.this.drawBackgroundBoxes(); 
/*     */     }
/*     */   }
/*     */ 
/*     */   class BoxMouseTrackListener implements MouseTrackListener {
/*     */     BoxMouseTrackListener() {
/*     */     }
/*     */ 
/*     */     public void mouseEnter(MouseEvent e) {
/*     */     }
/*     */ 
/* 559 */     public void mouseExit(MouseEvent e) { boolean redraw = false;
/* 560 */       if (BoxDecoratorImpl.this.boxes != null) {
/* 561 */         for (Box b : BoxDecoratorImpl.this.boxes)
/* 562 */           if (b.isOn) {
/* 563 */             redraw = true;
/* 564 */             b.isOn = false;
/*     */           }
/*     */       }
/* 567 */       if (redraw)
/* 568 */         BoxDecoratorImpl.this.drawBackgroundBoxes();
/*     */     }
/*     */ 
/*     */     public void mouseHover(MouseEvent e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   class BoxPaintListener
/*     */     implements PaintListener
/*     */   {
/*     */     volatile boolean paintMode;
/*     */ 
/*     */     BoxPaintListener()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void paintControl(PaintEvent e)
/*     */     {
/* 520 */       if (this.paintMode)
/* 521 */         return;
/* 522 */       this.paintMode = true;
/*     */       try
/*     */       {
/* 525 */         if ((BoxDecoratorImpl.this.boxes == null) || (BoxDecoratorImpl.this.charCount != BoxDecoratorImpl.this.boxText.getCharCount())) {
/* 526 */           BoxDecoratorImpl.this.buildBoxes();
/* 527 */           BoxDecoratorImpl.this.updateCaret();
/* 528 */           BoxDecoratorImpl.this.drawBackgroundBoxes();
/* 529 */         } else if (BoxDecoratorImpl.this.offsetMoved()) {
/* 530 */           BoxDecoratorImpl.this.updateCaret();
/* 531 */           BoxDecoratorImpl.this.drawBackgroundBoxes();
/*     */         } else {
/* 533 */           BoxDecoratorImpl.this.redrawIfClientAreaChanged();
/*     */         }
/*     */       } catch (Throwable t) {
/* 536 */         EditBoxActivator.logError(this, "Box paint error", t);
/*     */       } finally {
/* 538 */         this.paintMode = false;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   class BoxSettingsPropertyListner
/*     */     implements IPropertyChangeListener
/*     */   {
/*     */     BoxSettingsPropertyListner()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void propertyChange(PropertyChangeEvent event)
/*     */     {
/* 663 */       BoxDecoratorImpl.this.update();
/*     */     }
/*     */   }
/*     */ 
/*     */   class BoxTextChangeListener
/*     */     implements TextChangeListener
/*     */   {
/*     */     BoxTextChangeListener()
/*     */     {
/*     */     }
/*     */ 
/*     */     private void change()
/*     */     {
/* 578 */       BoxDecoratorImpl.this.boxes = null;
/* 579 */       BoxDecoratorImpl.this.setCaretOffset = true;
/*     */     }
/*     */ 
/*     */     public void textChanged(TextChangedEvent event) {
/* 583 */       change();
/*     */     }
/*     */ 
/*     */     public void textChanging(TextChangingEvent event) {
/*     */     }
/*     */ 
/*     */     public void textSet(TextChangedEvent event) {
/* 590 */       change();
/*     */     }
/*     */   }
/*     */ 
/*     */   class FillBoxMouseClick extends MouseAdapter
/*     */   {
/*     */     FillBoxMouseClick()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void mouseDown(MouseEvent e)
/*     */     {
/* 621 */       if ((e.button != 1) || (BoxDecoratorImpl.this.settings.getFillOnMove()) || (e.stateMask != BoxDecoratorImpl.this.settings.getFillKeyModifierSWTInt())) {
/* 622 */         if (BoxDecoratorImpl.this.keyPressed) {
/* 623 */           BoxDecoratorImpl.this.keyPressed = false;
/* 624 */           BoxDecoratorImpl.this.carretMoved();
/*     */         }
/* 626 */         return;
/*     */       }
/*     */ 
/* 629 */       int x = e.x + BoxDecoratorImpl.this.boxText.getHorizontalPixel();
/* 630 */       int y = e.y + BoxDecoratorImpl.this.boxText.getTopPixel();
/*     */ 
/* 632 */       Box fillBox = null;
/* 633 */       for (Box b : BoxDecoratorImpl.this.visibleBoxes()) {
/* 634 */         if (BoxDecoratorImpl.this.contains(b.rec, x, y))
/* 635 */           fillBox = b;
/*     */       }
/* 637 */       if ((fillBox != null) && ((fillBox.end != BoxDecoratorImpl.this.fillBoxEnd) || (fillBox.start != BoxDecoratorImpl.this.fillBoxStart) || (fillBox.level != BoxDecoratorImpl.this.fillBoxLevel))) {
/* 638 */         BoxDecoratorImpl.this.fillBoxEnd = fillBox.end;
/* 639 */         BoxDecoratorImpl.this.fillBoxLevel = fillBox.level;
/* 640 */         BoxDecoratorImpl.this.fillBoxStart = fillBox.start;
/*     */       } else {
/* 642 */         BoxDecoratorImpl.this.fillBoxEnd = -1;
/* 643 */         BoxDecoratorImpl.this.fillBoxStart = -1;
/* 644 */         BoxDecoratorImpl.this.fillBoxLevel = -1;
/*     */       }
/*     */ 
/* 647 */       if (BoxDecoratorImpl.this.keyPressed) {
/* 648 */         BoxDecoratorImpl.this.keyPressed = false;
/* 649 */         Point newLoc = BoxDecoratorImpl.this.boxText.getLocationAtOffset(BoxDecoratorImpl.this.boxText.getCaretOffset());
/* 650 */         if ((BoxDecoratorImpl.this.oldCaretLoc == null) || (!BoxDecoratorImpl.this.oldCaretLoc.equals(newLoc))) {
/* 651 */           BoxDecoratorImpl.this.buildBoxes();
/* 652 */           BoxDecoratorImpl.this.oldCaretLoc = newLoc;
/*     */         }
/*     */       }
/*     */ 
/* 656 */       BoxDecoratorImpl.this.drawBackgroundBoxes();
/*     */     }
/*     */   }
/*     */ 
/*     */   class SettingsChangeListener
/*     */     implements IPropertyChangeListener
/*     */   {
/*     */     SettingsChangeListener()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void propertyChange(PropertyChangeEvent event)
/*     */     {
/* 512 */       BoxDecoratorImpl.this.update();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.impl.BoxDecoratorImpl
 * JD-Core Version:    0.6.2
 */