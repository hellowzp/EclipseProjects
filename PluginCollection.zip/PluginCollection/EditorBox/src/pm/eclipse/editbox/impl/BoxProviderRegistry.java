/*     */ package pm.eclipse.editbox.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.eclipse.jface.preference.IPreferenceStore;
/*     */ import org.eclipse.ui.IPartListener2;
/*     */ import org.eclipse.ui.IPartService;
/*     */ import org.eclipse.ui.IWorkbenchPart;
/*     */ import pm.eclipse.editbox.EditBoxActivator;
/*     */ import pm.eclipse.editbox.IBoxDecorator;
/*     */ import pm.eclipse.editbox.IBoxProvider;
/*     */ import pm.eclipse.editbox.IBoxSettings;
/*     */ 
/*     */ public class BoxProviderRegistry
/*     */ {
/*     */   private static final String PROIVDERS = "proivders";
/*     */   private static final String PROVIDER_ID_ = "pm.eclipse.editbox.provider.";
/*     */   protected Collection<IBoxProvider> providers;
/*     */   protected Map<IWorkbenchPart, IBoxDecorator> decorators;
/*     */   protected Map<IPartService, IPartListener2> partListeners;
/*     */ 
/*     */   public Collection<IBoxProvider> getBoxProviders()
/*     */   {
/*  29 */     if (this.providers == null)
/*  30 */       this.providers = loadProviders();
/*  31 */     if (this.providers == null)
/*  32 */       this.providers = defaultProviders();
/*  33 */     return this.providers;
/*     */   }
/*     */ 
/*     */   protected Collection<IBoxProvider> loadProviders() {
/*  37 */     List result = null;
/*  38 */     String pSetting = EditBoxActivator.getDefault().getPreferenceStore().getString("proivders");
/*  39 */     if ((pSetting != null) && (pSetting.length() > 0)) {
/*  40 */       String[] split = pSetting.split(",");
/*  41 */       if (split.length > 0)
/*  42 */         result = new ArrayList();
/*  43 */       for (String s : split)
/*  44 */         if (s.trim().length() > 0)
/*  45 */           result.add(createProvider(s.trim()));
/*     */     }
/*  47 */     return result;
/*     */   }
/*     */ 
/*     */   public void setProvideres(Collection<IBoxProvider> newProviders) {
/*  51 */     this.providers = newProviders;
/*     */   }
/*     */ 
/*     */   public void storeProviders() {
/*  55 */     if (this.providers != null) {
/*  56 */       StringBuilder sb = new StringBuilder();
/*  57 */       for (IBoxProvider p : this.providers) {
/*  58 */         if (sb.length() != 0) sb.append(",");
/*  59 */         sb.append(p.getName());
/*     */       }
/*  61 */       EditBoxActivator.getDefault().getPreferenceStore().setValue("proivders", sb.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Collection<IBoxProvider> defaultProviders() {
/*  66 */     List result = new ArrayList();
/*     */ 
/*  68 */     result.add(javaProvider());
/*  69 */     result.add(pythonProvider());
/*  70 */     result.add(markupProvider());
/*  71 */     result.add(textProvider());
/*  72 */     return result;
/*     */   }
/*     */ 
/*     */   protected BoxProviderImpl createProvider(String name) {
/*  76 */     BoxProviderImpl provider = new BoxProviderImpl();
/*  77 */     provider.setId("pm.eclipse.editbox.provider." + name);
/*  78 */     provider.setName(name);
/*  79 */     provider.setBuilders(defaultBuilders());
/*  80 */     provider.setDefaultSettingsCatalog(Arrays.asList(new String[] { "Default" }));
/*  81 */     return provider;
/*     */   }
/*     */ 
/*     */   protected BoxProviderImpl markupProvider() {
/*  85 */     BoxProviderImpl provider = createProvider("markup");
/*  86 */     if (provider.getEditorsBoxSettings().getFileNames() == null)
/*  87 */       provider.getEditorsBoxSettings().setFileNames(Arrays.asList(new String[] { "*.*ml", "*.jsp" }));
/*  88 */     return provider;
/*     */   }
/*     */ 
/*     */   protected BoxProviderImpl javaProvider() {
/*  92 */     BoxProviderImpl provider = createProvider("java");
/*  93 */     provider.setDefaultSettingsCatalog(Arrays.asList(new String[] { "Default", "OnClick", "GreyGradient", "Java_v_20", "PaleBlue", "Wock" }));
/*  94 */     if (provider.getEditorsBoxSettings().getFileNames() == null)
/*  95 */       provider.getEditorsBoxSettings().setFileNames(Arrays.asList(new String[] { "*.java", "*.class" }));
/*  96 */     return provider;
/*     */   }
/*     */ 
/*     */   protected BoxProviderImpl pythonProvider() {
/* 100 */     BoxProviderImpl provider = createProvider("python");
/* 101 */     provider.setDefaultSettingsCatalog(Arrays.asList(new String[] { "Default", "Whitebox" }));
/* 102 */     if (provider.getEditorsBoxSettings().getFileNames() == null)
/* 103 */       provider.getEditorsBoxSettings().setFileNames(Arrays.asList(new String[] { "*.py" }));
/* 104 */     return provider;
/*     */   }
/*     */ 
/*     */   protected BoxProviderImpl textProvider() {
/* 108 */     BoxProviderImpl provider = createProvider("text");
/* 109 */     provider.setDefaultSettingsCatalog(Arrays.asList(new String[] { "Default", "Whitebox" }));
/* 110 */     if (provider.getEditorsBoxSettings().getFileNames() == null)
/* 111 */       provider.getEditorsBoxSettings().setFileNames(Arrays.asList(new String[] { "*.txt", "*.*" }));
/* 112 */     return provider;
/*     */   }
/*     */ 
/*     */   protected Map<String, Class> defaultBuilders() {
/* 116 */     Map result = new HashMap();
/* 117 */     result.put("Text", BoxBuilderImpl.class);
/* 118 */     result.put("Java", JavaBoxBuilder.class);
/* 119 */     result.put("Markup", MarkupBuilder2.class);
/* 120 */     result.put("Text2", TextBoxBuilder.class);
/* 121 */     return result;
/*     */   }
/*     */ 
/*     */   public IBoxDecorator getDecorator(IWorkbenchPart part) {
/* 125 */     return (IBoxDecorator)getDecorators().get(part);
/*     */   }
/*     */ 
/*     */   protected Map<IWorkbenchPart, IBoxDecorator> getDecorators() {
/* 129 */     if (this.decorators == null)
/* 130 */       this.decorators = new HashMap();
/* 131 */     return this.decorators;
/*     */   }
/*     */ 
/*     */   public IBoxDecorator removeDecorator(IWorkbenchPart part) {
/* 135 */     return (IBoxDecorator)getDecorators().remove(part);
/*     */   }
/*     */ 
/*     */   public void addDecorator(IBoxDecorator decorator, IWorkbenchPart part) {
/* 139 */     getDecorators().put(part, decorator);
/*     */   }
/*     */ 
/*     */   public void releaseDecorators() {
/* 143 */     if (this.decorators != null) {
/* 144 */       for (Map.Entry e : this.decorators.entrySet())
/* 145 */         ((IBoxDecorator)e.getValue()).getProvider().releaseDecorator((IBoxDecorator)e.getValue());
/* 146 */       this.decorators.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public IBoxProvider getBoxProvider(IWorkbenchPart part) {
/* 151 */     IBoxProvider result = null;
/* 152 */     for (IBoxProvider p : getBoxProviders()) {
/* 153 */       if (p.supports(part))
/* 154 */         if (p.getEditorsBoxSettings().getFileNames().contains("*.*"))
/* 155 */           result = p;
/*     */         else
/* 157 */           return p;
/*     */     }
/* 159 */     return result;
/*     */   }
/*     */ 
/*     */   public IBoxProvider providerForName(String name) {
/* 163 */     Collection providers = getBoxProviders();
/* 164 */     for (IBoxProvider provider : providers) {
/* 165 */       if (provider.getName().equals(name))
/* 166 */         return provider;
/*     */     }
/* 168 */     IBoxProvider provider = createProvider(name);
/* 169 */     providers.add(provider);
/* 170 */     return provider;
/*     */   }
/*     */ 
/*     */   public void removeProvider(String name) {
/* 174 */     for (Iterator it = getBoxProviders().iterator(); it.hasNext(); )
/* 175 */       if (((IBoxProvider)it.next()).getName().equals(name))
/* 176 */         it.remove();
/*     */   }
/*     */ 
/*     */   public void setPartListener(IPartService partService, IPartListener2 listener)
/*     */   {
/* 181 */     if (partService == null)
/* 182 */       return;
/* 183 */     if (this.partListeners == null)
/* 184 */       this.partListeners = new HashMap();
/* 185 */     IPartListener2 oldListener = (IPartListener2)this.partListeners.get(partService);
/* 186 */     if (oldListener != null)
/* 187 */       partService.removePartListener(oldListener);
/* 188 */     partService.addPartListener(listener);
/* 189 */     this.partListeners.put(partService, listener);
/*     */   }
/*     */ 
/*     */   public void removePartListener(IPartService partService) {
/* 193 */     if ((partService == null) || (this.partListeners == null))
/* 194 */       return;
/* 195 */     IPartListener2 oldListener = (IPartListener2)this.partListeners.remove(partService);
/* 196 */     if (oldListener != null)
/* 197 */       partService.removePartListener(oldListener);
/*     */   }
/*     */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.impl.BoxProviderRegistry
 * JD-Core Version:    0.6.2
 */