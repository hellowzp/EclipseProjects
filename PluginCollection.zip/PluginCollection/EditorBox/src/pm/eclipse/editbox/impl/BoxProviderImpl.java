/*     */ package pm.eclipse.editbox.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import org.eclipse.jface.util.IPropertyChangeListener;
/*     */ import org.eclipse.jface.util.PropertyChangeEvent;
/*     */ import org.eclipse.swt.custom.StyledText;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.ui.IWorkbenchPart;
/*     */ import org.eclipse.ui.internal.misc.StringMatcher;
/*     */ import pm.eclipse.editbox.EditBoxActivator;
/*     */ import pm.eclipse.editbox.IBoxBuilder;
/*     */ import pm.eclipse.editbox.IBoxDecorator;
/*     */ import pm.eclipse.editbox.IBoxProvider;
/*     */ import pm.eclipse.editbox.IBoxSettings;
/*     */ import pm.eclipse.editbox.IBoxSettings.PropertiesKeys;
/*     */ 
/*     */ public class BoxProviderImpl
/*     */   implements IBoxProvider
/*     */ {
/*     */   protected String id;
/*     */   protected String name;
/*     */   protected IBoxSettings editorsSettings;
/*     */   protected BoxSettingsStoreImpl settingsStore;
/*     */   protected Map<String, Class> builders;
/*     */   protected Collection<String> defaultSettingsCatalog;
/*     */   private ArrayList<Matcher> matchers;
/*     */ 
/*     */   public BoxSettingsStoreImpl getSettingsStore()
/*     */   {
/*  31 */     if (this.settingsStore == null) {
/*  32 */       this.settingsStore = createSettingsStore();
/*  33 */       this.settingsStore.setProviderId(this.id);
/*     */     }
/*  35 */     return this.settingsStore;
/*     */   }
/*     */ 
/*     */   public IBoxSettings getEditorsBoxSettings() {
/*  39 */     if (this.editorsSettings == null) {
/*  40 */       this.editorsSettings = createSettings0();
/*  41 */       getSettingsStore().loadDefaults(this.editorsSettings);
/*  42 */       this.editorsSettings.addPropertyChangeListener(new IPropertyChangeListener() {
/*     */         public void propertyChange(PropertyChangeEvent event) {
/*  44 */           String p = event.getProperty();
/*  45 */           if ((p != null) && ((p.equals(IBoxSettings.PropertiesKeys.FileNames.name())) || 
/*  46 */             (p.equals(IBoxSettings.PropertiesKeys.ALL.name()))))
/*  47 */             BoxProviderImpl.this.matchers = null;
/*     */         } } );
/*     */     }
/*  50 */     return this.editorsSettings;
/*     */   }
/*     */ 
/*     */   public IBoxDecorator decorate(IWorkbenchPart editorPart) {
/*  54 */     StyledText st = getStyledText(editorPart);
/*  55 */     if (st == null)
/*  56 */       return null;
/*  57 */     IBoxSettings settings = getEditorsBoxSettings();
/*  58 */     if (!settings.getEnabled())
/*  59 */       return null;
/*  60 */     IBoxDecorator result = createDecorator();
/*  61 */     result.setStyledText(st);
/*  62 */     result.setSettings(settings);
/*  63 */     result.decorate(false);
/*  64 */     return result;
/*     */   }
/*     */ 
/*     */   protected StyledText getStyledText(IWorkbenchPart editorPart) {
/*  68 */     if (editorPart != null) {
/*  69 */       Object obj = editorPart.getAdapter(Control.class);
/*  70 */       if ((obj instanceof StyledText)) {
/*  71 */         return (StyledText)obj;
/*     */       }
/*     */     }
/*  74 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean supports(IWorkbenchPart editorPart) {
/*  78 */     return ((editorPart.getAdapter(Control.class) instanceof StyledText)) && (
/*  79 */       (supportsFile(editorPart.getTitle())) || (supportsFile(editorPart.getTitleToolTip())));
/*     */   }
/*     */ 
/*     */   protected boolean supportsFile(String fileName) {
/*  83 */     if (fileName != null) {
/*  84 */       for (Matcher matcher : getMatchers())
/*  85 */         if (matcher.matches(fileName))
/*  86 */           return true;
/*     */     }
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */   protected Collection<Matcher> getMatchers() {
/*  92 */     if (this.matchers == null) {
/*  93 */       this.matchers = new ArrayList();
/*  94 */       Collection fileNames = getEditorsBoxSettings().getFileNames();
/*  95 */       if (fileNames != null)
/*  96 */         for (String pattern : fileNames)
/*  97 */           this.matchers.add(new Matcher(pattern));
/*     */     }
/*  99 */     return this.matchers;
/*     */   }
/*     */ 
/*     */   public void releaseDecorator(IBoxDecorator decorator) {
/* 103 */     decorator.undecorate();
/*     */   }
/*     */ 
/*     */   public String getId() {
/* 107 */     return this.id;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 111 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setId(String newId)
/*     */   {
/* 116 */     this.id = newId;
/*     */   }
/*     */ 
/*     */   public void setName(String newName) {
/* 120 */     this.name = newName;
/*     */   }
/*     */ 
/*     */   protected BoxSettingsStoreImpl createSettingsStore()
/*     */   {
/* 125 */     BoxSettingsStoreImpl result = new BoxSettingsStoreImpl();
/* 126 */     result.setDefaultSettingsCatalog(this.defaultSettingsCatalog);
/* 127 */     return result;
/*     */   }
/*     */ 
/*     */   public void setDefaultSettingsCatalog(Collection<String> cat) {
/* 131 */     this.defaultSettingsCatalog = cat;
/*     */   }
/*     */ 
/*     */   public IBoxSettings createSettings() {
/* 135 */     BoxSettingsImpl result = createSettings0();
/* 136 */     result.copyFrom(getEditorsBoxSettings());
/* 137 */     return result;
/*     */   }
/*     */ 
/*     */   protected BoxSettingsImpl createSettings0() {
/* 141 */     return new BoxSettingsImpl();
/*     */   }
/*     */ 
/*     */   public IBoxDecorator createDecorator() {
/* 145 */     BoxDecoratorImpl result = new BoxDecoratorImpl();
/* 146 */     result.setProvider(this);
/* 147 */     return result;
/*     */   }
/*     */ 
/*     */   public Collection<String> getBuilders() {
/* 151 */     return this.builders != null ? this.builders.keySet() : null;
/*     */   }
/*     */ 
/*     */   public void setBuilders(Map<String, Class> newBuilders) {
/* 155 */     this.builders = newBuilders;
/*     */   }
/*     */ 
/*     */   public IBoxBuilder createBoxBuilder(String name) {
/* 159 */     Class c = null;
/* 160 */     if ((name != null) && (this.builders != null))
/* 161 */       c = (Class)this.builders.get(name);
/* 162 */     if (c == null)
/* 163 */       return new BoxBuilderImpl();
/*     */     try {
/* 165 */       return (IBoxBuilder)c.newInstance();
/*     */     } catch (Exception e) {
/* 167 */       EditBoxActivator.logError(this, "Cannot create box builder: " + name, e);
/*     */     }
/* 169 */     return null;
/*     */   }
/*     */ 
/*     */   class Matcher {
/*     */     StringMatcher m;
/*     */ 
/*     */     Matcher(String pattern) {
/* 176 */       this.m = new StringMatcher(pattern, true, false);
/*     */     }
/*     */     boolean matches(String text) {
/* 179 */       return this.m.match(text);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.impl.BoxProviderImpl
 * JD-Core Version:    0.6.2
 */