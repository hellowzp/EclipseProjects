/*     */ package pm.eclipse.editbox.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import org.eclipse.jface.preference.IPreferenceStore;
/*     */ import pm.eclipse.editbox.EditBoxActivator;
/*     */ import pm.eclipse.editbox.IBoxSettings;
/*     */ import pm.eclipse.editbox.IBoxSettingsStore;
/*     */ 
/*     */ public class BoxSettingsStoreImpl
/*     */   implements IBoxSettingsStore
/*     */ {
/*     */   private static final String FILE_NAMES = "fileNames";
/*     */   private static final String TXT_POSTFIX = "$txt";
/*     */   private static final String DEFAULT = "default";
/*     */   private static final String ENABLED = "enabled";
/*     */   protected String providerId;
/*     */   protected IPreferenceStore store;
/*     */   private Set<String> catalog;
/*     */   private Collection<String> defaultCatalog;
/*     */ 
/*     */   protected IPreferenceStore getStore()
/*     */   {
/*  29 */     if (this.store == null)
/*  30 */       this.store = EditBoxActivator.getDefault().getPreferenceStore();
/*  31 */     return this.store;
/*     */   }
/*     */ 
/*     */   protected String key(String postfix) {
/*  35 */     return this.providerId + "_" + postfix;
/*     */   }
/*     */ 
/*     */   public void setProviderId(String id) {
/*  39 */     this.providerId = id;
/*     */   }
/*     */ 
/*     */   public void loadDefaults(IBoxSettings editorsSettings) {
/*  43 */     String defaultName = getStore().getString(key("default"));
/*  44 */     if (isEmpty(defaultName)) defaultName = this.providerId;
/*  45 */     load(defaultName, editorsSettings);
/*     */   }
/*     */ 
/*     */   public void load(String name, IBoxSettings editorsSettings) {
/*  49 */     String value = getStore().getString(key(name));
/*  50 */     if (!isEmpty(value))
/*  51 */       editorsSettings.load(value);
/*     */     else
/*     */       try {
/*  54 */         editorsSettings.load(getClass().getResourceAsStream("/" + name + ".eb"));
/*     */       } catch (Exception e) {
/*  56 */         EditBoxActivator.logError(this, "Error loading settings: " + name, e);
/*     */       }
/*  58 */     editorsSettings.setEnabled(getIsEnabled());
/*  59 */     editorsSettings.setFileNames(getFileNames());
/*     */   }
/*     */ 
/*     */   protected boolean isEmpty(String s) {
/*  63 */     return (s == null) || (s.length() == 0);
/*     */   }
/*     */ 
/*     */   protected boolean getIsEnabled() {
/*  67 */     String key = key("enabled");
/*  68 */     if (getStore().contains(key))
/*  69 */       return getStore().getBoolean(key);
/*  70 */     return true;
/*     */   }
/*     */ 
/*     */   public void saveDefaults(IBoxSettings settings) {
/*  74 */     getStore().setValue(key("enabled"), settings.getEnabled() ? "true" : "false");
/*  75 */     getStore().setValue(key("default"), settings.getName());
/*  76 */     store(settings);
/*     */   }
/*     */ 
/*     */   public void store(IBoxSettings settings) {
/*  80 */     String name = settings.getName();
/*  81 */     getStore().setValue(key(name), settings.export());
/*  82 */     setFileNames(settings.getFileNames());
/*  83 */     addToCatalog(name);
/*  84 */     EditBoxActivator.getDefault().savePluginPreferences();
/*     */   }
/*     */ 
/*     */   protected void addToCatalog(String name) {
/*  88 */     Set cat = getCatalog();
/*  89 */     if (!cat.contains(name)) {
/*  90 */       cat.add(name);
/*  91 */       storeCatalog(cat);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void storeCatalog(Set<String> cat) {
/*  96 */     StringBuilder sb = new StringBuilder();
/*  97 */     for (String c : cat) {
/*  98 */       if (sb.length() > 0) sb.append(",");
/*  99 */       sb.append(c);
/*     */     }
/* 101 */     getStore().setValue(key("catalog"), sb.toString());
/*     */   }
/*     */ 
/*     */   public Set<String> getCatalog() {
/* 105 */     if (this.catalog == null) {
/* 106 */       this.catalog = new LinkedHashSet();
/* 107 */       String cstr = getStore().getString(key("catalog"));
/* 108 */       if (!isEmpty(cstr)) {
/* 109 */         for (String s : cstr.split(","))
/* 110 */           this.catalog.add(s);
/*     */       }
/*     */     }
/* 113 */     if ((this.defaultCatalog != null) && (this.catalog != null))
/* 114 */       this.catalog.addAll(this.defaultCatalog);
/* 115 */     return this.catalog;
/*     */   }
/*     */ 
/*     */   public void setDefaultSettingsCatalog(Collection<String> cat) {
/* 119 */     this.defaultCatalog = cat;
/*     */   }
/*     */ 
/*     */   public void remove(String name) {
/* 123 */     if (getCatalog().remove(name))
/* 124 */       storeCatalog(getCatalog());
/* 125 */     getStore().setValue(key(name), "");
/* 126 */     getStore().setValue(key(name + "$txt"), "");
/* 127 */     EditBoxActivator.getDefault().savePluginPreferences();
/*     */   }
/*     */ 
/*     */   protected void setFileNames(Collection<String> fileNames) {
/* 131 */     StringBuilder sb = new StringBuilder();
/* 132 */     if (fileNames != null) {
/* 133 */       boolean first = true;
/* 134 */       for (String s : fileNames) {
/* 135 */         if (!first)
/* 136 */           sb.append(",");
/* 137 */         sb.append(s);
/* 138 */         first = false;
/*     */       }
/*     */     }
/* 141 */     getStore().setValue(key("fileNames"), sb.toString());
/*     */   }
/*     */ 
/*     */   protected Collection<String> getFileNames()
/*     */   {
/* 148 */     String key = key("fileNames");
/*     */ 
/* 150 */     if (!getStore().contains(key)) {
/* 151 */       return null;
/*     */     }
/* 153 */     String value = getStore().getString(key);
/* 154 */     List l = new ArrayList();
/* 155 */     if (value != null) {
/* 156 */       StringTokenizer st = new StringTokenizer(value, ",");
/* 157 */       while (st.hasMoreTokens()) {
/* 158 */         String t = st.nextToken().trim();
/* 159 */         if (t.length() > 0) {
/* 160 */           l.add(t);
/*     */         }
/*     */       }
/*     */     }
/* 164 */     return l;
/*     */   }
/*     */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.impl.BoxSettingsStoreImpl
 * JD-Core Version:    0.6.2
 */