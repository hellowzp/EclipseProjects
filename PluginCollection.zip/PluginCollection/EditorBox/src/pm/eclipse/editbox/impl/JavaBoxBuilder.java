/*    */ package pm.eclipse.editbox.impl;
/*    */ 
/*    */ import pm.eclipse.editbox.Box;
/*    */ 
/*    */ public class JavaBoxBuilder extends BoxBuilderImpl
/*    */ {
/*    */   protected void addLine(int start, int end, int offset, boolean empty)
/*    */   {
/* 14 */     if (!empty) {
/* 15 */       if (startLineComment(start, end, offset, empty)) {
/* 16 */         int n = 2;
/* 17 */         char c = '\000';
/* 18 */         int newOffset = 0;
/* 19 */         while ((start + n < end) && (Character.isWhitespace(c = this.text.charAt(start + n)))) {
/* 20 */           newOffset += (c == '\t' ? this.tabSize : 1);
/* 21 */           n++;
/*    */         }
/* 23 */         updateEnds(start, end, newOffset + 2);
/* 24 */         return;
/*    */       }
/* 26 */       if (this.text.charAt(start) == '*') {
/* 27 */         this.emptyPrevLine = (!commentStarts(this.currentbox.start, this.currentbox.end));
/* 28 */         if (!this.emptyPrevLine) {
/* 29 */           if (this.currentbox.offset < offset) {
/* 30 */             offset = this.currentbox.offset;
/* 31 */             start -= offset - this.currentbox.offset;
/*    */           }
/*    */         } else {
/* 34 */           start--;
/* 35 */           offset--;
/*    */         }
/* 37 */       } else if ((this.emptyPrevLine) && (isClosingToken(start, end))) {
/* 38 */         this.emptyPrevLine = false;
/* 39 */       } else if ((!this.emptyPrevLine) && (commentStarts(start, end))) {
/* 40 */         this.emptyPrevLine = true;
/*    */       }
/* 42 */       addbox0(start, end, offset);
/* 43 */       this.emptyPrevLine = commentEnds(start, end);
/*    */     } else {
/* 45 */       this.emptyPrevLine = true;
/*    */     }
/*    */   }
/*    */ 
/*    */   private void updateEnds(int start, int end, int n) {
/* 50 */     Box b = this.currentbox;
/* 51 */     int len = end - start;
/* 52 */     while (b != null) {
/* 53 */       if ((b.offset <= n) && 
/* 54 */         (b.maxLineLen < len)) {
/* 55 */         b.maxLineLen = len;
/* 56 */         b.maxEndOffset = end;
/*    */       }
/*    */ 
/* 59 */       b = b.parent;
/*    */     }
/*    */   }
/*    */ 
/*    */   private boolean startLineComment(int start, int end, int offset, boolean empty) {
/* 64 */     return (offset == 0) && (end - start > 1) && (this.text.charAt(start) == '/') && (this.text.charAt(start + 1) == '/');
/*    */   }
/*    */ 
/*    */   private boolean commentStarts(int start, int end) {
/* 68 */     return (end - start > 1) && (this.text.charAt(start) == '/') && (this.text.charAt(start + 1) == '*');
/*    */   }
/*    */ 
/*    */   private boolean commentEnds(int start, int end) {
/* 72 */     for (int i = start; i < end; i++)
/* 73 */       if ((this.text.charAt(i) == '*') && (this.text.charAt(i + 1) == '/'))
/* 74 */         return true;
/* 75 */     return false;
/*    */   }
/*    */ 
/*    */   private boolean isClosingToken(int start, int end) {
/* 79 */     int open = 0;
/* 80 */     int close = 0;
/* 81 */     for (int i = start; i <= end; i++) {
/* 82 */       if (this.text.charAt(i) == '}') {
/* 83 */         if (open > 0)
/* 84 */           open--;
/*    */         else
/* 86 */           close++;
/* 87 */       } else if (this.text.charAt(i) == '}') {
/* 88 */         open++;
/*    */       }
/*    */     }
/* 91 */     return close > 0;
/*    */   }
/*    */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.impl.JavaBoxBuilder
 * JD-Core Version:    0.6.2
 */