/*     */ package pm.eclipse.editbox.impl;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.StringBufferInputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Properties;
/*     */ import org.eclipse.jface.util.IPropertyChangeListener;
/*     */ import org.eclipse.jface.util.PropertyChangeEvent;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.RGB;
/*     */ import pm.eclipse.editbox.EditBox;
/*     */ import pm.eclipse.editbox.IBoxSettings;
/*     */ import pm.eclipse.editbox.IBoxSettings.PropertiesKeys;
/*     */ 
/*     */ public class BoxSettingsImpl
/*     */   implements IBoxSettings
/*     */ {
/*  23 */   private static final BoxSettingsImpl DEFAULT = new BoxSettingsImpl() {  } ;
/*     */   protected boolean enabled;
/*     */   protected String name;
/*     */   protected String text;
/*     */   protected Color borderColor;
/*     */   protected Color highlightColor;
/*     */   protected Color fillColor;
/*     */   protected int borderWidth;
/*     */   protected int highlightWidth;
/*     */   protected boolean highlightOne;
/*     */   protected boolean fillSelected;
/*     */   protected boolean roundBox;
/*     */   protected String builder;
/*     */   protected Color[] boxColors;
/*     */   protected ArrayList<IPropertyChangeListener> listeners;
/*     */   protected boolean highlightDrawLine;
/*     */   protected Color fillGradientColor;
/*     */   protected boolean fillGradient;
/*     */   protected boolean borderDrawLine;
/*     */   protected boolean fillOnMove;
/*     */   protected boolean circulateLevelColors;
/*     */   protected String fillKeyModifier;
/*     */   protected Collection<String> fileNames;
/*     */   protected int highlightColorType;
/*     */   protected int borderColorType;
/*     */   protected int borderLineStyle;
/*     */   protected int highlightLineStyle;
/*     */   protected boolean noBackground;
/*     */   protected boolean expandBox;
/*     */   protected int alpha;
/*     */   private transient Color[] borderColors;
/*     */   private transient Color[] highlightColors;
/*     */ 
/*  75 */   public void copyFrom(IBoxSettings other) { BoxSettingsImpl o = (BoxSettingsImpl)other;
/*  76 */     this.name = o.getName();
/*  77 */     this.enabled = o.getEnabled();
/*  78 */     this.fileNames = (o.fileNames == null ? null : new ArrayList(o.fileNames));
/*  79 */     this.borderColor = setColorCopy(this.borderColor, o.borderColor);
/*  80 */     this.highlightColor = setColorCopy(this.highlightColor, o.highlightColor);
/*  81 */     this.fillColor = setColorCopy(this.fillColor, o.fillColor);
/*  82 */     this.borderWidth = o.borderWidth;
/*  83 */     this.highlightWidth = o.highlightWidth;
/*  84 */     this.highlightOne = o.highlightOne;
/*  85 */     this.fillSelected = o.fillSelected;
/*  86 */     this.roundBox = o.roundBox;
/*  87 */     Color[] newBoxColors = copyColors(o);
/*  88 */     Color[] oldBoxColors = this.boxColors;
/*  89 */     this.boxColors = newBoxColors;
/*  90 */     disposeColors(oldBoxColors);
/*  91 */     this.builder = o.builder;
/*  92 */     this.borderDrawLine = o.borderDrawLine;
/*  93 */     this.highlightDrawLine = o.highlightDrawLine;
/*  94 */     this.fillGradient = o.fillGradient;
/*  95 */     this.fillGradientColor = setColorCopy(this.fillGradientColor, o.fillGradientColor);
/*  96 */     this.fillOnMove = o.fillOnMove;
/*  97 */     this.circulateLevelColors = o.circulateLevelColors;
/*  98 */     this.fillKeyModifier = o.fillKeyModifier;
/*  99 */     this.borderColorType = o.borderColorType;
/* 100 */     this.highlightColorType = o.highlightColorType;
/* 101 */     this.borderColors = disposeColors(this.borderColors);
/* 102 */     this.highlightColors = disposeColors(this.highlightColors);
/* 103 */     this.highlightLineStyle = o.highlightLineStyle;
/* 104 */     this.borderLineStyle = o.borderLineStyle;
/* 105 */     this.noBackground = o.noBackground;
/* 106 */     this.expandBox = o.expandBox;
/* 107 */     this.alpha = o.alpha;
/* 108 */     notifyChange(IBoxSettings.PropertiesKeys.ALL.name(), null, null); }
/*     */ 
/*     */   private Color[] copyColors(BoxSettingsImpl o)
/*     */   {
/* 112 */     Color[] newBoxColors = o.boxColors == null ? null : new Color[o.boxColors.length];
/* 113 */     if (newBoxColors != null)
/* 114 */       for (int i = 0; i < newBoxColors.length; i++) {
/* 115 */         Color c = o.boxColors[i];
/* 116 */         if (c != null)
/* 117 */           newBoxColors[i] = new Color(null, c.getRGB());
/*     */       }
/* 119 */     return newBoxColors;
/*     */   }
/*     */ 
/*     */   private Color[] disposeColors(Color[] oldBoxColors) {
/* 123 */     if (oldBoxColors != null) {
/* 124 */       for (int i = 0; i < oldBoxColors.length; i++)
/* 125 */         if (oldBoxColors[i] != null)
/* 126 */           oldBoxColors[i].dispose();
/*     */     }
/* 128 */     return null;
/*     */   }
/*     */ 
/*     */   protected Color setColorCopy(Color old, Color newColor) {
/* 132 */     if (old != null)
/* 133 */       old.dispose();
/* 134 */     return newColor == null ? null : new Color(null, newColor.getRGB());
/*     */   }
/*     */ 
/*     */   public String export() {
/* 138 */     return new StringExternalization().export(this);
/*     */   }
/*     */ 
/*     */   public void load(String string) {
/* 142 */     StringExternalization ext = new StringExternalization();
/* 143 */     boolean error = false;
/* 144 */     if (string != null)
/*     */       try {
/* 146 */         ext.load(string, this);
/*     */       } catch (Exception e) {
/* 148 */         EditBox.logError(this, "Cannot load EditBox settings from string: " + string, e);
/* 149 */         error = true;
/*     */       }
/* 151 */     if ((error) || (string == null)) {
/* 152 */       copyFrom(DEFAULT);
/*     */     }
/* 154 */     notifyChange(IBoxSettings.PropertiesKeys.ALL.name(), null, null);
/*     */   }
/*     */ 
/*     */   public void export(OutputStream stream) throws Exception {
/* 158 */     new StringExternalization().export(stream, this);
/*     */   }
/*     */ 
/*     */   public void load(InputStream stream) throws Exception {
/* 162 */     if (stream == null)
/* 163 */       load(null);
/*     */     else
/* 165 */       new StringExternalization().load(stream, this);
/* 166 */     notifyChange(IBoxSettings.PropertiesKeys.ALL.name(), null, null);
/*     */   }
/*     */ 
/*     */   public boolean getEnabled() {
/* 170 */     return this.enabled;
/*     */   }
/*     */ 
/*     */   public void setEnabled(boolean flag) {
/* 174 */     this.enabled = flag;
/* 175 */     notifyChange(IBoxSettings.PropertiesKeys.Enabled.name(), null, Boolean.valueOf(flag));
/*     */   }
/*     */ 
/*     */   public void setFileNames(Collection<String> fileNames) {
/* 179 */     this.fileNames = fileNames;
/* 180 */     notifyChange(IBoxSettings.PropertiesKeys.FileNames.name(), null, null);
/*     */   }
/*     */ 
/*     */   public Collection<String> getFileNames() {
/* 184 */     return this.fileNames;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 188 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String newName) {
/* 192 */     this.name = newName;
/* 193 */     notifyChange(IBoxSettings.PropertiesKeys.Name.name(), null, null);
/*     */   }
/*     */ 
/*     */   public String getText() {
/* 197 */     return this.text;
/*     */   }
/*     */ 
/*     */   public void setText(String newText) {
/* 201 */     this.text = newText;
/*     */   }
/*     */ 
/*     */   protected Color setColor0(Color old, Color c) {
/* 205 */     disposeColor(old);
/* 206 */     return c;
/*     */   }
/*     */ 
/*     */   protected Color setColor0(Color old, RGB c) {
/* 210 */     if (c == null)
/* 211 */       return old;
/* 212 */     return setColor0(old, new Color(null, c));
/*     */   }
/*     */ 
/*     */   protected Color disposeColor(Color c) {
/* 216 */     if (c != null)
/* 217 */       c.dispose();
/* 218 */     return null;
/*     */   }
/*     */ 
/*     */   public void dispose() {
/* 222 */     this.borderColor = disposeColor(this.borderColor);
/* 223 */     this.highlightColor = disposeColor(this.highlightColor);
/* 224 */     this.fillColor = disposeColor(this.fillColor);
/* 225 */     disposeColors(this.boxColors);
/* 226 */     this.boxColors = null;
/* 227 */     if (this.listeners != null)
/* 228 */       this.listeners.clear();
/*     */   }
/*     */ 
/*     */   public Color getBorderColor() {
/* 232 */     return this.borderColor;
/*     */   }
/*     */ 
/*     */   public int getBorderWidth() {
/* 236 */     return this.borderWidth;
/*     */   }
/*     */ 
/*     */   public void setBorderRGB(RGB c) {
/* 240 */     this.borderColor = setColor0(this.borderColor, c);
/* 241 */     notifyChange(IBoxSettings.PropertiesKeys.BorderColor.name(), null, null);
/*     */   }
/*     */ 
/*     */   public void setBorderWidth(int w) {
/* 245 */     this.borderWidth = w;
/* 246 */     notifyChange(IBoxSettings.PropertiesKeys.BorderWidth.name(), null, null);
/*     */   }
/*     */ 
/*     */   public void setRoundBox(boolean flag) {
/* 250 */     this.roundBox = flag;
/* 251 */     notifyChange(IBoxSettings.PropertiesKeys.RoundBox.name(), null, null);
/*     */   }
/*     */ 
/*     */   public boolean getRoundBox() {
/* 255 */     return this.roundBox;
/*     */   }
/*     */ 
/*     */   public Color getHighlightColor() {
/* 259 */     return this.highlightColor;
/*     */   }
/*     */ 
/*     */   public boolean getHighlightOne() {
/* 263 */     return this.highlightOne;
/*     */   }
/*     */ 
/*     */   public int getHighlightWidth() {
/* 267 */     return this.highlightWidth;
/*     */   }
/*     */ 
/*     */   public void setHighlightOne(boolean flag) {
/* 271 */     this.highlightOne = flag;
/* 272 */     notifyChange(IBoxSettings.PropertiesKeys.HighlightOne.name(), null, null);
/*     */   }
/*     */ 
/*     */   public void setHighlightRGB(RGB highlightRGB) {
/* 276 */     this.highlightColor = setColor0(this.highlightColor, highlightRGB);
/* 277 */     notifyChange(IBoxSettings.PropertiesKeys.HighlightColor.name(), null, null);
/*     */   }
/*     */ 
/*     */   public void setHighlightWidth(int w) {
/* 281 */     this.highlightWidth = w;
/* 282 */     notifyChange(IBoxSettings.PropertiesKeys.HighlightWidth.name(), null, null);
/*     */   }
/*     */ 
/*     */   public boolean getFillSelected() {
/* 286 */     return this.fillSelected;
/*     */   }
/*     */ 
/*     */   public Color getFillSelectedColor() {
/* 290 */     return this.fillColor;
/*     */   }
/*     */ 
/*     */   public void setFillSelected(boolean flag) {
/* 294 */     this.fillSelected = flag;
/* 295 */     notifyChange(IBoxSettings.PropertiesKeys.FillSelected.name(), null, null);
/*     */   }
/*     */ 
/*     */   public void setFillSelectedRGB(RGB newColor) {
/* 299 */     this.fillColor = setColor0(this.fillColor, newColor);
/* 300 */     notifyChange(IBoxSettings.PropertiesKeys.FillSelectedColor.name(), null, null);
/*     */   }
/*     */ 
/*     */   public void setBuilder(String name) {
/* 304 */     this.builder = name;
/* 305 */     notifyChange(IBoxSettings.PropertiesKeys.Builder.name(), null, null);
/*     */   }
/*     */ 
/*     */   public String getBuilder() {
/* 309 */     return this.builder;
/*     */   }
/*     */ 
/*     */   public boolean getBorderDrawLine() {
/* 313 */     return this.borderDrawLine;
/*     */   }
/*     */ 
/*     */   public boolean getFillGradient() {
/* 317 */     return this.fillGradient;
/*     */   }
/*     */ 
/*     */   public Color getFillGradientColor() {
/* 321 */     return this.fillGradientColor;
/*     */   }
/*     */ 
/*     */   public boolean getHighlightDrawLine() {
/* 325 */     return this.highlightDrawLine;
/*     */   }
/*     */ 
/*     */   public void setBorderDrawLine(boolean flag) {
/* 329 */     this.borderDrawLine = flag;
/* 330 */     notifyChange(IBoxSettings.PropertiesKeys.BorderDrawLine.name(), null, null);
/*     */   }
/*     */ 
/*     */   public void setFillGradient(boolean flag) {
/* 334 */     this.fillGradient = flag;
/* 335 */     notifyChange(IBoxSettings.PropertiesKeys.FillGradient.name(), null, null);
/*     */   }
/*     */ 
/*     */   public void setFillGradientColorRGB(RGB color) {
/* 339 */     this.fillGradientColor = setColor0(this.fillGradientColor, color);
/* 340 */     notifyChange(IBoxSettings.PropertiesKeys.FillGradientColor.name(), null, null);
/*     */   }
/*     */ 
/*     */   public void setHighlightDrawLine(boolean flag) {
/* 344 */     this.highlightDrawLine = flag;
/* 345 */     notifyChange(IBoxSettings.PropertiesKeys.HighlightDrawLine.name(), null, null);
/*     */   }
/*     */ 
/*     */   public Color[] getColors() {
/* 349 */     return this.boxColors;
/*     */   }
/*     */ 
/*     */   public boolean getFillOnMove() {
/* 353 */     return this.fillOnMove;
/*     */   }
/*     */ 
/*     */   public void setFillOnMove(boolean selection) {
/* 357 */     this.fillOnMove = selection;
/* 358 */     notifyChange(IBoxSettings.PropertiesKeys.FillOnMove.name(), null, null);
/*     */   }
/*     */ 
/*     */   public void setColorsRGB(RGB[] gradient)
/*     */   {
/* 363 */     if (gradient == null) {
/* 364 */       disposeColors(this.boxColors);
/* 365 */       this.boxColors = null;
/*     */     } else {
/* 367 */       Color[] c = new Color[gradient.length];
/* 368 */       for (int i = 0; i < gradient.length; i++)
/* 369 */         c[i] = new Color(null, gradient[i]);
/* 370 */       disposeColors(this.boxColors);
/* 371 */       this.boxColors = c;
/*     */     }
/* 373 */     notifyChange(IBoxSettings.PropertiesKeys.Colors.name(), null, null);
/*     */   }
/*     */ 
/*     */   public void setColorsSize(int n) {
/* 377 */     n++;
/* 378 */     Color[] newColors = null;
/* 379 */     if (n == 0) {
/* 380 */       disposeColors(this.boxColors);
/* 381 */     } else if (this.boxColors != null) {
/* 382 */       newColors = new Color[n];
/* 383 */       for (int i = 0; i < n; i++) {
/* 384 */         if (i >= this.boxColors.length)
/*     */           break;
/* 386 */         newColors[i] = this.boxColors[i];
/*     */       }
/* 388 */       for (int i = n; i < this.boxColors.length; i++)
/* 389 */         disposeColor(this.boxColors[i]);
/*     */     } else {
/* 391 */       newColors = new Color[n];
/* 392 */     }this.boxColors = newColors;
/* 393 */     notifyChange(IBoxSettings.PropertiesKeys.Colors.name(), null, null);
/*     */   }
/*     */ 
/*     */   public int getColorsSize() {
/* 397 */     return this.boxColors == null ? 0 : this.boxColors.length - 1;
/*     */   }
/*     */ 
/*     */   public Color getBorderColor(int level) {
/* 401 */     if (this.borderColorType < 1) return this.borderColor;
/*     */ 
/* 403 */     if (this.boxColors == null) {
/* 404 */       return null;
/*     */     }
/* 406 */     if ((this.borderColors != null) && (this.borderColors.length != this.boxColors.length)) {
/* 407 */       this.borderColors = disposeColors(this.borderColors);
/*     */     }
/* 409 */     if (this.borderColors == null) {
/* 410 */       this.borderColors = new Color[this.boxColors.length];
/*     */     }
/* 412 */     int idx = getColorIndex(level);
/* 413 */     if (idx > -1) {
/* 414 */       if (this.borderColors[idx] != null) return this.borderColors[idx];
/* 415 */       if (this.boxColors[idx] == null) return null;
/* 416 */       return this.borderColors[idx] =  = calculateDarkerColor(this.boxColors[idx], this.borderColorType);
/*     */     }
/*     */ 
/* 419 */     return null;
/*     */   }
/*     */ 
/*     */   private final Color calculateDarkerColor(Color c, int type) {
/* 423 */     return new Color(null, calcDarker(c.getRed(), type), calcDarker(c.getGreen(), type), calcDarker(c.getBlue(), type));
/*     */   }
/*     */ 
/*     */   private final int calcDarker(int r, int type) {
/* 427 */     return r - r * type / 4;
/*     */   }
/*     */ 
/*     */   public Color getHighlightColor(int level) {
/* 431 */     if (this.highlightColorType < 1) return this.highlightColor;
/*     */ 
/* 433 */     if (this.boxColors == null) {
/* 434 */       return null;
/*     */     }
/* 436 */     if ((this.highlightColors != null) && (this.highlightColors.length != this.boxColors.length)) {
/* 437 */       this.highlightColors = disposeColors(this.highlightColors);
/*     */     }
/* 439 */     if (this.highlightColors == null) {
/* 440 */       this.highlightColors = new Color[this.boxColors.length];
/*     */     }
/* 442 */     int idx = getColorIndex(level);
/* 443 */     if (idx > -1) {
/* 444 */       if (this.highlightColors[idx] != null) return this.highlightColors[idx];
/* 445 */       if (this.boxColors[idx] == null) return null;
/* 446 */       return this.highlightColors[idx] =  = calculateDarkerColor(this.boxColors[idx], this.highlightColorType);
/*     */     }
/*     */ 
/* 449 */     return null;
/*     */   }
/*     */ 
/*     */   public void setBorderColorType(int selectionIndex) {
/* 453 */     this.borderColorType = selectionIndex;
/* 454 */     notifyChange(IBoxSettings.PropertiesKeys.BorderColorType.name(), null, null);
/*     */   }
/*     */ 
/*     */   public int getBorderColorType() {
/* 458 */     return this.borderColorType;
/*     */   }
/*     */ 
/*     */   public void setHighlightColorType(int selectionIndex) {
/* 462 */     this.highlightColorType = selectionIndex;
/* 463 */     notifyChange(IBoxSettings.PropertiesKeys.HighlightColorType.name(), null, null);
/*     */   }
/*     */ 
/*     */   public int getHighlightColorType() {
/* 467 */     return this.highlightColorType;
/*     */   }
/*     */ 
/*     */   public int getColorIndex(int level) {
/* 471 */     if ((this.boxColors.length == 1) && (this.noBackground) && (level > 0))
/* 472 */       return -1;
/* 473 */     if ((!this.circulateLevelColors) && (this.boxColors != null) && (this.boxColors.length <= level) && (this.boxColors.length > 0))
/* 474 */       return this.boxColors.length - 1;
/* 475 */     if ((this.boxColors != null) && (this.boxColors.length > 0) && (level > -1)) {
/* 476 */       return getNColor0(level);
/*     */     }
/* 478 */     return -1;
/*     */   }
/*     */ 
/*     */   public Color getColor(int level) {
/* 482 */     int idx = getColorIndex(level);
/* 483 */     if (idx > -1) return this.boxColors[idx];
/* 484 */     return null;
/*     */   }
/*     */ 
/*     */   int getNColor0(int n) {
/* 488 */     int len = this.boxColors.length;
/* 489 */     if (len < 2) return 0;
/* 490 */     int x = n % (len + len - 2);
/* 491 */     if (x < len) {
/* 492 */       return x;
/*     */     }
/* 494 */     return len - (x - len + 2);
/*     */   }
/*     */ 
/*     */   public void setColor(int level, RGB rgb) {
/* 498 */     if ((this.boxColors != null) && (this.boxColors.length > 0) && (level > -1))
/* 499 */       this.boxColors[(level % this.boxColors.length)] = setColor0(this.boxColors[(level % this.boxColors.length)], rgb);
/* 500 */     notifyChange(IBoxSettings.PropertiesKeys.Color.name(), null, null);
/*     */   }
/*     */ 
/*     */   public boolean getCirculateLevelColors() {
/* 504 */     return this.circulateLevelColors;
/*     */   }
/*     */ 
/*     */   public void setCirculateLevelColors(boolean flag) {
/* 508 */     this.circulateLevelColors = flag;
/* 509 */     notifyChange(IBoxSettings.PropertiesKeys.CirculateLevelColors.name(), null, null);
/*     */   }
/*     */ 
/*     */   public void setFillKeyModifier(String key) {
/* 513 */     this.fillKeyModifier = key;
/* 514 */     notifyChange(IBoxSettings.PropertiesKeys.FillKeyModifier.name(), null, null);
/*     */   }
/*     */   public String getFillKeyModifier() {
/* 517 */     return this.fillKeyModifier;
/*     */   }
/*     */   public int getFillKeyModifierSWTInt() {
/* 520 */     if ((this.fillKeyModifier == null) || (this.fillKeyModifier.length() == 0))
/* 521 */       return 0;
/* 522 */     if ("Alt".equals(this.fillKeyModifier))
/* 523 */       return 65536;
/* 524 */     if ("Ctrl".equals(this.fillKeyModifier))
/* 525 */       return 262144;
/* 526 */     if ("Shift".equals(this.fillKeyModifier))
/* 527 */       return 131072;
/* 528 */     return 0;
/*     */   }
/*     */ 
/*     */   public void addPropertyChangeListener(IPropertyChangeListener listener)
/*     */   {
/* 716 */     if (this.listeners == null)
/* 717 */       this.listeners = new ArrayList();
/* 718 */     this.listeners.add(listener);
/*     */   }
/*     */ 
/*     */   public void removePropertyChangeListener(IPropertyChangeListener listener) {
/* 722 */     if (this.listeners != null) this.listeners.remove(listener); 
/*     */   }
/*     */ 
/*     */   protected void notifyChange(String propertyName, Object oldValue, Object newValue)
/*     */   {
/* 726 */     if (this.listeners != null) {
/* 727 */       PropertyChangeEvent e = new PropertyChangeEvent(this, propertyName, oldValue, newValue);
/* 728 */       for (IPropertyChangeListener listener : this.listeners)
/* 729 */         listener.propertyChange(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setBorderLineStyle(int selectionIndex) {
/* 734 */     this.borderLineStyle = selectionIndex;
/* 735 */     notifyChange(IBoxSettings.PropertiesKeys.BorderLineStyle.name(), null, null);
/*     */   }
/*     */ 
/*     */   public void setHighlightLineStyle(int selectionIndex) {
/* 739 */     this.highlightLineStyle = selectionIndex;
/* 740 */     notifyChange(IBoxSettings.PropertiesKeys.HighlightLineStyle.name(), null, null);
/*     */   }
/*     */ 
/*     */   public int getBorderLineStyle() {
/* 744 */     return this.borderLineStyle;
/*     */   }
/*     */ 
/*     */   public int getBorderLineStyleSWTInt() {
/* 748 */     return swtLineStyle(this.borderLineStyle);
/*     */   }
/*     */ 
/*     */   private int swtLineStyle(int index) {
/* 752 */     switch (index) { case 0:
/* 753 */       return 1;
/*     */     case 1:
/* 754 */       return 3;
/*     */     case 2:
/* 755 */       return 2;
/*     */     case 3:
/* 756 */       return 4;
/*     */     case 4:
/* 757 */       return 5;
/*     */     }
/* 759 */     return 0;
/*     */   }
/*     */ 
/*     */   public int getHighlightLineStyle() {
/* 763 */     return this.highlightLineStyle;
/*     */   }
/*     */ 
/*     */   public int getHighlightLineStyleSWTInt() {
/* 767 */     return swtLineStyle(this.highlightLineStyle);
/*     */   }
/*     */ 
/*     */   public boolean getNoBackground() {
/* 771 */     return this.noBackground;
/*     */   }
/*     */ 
/*     */   public void setNoBackground(boolean flag) {
/* 775 */     this.noBackground = flag;
/* 776 */     notifyChange(IBoxSettings.PropertiesKeys.NoBackground.name(), null, null);
/*     */   }
/*     */ 
/*     */   public boolean getExpandBox() {
/* 780 */     return this.expandBox;
/*     */   }
/*     */ 
/*     */   public void setExpandBox(boolean flag) {
/* 784 */     this.expandBox = flag;
/* 785 */     notifyChange(IBoxSettings.PropertiesKeys.ExpandBox.name(), null, null);
/*     */   }
/*     */ 
/*     */   public int getAlpha() {
/* 789 */     return this.alpha;
/*     */   }
/*     */ 
/*     */   public void setAlpha(int alpha) {
/* 793 */     this.alpha = alpha;
/* 794 */     notifyChange(IBoxSettings.PropertiesKeys.Alpha.name(), null, null);
/*     */   }
/*     */ 
/*     */   class StringExternalization
/*     */   {
/*     */     private static final String COMMENT = "Editbox Eclipse Plugin Settings";
/*     */ 
/*     */     StringExternalization()
/*     */     {
/*     */     }
/*     */ 
/*     */     public String export(BoxSettingsImpl b)
/*     */     {
/* 536 */       Properties p = toProperies(b);
/* 537 */       return propertiesToString(p);
/*     */     }
/*     */ 
/*     */     public void load(InputStream stream, BoxSettingsImpl b) throws Exception {
/* 541 */       Properties p = new Properties();
/* 542 */       p.load(stream);
/* 543 */       load(p, b);
/*     */     }
/*     */ 
/*     */     public void export(OutputStream stream, BoxSettingsImpl b) throws Exception {
/* 547 */       Properties p = toProperies(b);
/* 548 */       p.store(stream, "Editbox Eclipse Plugin Settings");
/*     */     }
/*     */ 
/*     */     public void load(String s, BoxSettingsImpl b) throws Exception
/*     */     {
/* 553 */       Properties p = loadProperties(s);
/* 554 */       load(p, b);
/*     */     }
/*     */ 
/*     */     private void load(Properties p, BoxSettingsImpl b) {
/* 558 */       b.name = parseString(p.get(IBoxSettings.PropertiesKeys.Name.name()));
/* 559 */       b.borderColor = parseColor(p.get(IBoxSettings.PropertiesKeys.BorderColor.name()));
/* 560 */       b.highlightColor = parseColor(p.get(IBoxSettings.PropertiesKeys.HighlightColor.name()));
/* 561 */       b.borderWidth = parseInt(p.get(IBoxSettings.PropertiesKeys.BorderWidth.name()));
/* 562 */       b.highlightWidth = parseInt(p.get(IBoxSettings.PropertiesKeys.HighlightWidth.name()));
/* 563 */       b.roundBox = parseBool(p.get(IBoxSettings.PropertiesKeys.RoundBox.name()));
/* 564 */       b.highlightOne = parseBool(p.get(IBoxSettings.PropertiesKeys.HighlightOne.name()));
/* 565 */       b.fillSelected = parseBool(p.get(IBoxSettings.PropertiesKeys.FillSelected.name()));
/* 566 */       b.fillColor = parseColor(p.get(IBoxSettings.PropertiesKeys.FillSelectedColor.name()));
/* 567 */       b.builder = parseString(p.get(IBoxSettings.PropertiesKeys.Builder.name()));
/* 568 */       b.boxColors = parseColorsArray(p.get(IBoxSettings.PropertiesKeys.Colors.name()));
/* 569 */       b.highlightDrawLine = parseBool(p.get(IBoxSettings.PropertiesKeys.HighlightDrawLine.name()));
/* 570 */       b.borderDrawLine = parseBool(p.get(IBoxSettings.PropertiesKeys.BorderDrawLine.name()));
/* 571 */       b.fillGradient = parseBool(p.get(IBoxSettings.PropertiesKeys.FillGradient.name()));
/* 572 */       b.fillGradientColor = parseColor(p.get(IBoxSettings.PropertiesKeys.FillGradientColor.name()));
/* 573 */       b.fillOnMove = parseBool(p.get(IBoxSettings.PropertiesKeys.FillOnMove.name()));
/* 574 */       b.circulateLevelColors = parseBool(p.get(IBoxSettings.PropertiesKeys.CirculateLevelColors.name()));
/* 575 */       b.fillKeyModifier = parseString(p.get(IBoxSettings.PropertiesKeys.FillKeyModifier.name()));
/* 576 */       b.borderColorType = parseInt(p.get(IBoxSettings.PropertiesKeys.BorderColorType.name()));
/* 577 */       b.highlightColorType = parseInt(p.get(IBoxSettings.PropertiesKeys.HighlightColorType.name()));
/* 578 */       b.highlightLineStyle = parseInt(p.get(IBoxSettings.PropertiesKeys.HighlightLineStyle.name()));
/* 579 */       b.borderLineStyle = parseInt(p.get(IBoxSettings.PropertiesKeys.BorderLineStyle.name()));
/* 580 */       b.noBackground = parseBool(p.get(IBoxSettings.PropertiesKeys.NoBackground.name()));
/* 581 */       b.expandBox = parseBool(p.get(IBoxSettings.PropertiesKeys.ExpandBox.name()));
/* 582 */       b.alpha = parseInt(p.get(IBoxSettings.PropertiesKeys.Alpha.name()));
/*     */     }
/*     */ 
/*     */     private Properties toProperies(BoxSettingsImpl b) {
/* 586 */       Properties p = new Properties();
/* 587 */       p.put(IBoxSettings.PropertiesKeys.Name.name(), toS(b.name));
/* 588 */       p.put(IBoxSettings.PropertiesKeys.BorderColor.name(), toS(b.borderColor));
/* 589 */       p.put(IBoxSettings.PropertiesKeys.HighlightColor.name(), toS(b.highlightColor));
/* 590 */       p.put(IBoxSettings.PropertiesKeys.BorderWidth.name(), toS(b.borderWidth));
/* 591 */       p.put(IBoxSettings.PropertiesKeys.HighlightWidth.name(), toS(b.highlightWidth));
/* 592 */       p.put(IBoxSettings.PropertiesKeys.RoundBox.name(), toS(b.roundBox));
/* 593 */       p.put(IBoxSettings.PropertiesKeys.HighlightOne.name(), toS(b.highlightOne));
/* 594 */       p.put(IBoxSettings.PropertiesKeys.FillSelected.name(), toS(b.fillSelected));
/* 595 */       p.put(IBoxSettings.PropertiesKeys.FillSelectedColor.name(), toS(b.fillColor));
/* 596 */       p.put(IBoxSettings.PropertiesKeys.Builder.name(), toS(b.builder));
/* 597 */       p.put(IBoxSettings.PropertiesKeys.Colors.name(), toS(b.boxColors));
/* 598 */       p.put(IBoxSettings.PropertiesKeys.HighlightDrawLine.name(), toS(b.highlightDrawLine));
/* 599 */       p.put(IBoxSettings.PropertiesKeys.BorderDrawLine.name(), toS(b.borderDrawLine));
/* 600 */       p.put(IBoxSettings.PropertiesKeys.FillGradient.name(), toS(b.fillGradient));
/* 601 */       p.put(IBoxSettings.PropertiesKeys.FillGradientColor.name(), toS(b.fillGradientColor));
/* 602 */       p.put(IBoxSettings.PropertiesKeys.FillOnMove.name(), toS(b.fillOnMove));
/* 603 */       p.put(IBoxSettings.PropertiesKeys.CirculateLevelColors.name(), toS(b.circulateLevelColors));
/* 604 */       p.put(IBoxSettings.PropertiesKeys.FillKeyModifier.name(), toS(b.fillKeyModifier));
/* 605 */       p.put(IBoxSettings.PropertiesKeys.BorderColorType.name(), toS(b.borderColorType));
/* 606 */       p.put(IBoxSettings.PropertiesKeys.HighlightColorType.name(), toS(b.highlightColorType));
/* 607 */       p.put(IBoxSettings.PropertiesKeys.HighlightLineStyle.name(), toS(b.highlightLineStyle));
/* 608 */       p.put(IBoxSettings.PropertiesKeys.BorderLineStyle.name(), toS(b.borderLineStyle));
/* 609 */       p.put(IBoxSettings.PropertiesKeys.NoBackground.name(), toS(b.noBackground));
/* 610 */       p.put(IBoxSettings.PropertiesKeys.ExpandBox.name(), toS(b.expandBox));
/* 611 */       p.put(IBoxSettings.PropertiesKeys.Alpha.name(), toS(b.alpha));
/* 612 */       return p;
/*     */     }
/*     */ 
/*     */     private Properties loadProperties(String s) throws IOException {
/* 616 */       Properties p = new Properties();
/* 617 */       p.load(new StringBufferInputStream(s));
/* 618 */       return p;
/*     */     }
/*     */ 
/*     */     private String propertiesToString(Properties p) {
/*     */       try {
/* 623 */         ByteArrayOutputStream bo = new ByteArrayOutputStream();
/* 624 */         p.store(bo, "COMMENT");
/* 625 */         return bo.toString();
/*     */       } catch (IOException e) {
/* 627 */         EditBox.logError(this, "Cannot convert propeties to sring", e);
/*     */       }
/* 629 */       return "";
/*     */     }
/*     */ 
/*     */     private Color[] parseColorsArray(Object o)
/*     */     {
/* 634 */       if ((o == null) || (o.equals("null")))
/* 635 */         return null;
/* 636 */       String[] s = o.toString().split("-");
/* 637 */       Color[] c = new Color[s.length];
/* 638 */       for (int i = 0; i < c.length; i++)
/* 639 */         c[i] = parseColor(s[i]);
/* 640 */       return c;
/*     */     }
/*     */ 
/*     */     private boolean parseBool(Object o) {
/* 644 */       if (o == null)
/* 645 */         return false;
/* 646 */       return o.equals("true");
/*     */     }
/*     */ 
/*     */     private int parseInt(Object o) {
/* 650 */       if ((o == null) || (o.equals("null")))
/* 651 */         return 0;
/* 652 */       return Integer.parseInt(o.toString());
/*     */     }
/*     */ 
/*     */     private Color parseColor(Object o) {
/* 656 */       if ((o == null) || (o.equals("null")))
/* 657 */         return null;
/* 658 */       String c = o.toString();
/* 659 */       if (c.length() != 6)
/* 660 */         return null;
/*     */       try {
/* 662 */         int r = Integer.parseInt(c.substring(0, 2), 16);
/* 663 */         int g = Integer.parseInt(c.substring(2, 4), 16);
/* 664 */         int b = Integer.parseInt(c.substring(4, 6), 16);
/* 665 */         return new Color(null, r, g, b); } catch (Exception localException) {
/*     */       }
/* 667 */       return null;
/*     */     }
/*     */ 
/*     */     private String parseString(Object o)
/*     */     {
/* 672 */       if ((o == null) || (o.equals("null")))
/* 673 */         return null;
/* 674 */       return o.toString();
/*     */     }
/*     */ 
/*     */     private String toS(boolean b) {
/* 678 */       return b ? "true" : "false";
/*     */     }
/*     */ 
/*     */     private String toS(Color[] colors) {
/* 682 */       StringBuilder sb = new StringBuilder();
/* 683 */       if ((colors == null) || (colors.length == 0))
/* 684 */         sb.append("null");
/*     */       else {
/* 686 */         for (int i = 0; i < colors.length; i++) {
/* 687 */           if (i > 0)
/* 688 */             sb.append("-");
/* 689 */           sb.append(toS(colors[i]));
/*     */         }
/*     */       }
/* 692 */       return sb.toString();
/*     */     }
/*     */ 
/*     */     private String toS(int i) {
/* 696 */       return Integer.toString(i);
/*     */     }
/*     */ 
/*     */     private String toS(Color c) {
/* 700 */       return toHex(c.getRed()) + toHex(c.getGreen()) + toHex(c.getBlue());
/*     */     }
/*     */ 
/*     */     private String toHex(int v) {
/* 704 */       String s = Integer.toHexString(v);
/* 705 */       if (s.length() == 1)
/* 706 */         s = "0" + s;
/* 707 */       return s;
/*     */     }
/*     */ 
/*     */     private String toS(String s) {
/* 711 */       return s == null ? "null" : s;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.impl.BoxSettingsImpl
 * JD-Core Version:    0.6.2
 */