/*   */ package pm.eclipse.editbox.impl;
/*   */ 
/*   */ import pm.eclipse.editbox.Box;
/*   */ 
/*   */ public class TextBoxBuilder extends BoxBuilderImpl
/*   */ {
/*   */   protected void addbox0(int start, int end, int offset)
/*   */   {
/* 8 */     if (offset == this.currentbox.offset) {
/* 9 */       if ((this.currentbox.hasChildren) || ((this.emptyPrevLine) && (this.currentbox.parent != null))) {
/* 10 */         this.currentbox = newbox(start, end, offset, this.currentbox.parent);
/* 11 */         updateParentEnds(this.currentbox);
/* 12 */       } else if (end > this.currentbox.end) {
/* 13 */         this.currentbox.end = end;
/* 14 */         if ((this.currentbox.tabsStart < 0) && (this.lineHasStartTab))
/* 15 */           this.currentbox.tabsStart = start;
/* 16 */         updateMaxEndOffset(start, this.currentbox);
/* 17 */         updateParentEnds(this.currentbox);
/*   */       }
/* 19 */     } else if (offset > this.currentbox.offset) {
/* 20 */       this.currentbox = newbox(start, end, offset, this.currentbox);
/* 21 */       updateParentEnds(this.currentbox);
/* 22 */     } else if (this.currentbox.parent != null) {
/* 23 */       this.currentbox = this.currentbox.parent;
/* 24 */       addbox0(start, end, offset);
/*   */     }
/*   */   }
/*   */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.impl.TextBoxBuilder
 * JD-Core Version:    0.6.2
 */