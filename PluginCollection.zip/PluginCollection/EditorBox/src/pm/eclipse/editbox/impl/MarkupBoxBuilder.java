/*     */ package pm.eclipse.editbox.impl;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import pm.eclipse.editbox.Box;
/*     */ 
/*     */ public class MarkupBoxBuilder extends BoxBuilderImpl
/*     */ {
/*     */   protected void addLine(int start, int end, int offset, boolean empty)
/*     */   {
/*   8 */     if (!empty) {
/*   9 */       addbox0(start, end, offset);
/*  10 */       this.emptyPrevLine = isClosingTag0(start, end);
/*     */     } else {
/*  12 */       this.emptyPrevLine = empty;
/*     */     }
/*     */   }
/*     */ 
/*  16 */   protected boolean isClosingTag0(int start, int end) { String line = this.text.substring(start, end).trim();
/*  17 */     return countCloseOpen(line) < 0;
/*     */   }
/*     */ 
/*     */   protected boolean isClosingCurrentTag(int start, int end)
/*     */   {
/*  22 */     String line = this.text.substring(start, end).trim();
/*  23 */     if ((line.startsWith("</")) && (line.endsWith(">"))) {
/*  24 */       String token = "<" + line.substring(2, line.length() - 1);
/*  25 */       for (int i = 0; i < token.length(); i++) {
/*  26 */         if (this.text.charAt(this.currentbox.start + i) != token.charAt(i))
/*  27 */           return false;
/*     */       }
/*  29 */       return true;
/*     */     }
/*     */ 
/*  32 */     return false;
/*     */   }
/*     */ 
/*     */   protected void addbox0(int start, int end, int offset)
/*     */   {
/*  37 */     if ((!this.emptyPrevLine) && (isOpenTag(start, end)))
/*  38 */       this.emptyPrevLine = true;
/*  39 */     else if ((this.emptyPrevLine) && (isClosingCurrentTag(start, end)))
/*  40 */       this.emptyPrevLine = false;
/*  41 */     super.addbox0(start, end, offset);
/*     */   }
/*     */ 
/*     */   protected boolean isOpenTag(int start, int end) {
/*  45 */     String line = this.text.substring(start, end).trim();
/*  46 */     if (line.length() < 3)
/*  47 */       return false;
/*  48 */     char c = line.charAt(1);
/*  49 */     return (line.startsWith("<")) && (c != '/') && (c != '?') && (c != '!') && (c != '%') && (countCloseOpen(line) > 0);
/*     */   }
/*     */ 
/*     */   protected int countCloseOpen(String line)
/*     */   {
/*  54 */     TokenStack stack = processTags(line);
/*  55 */     return stack.result();
/*     */   }
/*     */ 
/*     */   protected TokenStack processTags(String line) {
/*  59 */     TokenStack stack = new TokenStack();
/*  60 */     String token = null;
/*  61 */     for (int i = 0; i < line.length() - 1; i++) {
/*  62 */       if (line.startsWith("</", i)) {
/*  63 */         token = getWord(line, i + 2);
/*  64 */         stack.addClosing(token);
/*  65 */       } else if (line.startsWith("/>", i)) {
/*  66 */         stack.addClosing(null);
/*  67 */       } else if ((line.startsWith("<", i)) && (Character.isLetterOrDigit(line.charAt(i + 1)))) {
/*  68 */         token = getWord(line, i + 1);
/*  69 */         stack.addOpening(token);
/*     */       }
/*     */     }
/*  72 */     return stack;
/*     */   }
/*     */ 
/*     */   protected String getWord(String line, int n) {
/*  76 */     StringBuilder sb = new StringBuilder();
/*  77 */     for (int i = n; i < line.length(); i++) {
/*  78 */       char c = line.charAt(i);
/*  79 */       if ((Character.isWhitespace(c)) || (c == '>') || (c == '/'))
/*     */         break;
/*  81 */       sb.append(c);
/*     */     }
/*  83 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   class TokenStack
/*     */   {
/*     */     private static final String CLOSING = ">";
/*  89 */     LinkedList<String> tokens = new LinkedList();
/*     */ 
/*     */     TokenStack() {  } 
/*  92 */     public void addClosing(String token) { if (token == null) {
/*  93 */         if ((!this.tokens.isEmpty()) && (!((String)this.tokens.getLast()).equals(">")))
/*  94 */           this.tokens.removeLast();
/*     */         else
/*  96 */           this.tokens.add(">");
/*     */       }
/*  98 */       else if (!this.tokens.contains(token))
/*  99 */         this.tokens.add(">");
/*     */       else
/* 101 */         while (!token.equals(this.tokens.removeLast()));
/*     */     }
/*     */ 
/*     */     public int result()
/*     */     {
/* 108 */       if (this.tokens.isEmpty())
/* 109 */         return 0;
/* 110 */       if (((String)this.tokens.getLast()).equals(">"))
/* 111 */         return -1;
/* 112 */       return 1;
/*     */     }
/*     */ 
/*     */     public void addOpening(String token) {
/* 116 */       this.tokens.add(token);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.impl.MarkupBoxBuilder
 * JD-Core Version:    0.6.2
 */