/*    */ package pm.eclipse.editbox.impl;
/*    */ 
/*    */ import pm.eclipse.editbox.IBoxBuilder;
/*    */ 
/*    */ public abstract class AbstractBoxBuilder
/*    */   implements IBoxBuilder
/*    */ {
/*    */   protected String name;
/*  9 */   protected int tabSize = 1;
/*    */   protected StringBuilder text;
/* 11 */   protected int caretOffset = -1;
/*    */ 
/*    */   public String getName() {
/* 14 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 18 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public void setTabSize(int tabSize) {
/* 22 */     this.tabSize = tabSize;
/*    */   }
/*    */ 
/*    */   public void setText(StringBuilder sb) {
/* 26 */     this.text = sb;
/*    */   }
/*    */ 
/*    */   public int getTabSize() {
/* 30 */     return this.tabSize;
/*    */   }
/*    */ 
/*    */   public void setCaretOffset(int newCarretOffset) {
/* 34 */     this.caretOffset = newCarretOffset;
/*    */   }
/*    */ 
/*    */   public int getCaretOffset() {
/* 38 */     return this.caretOffset;
/*    */   }
/*    */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.impl.AbstractBoxBuilder
 * JD-Core Version:    0.6.2
 */