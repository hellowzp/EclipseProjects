/*     */ package pm.eclipse.editbox.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import pm.eclipse.editbox.Box;
/*     */ 
/*     */ public class MarkupBuilder2 extends MarkupBoxBuilder
/*     */ {
/*     */   int lineNr;
/*     */ 
/*     */   protected void addLine(int start, int end, int offset, boolean empty)
/*     */   {
/*  13 */     Line l = new Line();
/*  14 */     l.nbr = this.lineNr;
/*  15 */     l.start = start;
/*  16 */     l.end = end;
/*  17 */     l.offset = offset;
/*  18 */     l.empty = empty;
/*  19 */     this.lineNr += 1;
/*  20 */     detectType(l);
/*     */ 
/*  22 */     addLine(l);
/*     */   }
/*     */ 
/*     */   private void detectType(Line l) {
/*  26 */     if (l.empty) {
/*  27 */       l.type = LineType.EMPTY_LINE;
/*  28 */       return;
/*     */     }
/*  30 */     String line = this.text.substring(l.start, l.end).trim();
/*  31 */     int closeOpen = countCloseOpen(line);
/*  32 */     if (closeOpen > 0) {
/*  33 */       if ((line.length() > 2) && (line.charAt(0) == '<') && (line.charAt(1) != '/') && (line.charAt(1) != '!') && (line.charAt(1) != '%') && (!line.endsWith("/>"))) {
/*  34 */         l.type = LineType.OPEN_TAG;
/*  35 */         l.tag = getWord(line, 1);
/*     */       }
/*     */     }
/*  38 */     else if (closeOpen < 0) {
/*  39 */       int idx = line.lastIndexOf("</");
/*  40 */       if ((idx > -1) && (idx < line.length() - 3)) {
/*  41 */         l.type = LineType.CLOSE_TAG;
/*  42 */         l.tag = getWord(line, idx + 2);
/*  43 */         return;
/*     */       }
/*     */     }
/*  46 */     l.type = LineType.TEXT;
/*     */   }
/*     */ 
/*     */   private void addLine(Line l) {
/*  50 */     switch ($SWITCH_TABLE$pm$eclipse$editbox$impl$MarkupBuilder2$LineType()[l.type.ordinal()]) {
/*     */     case 1:
/*  52 */       openTag(l);
/*  53 */       this.emptyPrevLine = false;
/*  54 */       break;
/*     */     case 2:
/*  56 */       closeTag(l);
/*  57 */       this.emptyPrevLine = false;
/*  58 */       break;
/*     */     case 3:
/*  60 */       freeText(l);
/*  61 */       closeParent(l);
/*  62 */       this.emptyPrevLine = false;
/*  63 */       break;
/*     */     case 4:
/*  65 */       emptyLine(l);
/*  66 */       this.emptyPrevLine = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void closeParent(Line l)
/*     */   {
/*  72 */     String t = this.text.substring(l.start, l.end).trim();
/*  73 */     if ((t.endsWith("/>")) && (!t.contains("<"))) {
/*  74 */       Box b = this.currentbox;
/*  75 */       if ((isType(b, LineType.OPEN_TAG)) && (!isClosed(b))) {
/*  76 */         data(b).isClosed = true;
/*  77 */       } else if (isType(b, LineType.TEXT)) {
/*  78 */         b = this.currentbox.parent;
/*  79 */         if ((isType(b, LineType.OPEN_TAG)) && (!isClosed(b)))
/*  80 */           data(b).isClosed = true;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void emptyLine(Line l) {
/*     */   }
/*     */ 
/*     */   private void closeTag(Line l) {
/*  89 */     Box b = findClosingBox(l, this.currentbox);
/*  90 */     if (b == null) {
/*  91 */       freeText(l);
/*  92 */       return;
/*     */     }
/*     */ 
/*  95 */     data(b).isClosed = true;
/*  96 */     collapseOpenBoxes(b);
/*  97 */     this.currentbox = b;
/*  98 */     extendbox(this.currentbox, l);
/*     */   }
/*     */ 
/*     */   private void collapseOpenBoxes(Box b) {
/* 102 */     List children = new ArrayList(b.children());
/* 103 */     for (Box c : children) {
/* 104 */       collapseOpenBoxes(c);
/*     */     }
/* 106 */     if ((data(b).type == LineType.OPEN_TAG) && (!data(b).isClosed) && (b.children().isEmpty()) && 
/* 107 */       (b.parent != null) && (b.parent.data != null) && (!data(b.parent).isClosed) && (data(b.parent).type == LineType.OPEN_TAG)) {
/* 108 */       b.parent.children().remove(b);
/* 109 */       b.parent.hasChildren = (!b.parent.children().isEmpty());
/* 110 */       this.boxes.remove(b);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Box findClosingBox(Line l, Box box)
/*     */   {
/* 117 */     if (box == null)
/* 118 */       return null;
/* 119 */     if (isOpening(box, l.tag))
/* 120 */       return box;
/* 121 */     if (box.parent != null)
/* 122 */       for (Box b : box.parent.children())
/* 123 */         if ((b != box) && (isOpening(b, l.tag)))
/* 124 */           return b;
/* 125 */     return findClosingBox(l, box.parent);
/*     */   }
/*     */ 
/*     */   private boolean isOpening(Box box, String tag) {
/* 129 */     BoxData d = data(box);
/* 130 */     return (d != null) && (tag != null) && (d.type == LineType.OPEN_TAG) && (!d.isClosed) && (d.tag != null) && (tag.equals(d.tag));
/*     */   }
/*     */ 
/*     */   private BoxData data(Box box) {
/* 134 */     return (BoxData)box.data;
/*     */   }
/*     */ 
/*     */   private void freeText(Line l) {
/* 138 */     if (this.currentbox.offset < l.offset) {
/* 139 */       Box b = isClosed(this.currentbox) ? this.currentbox.parent : this.currentbox;
/* 140 */       this.currentbox = newbox(l, b);
/* 141 */     } else if ((this.currentbox.offset == l.offset) && ((this.emptyPrevLine) || (isType(this.currentbox, LineType.OPEN_TAG)))) {
/* 142 */       Box b = (isClosed(this.currentbox)) || (isType(this.currentbox, LineType.TEXT)) ? this.currentbox.parent : this.currentbox;
/* 143 */       this.currentbox = newbox(l, b);
/* 144 */     } else if (this.currentbox.offset == l.offset) {
/* 145 */       extendbox(this.currentbox, l);
/* 146 */     } else if ((isType(this.currentbox, LineType.OPEN_TAG)) && (!isClosed(this.currentbox))) {
/* 147 */       Box b = isType(this.currentbox, LineType.TEXT) ? this.currentbox.parent : this.currentbox;
/* 148 */       this.currentbox = newbox(l, b);
/*     */     } else {
/* 150 */       this.currentbox = this.currentbox.parent;
/* 151 */       freeText(l);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isClosed(Box b) {
/* 156 */     return (b.data != null) && (data(b).isClosed);
/*     */   }
/*     */ 
/*     */   private boolean isType(Box b, LineType type) {
/* 160 */     return (b != null) && (b.data != null) && (data(b).type == type);
/*     */   }
/*     */ 
/*     */   private void openTag(Line l) {
/* 164 */     BoxData d = data(this.currentbox);
/* 165 */     if (((d != null) && (d.type == LineType.OPEN_TAG) && (!d.isClosed)) || (this.currentbox.parent == null) || (this.currentbox.parent.data == null)) {
/* 166 */       this.currentbox = newbox(l, this.currentbox);
/*     */     } else {
/* 168 */       this.currentbox = this.currentbox.parent;
/* 169 */       openTag(l);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void extendbox(Box box, Line l) {
/* 174 */     box.end = l.end;
/* 175 */     if ((box.tabsStart < 0) && (this.lineHasStartTab))
/* 176 */       box.tabsStart = l.start;
/* 177 */     updateEndsOffset(l, box);
/* 178 */     updateParentEnds(box);
/*     */   }
/*     */ 
/*     */   protected void updateEndsOffset(Line l, Box b) {
/* 182 */     int n = l.end - l.start + l.offset;
/* 183 */     if (n >= b.maxLineLen) {
/* 184 */       b.maxLineLen = n;
/* 185 */       b.maxEndOffset = b.end;
/*     */     }
/*     */ 
/* 188 */     int off = b.offset - l.offset;
/* 189 */     if (off > 0) {
/* 190 */       b.tabsStart = l.start;
/* 191 */       b.offset = l.offset;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void updateParentEnds(Box box)
/*     */   {
/* 198 */     Box b = box.parent;
/* 199 */     while (b != null) {
/* 200 */       if (b.end < box.end)
/* 201 */         b.end = box.end;
/* 202 */       if (b.maxLineLen <= box.maxLineLen) {
/* 203 */         b.maxEndOffset = box.maxEndOffset;
/* 204 */         b.maxLineLen = box.maxLineLen;
/*     */       }
/* 206 */       b = b.parent;
/*     */     }
/*     */   }
/*     */ 
/*     */   private Box newbox(Line l, Box parent)
/*     */   {
/* 212 */     Box b = newbox(l.start, l.end, l.offset, parent);
/* 213 */     if (parent != null)
/* 214 */       parent.addChild(b);
/* 215 */     BoxData d = new BoxData();
/* 216 */     d.type = l.type;
/* 217 */     d.tag = l.tag;
/* 218 */     b.data = d;
/* 219 */     updateParentEnds(b);
/* 220 */     return b;
/*     */   }
/*     */ 
/*     */   class BoxData
/*     */   {
/*     */     MarkupBuilder2.LineType type;
/*     */     String tag;
/*     */     boolean isClosed;
/* 243 */     int minOffsetLineWithTabs = 2147483647;
/* 244 */     int startLineWithTabs = -1;
/* 245 */     int minOffsetLineWithNoTabs = 2147483647;
/* 246 */     int startLineWithNoTabs = -1;
/*     */ 
/*     */     BoxData()
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   class Line
/*     */   {
/*     */     int nbr;
/*     */     int start;
/*     */     int end;
/*     */     int offset;
/*     */     boolean empty;
/*     */     MarkupBuilder2.LineType type;
/*     */     String tag;
/*     */ 
/*     */     Line()
/*     */     {
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 235 */       return MarkupBuilder2.this.text.substring(this.start, this.end);
/*     */     }
/*     */   }
/*     */ 
/*     */   static enum LineType
/*     */   {
/* 224 */     OPEN_TAG, CLOSE_TAG, TEXT, EMPTY_LINE;
/*     */   }
/*     */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.impl.MarkupBuilder2
 * JD-Core Version:    0.6.2
 */