/*    */ package pm.eclipse.editbox.actions;
/*    */ 
/*    */ import org.eclipse.core.commands.AbstractHandler;
/*    */ import org.eclipse.core.commands.ExecutionEvent;
/*    */ import org.eclipse.core.commands.ExecutionException;
/*    */ import org.eclipse.ui.IEditorPart;
/*    */ import org.eclipse.ui.IWorkbench;
/*    */ import org.eclipse.ui.IWorkbenchPage;
/*    */ import org.eclipse.ui.IWorkbenchWindow;
/*    */ import org.eclipse.ui.PlatformUI;
/*    */ import pm.eclipse.editbox.EditBoxActivator;
/*    */ import pm.eclipse.editbox.IBoxDecorator;
/*    */ import pm.eclipse.editbox.impl.BoxProviderRegistry;
/*    */ 
/*    */ public class UnselectBox extends AbstractHandler
/*    */ {
/*    */   public Object execute(ExecutionEvent arg0)
/*    */     throws ExecutionException
/*    */   {
/* 16 */     IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
/* 17 */     if (activeEditor != null) {
/* 18 */       IBoxDecorator decorator = EditBoxActivator.getDefault().getProviderRegistry().getDecorator(activeEditor);
/* 19 */       if (decorator != null)
/* 20 */         decorator.unselectCurrentBox();
/*    */     }
/* 22 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.actions.UnselectBox
 * JD-Core Version:    0.6.2
 */