/*    */ package pm.eclipse.editbox.actions;
/*    */ 
/*    */ import org.eclipse.core.commands.Command;
/*    */ import org.eclipse.core.commands.ParameterizedCommand;
/*    */ import org.eclipse.jface.action.ActionContributionItem;
/*    */ import org.eclipse.jface.action.CoolBarManager;
/*    */ import org.eclipse.jface.action.IAction;
/*    */ import org.eclipse.jface.action.IContributionItem;
/*    */ import org.eclipse.jface.action.IToolBarManager;
/*    */ import org.eclipse.jface.action.ToolBarContributionItem;
/*    */ import org.eclipse.jface.window.ApplicationWindow;
/*    */ import org.eclipse.swt.widgets.Display;
/*    */ import org.eclipse.ui.IStartup;
/*    */ import org.eclipse.ui.IWorkbench;
/*    */ import org.eclipse.ui.IWorkbenchWindow;
/*    */ import org.eclipse.ui.PlatformUI;
/*    */ import org.eclipse.ui.commands.ICommandService;
/*    */ import org.eclipse.ui.handlers.IHandlerService;
/*    */ import pm.eclipse.editbox.EditBoxActivator;
/*    */ 
/*    */ public class EditBoxStartup
/*    */   implements IStartup
/*    */ {
/*    */   public void earlyStartup()
/*    */   {
/* 23 */     if (!EditBoxActivator.getDefault().isEnabled()) {
/* 24 */       return;
/*    */     }
/* 26 */     EditBoxActivator.getDefault().setEnabled(false);
/*    */ 
/* 28 */     IWorkbench workbench = PlatformUI.getWorkbench();
/* 29 */     workbench.getDisplay().asyncExec(new Runnable()
/*    */     {
/*    */       public void run() {
/* 32 */         ICommandService commandService = (ICommandService)PlatformUI.getWorkbench().getService(ICommandService.class);
/* 33 */         Command command = commandService.getCommand("pm.eclipse.editbox.actions.EnableEditBoxCmd");
/* 34 */         IWorkbenchWindow window = PlatformUI.getWorkbench().getActiveWorkbenchWindow();
/* 35 */         if (window != null) {
/* 36 */           IHandlerService handlerService = (IHandlerService)window.getWorkbench().getService(IHandlerService.class);
/* 37 */           if (handlerService != null)
/*    */             try {
/* 39 */               handlerService.executeCommand(new ParameterizedCommand(command, null), null);
/* 40 */               EditBoxStartup.this.toggle(window);
/*    */             } catch (Exception e) {
/* 42 */               EditBoxActivator.logError(this, "Failed to enable EditBox at startup", e);
/*    */             }
/*    */         }
/*    */       }
/*    */     });
/*    */   }
/*    */ 
/*    */   protected void toggle(IWorkbenchWindow window)
/*    */   {
/* 52 */     if ((window instanceof ApplicationWindow)) {
/* 53 */       CoolBarManager coolBarManager = ((ApplicationWindow)window).getCoolBarManager();
/* 54 */       if (coolBarManager != null) {
/* 55 */         IContributionItem item = coolBarManager.find("pm.eclipse.editbox.ActionSetId");
/* 56 */         if ((item instanceof ToolBarContributionItem)) {
/* 57 */           IToolBarManager tbMgr2 = ((ToolBarContributionItem)item).getToolBarManager();
/* 58 */           if (tbMgr2 != null) {
/* 59 */             IContributionItem item2 = tbMgr2.find("pm.eclipse.editbox.EnableEditboxActionId");
/* 60 */             if ((item2 instanceof ActionContributionItem))
/* 61 */               ((ActionContributionItem)item2).getAction().setChecked(true);
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.actions.EditBoxStartup
 * JD-Core Version:    0.6.2
 */