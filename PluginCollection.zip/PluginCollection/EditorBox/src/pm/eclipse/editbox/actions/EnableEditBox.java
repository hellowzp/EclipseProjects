/*     */ package pm.eclipse.editbox.actions;
/*     */ 
/*     */ import org.eclipse.core.commands.AbstractHandler;
/*     */ import org.eclipse.core.commands.ExecutionEvent;
/*     */ import org.eclipse.core.commands.ExecutionException;
/*     */ import org.eclipse.jface.action.IAction;
/*     */ import org.eclipse.jface.viewers.ISelection;
/*     */ import org.eclipse.ui.IPartListener2;
/*     */ import org.eclipse.ui.IWorkbench;
/*     */ import org.eclipse.ui.IWorkbenchPage;
/*     */ import org.eclipse.ui.IWorkbenchPart;
/*     */ import org.eclipse.ui.IWorkbenchPartReference;
/*     */ import org.eclipse.ui.IWorkbenchWindow;
/*     */ import org.eclipse.ui.IWorkbenchWindowActionDelegate;
/*     */ import org.eclipse.ui.PlatformUI;
/*     */ import pm.eclipse.editbox.EditBoxActivator;
/*     */ import pm.eclipse.editbox.IBoxDecorator;
/*     */ import pm.eclipse.editbox.IBoxProvider;
/*     */ import pm.eclipse.editbox.impl.BoxProviderRegistry;
/*     */ 
/*     */ public class EnableEditBox extends AbstractHandler
/*     */   implements IWorkbenchWindowActionDelegate
/*     */ {
/*     */   public static final String COMMAND_ID = "pm.eclipse.editbox.actions.EnableEditBoxCmd";
/*     */   private IWorkbenchWindow win;
/*     */   private BoxProviderRegistry registry;
/*     */ 
/*     */   public void init(IWorkbenchWindow window)
/*     */   {
/*  29 */     this.win = window;
/*     */   }
/*     */ 
/*     */   public Object execute(ExecutionEvent event) throws ExecutionException {
/*  33 */     runCommand(!EditBoxActivator.getDefault().isEnabled());
/*  34 */     return null;
/*     */   }
/*     */ 
/*     */   public void run(IAction action) {
/*  38 */     boolean checked = !EditBoxActivator.getDefault().isEnabled();
/*  39 */     runCommand(checked);
/*  40 */     action.setChecked(checked);
/*     */   }
/*     */ 
/*     */   public void selectionChanged(IAction action, ISelection selection) {
/*     */   }
/*     */ 
/*     */   private void runCommand(boolean isChecked) {
/*  47 */     if (this.win == null)
/*  48 */       this.win = PlatformUI.getWorkbench().getActiveWorkbenchWindow();
/*  49 */     if (!isChecked) {
/*  50 */       releaseDecorators();
/*     */     } else {
/*  52 */       getRegistry().setPartListener(this.win.getPartService(), new BoxDecoratorPartListener());
/*  53 */       IWorkbenchPart part = this.win.getActivePage().getActiveEditor();
/*  54 */       if (part != null)
/*  55 */         setVisible(part, true);
/*     */     }
/*  57 */     EditBoxActivator.getDefault().setEnabled(isChecked);
/*     */   }
/*     */ 
/*     */   public void dispose() {
/*  61 */     releaseDecorators();
/*     */   }
/*     */ 
/*     */   private void releaseDecorators() {
/*  65 */     if (this.win != null)
/*  66 */       getRegistry().removePartListener(this.win.getPartService());
/*  67 */     getRegistry().releaseDecorators();
/*     */   }
/*     */ 
/*     */   protected BoxProviderRegistry getRegistry() {
/*  71 */     if (this.registry == null)
/*  72 */       this.registry = EditBoxActivator.getDefault().getProviderRegistry();
/*  73 */     return this.registry;
/*     */   }
/*     */ 
/*     */   protected void setVisible(IWorkbenchPartReference partRef, boolean visible) {
/*  77 */     IWorkbenchPart part = partRef.getPart(false);
/*  78 */     if (part != null)
/*  79 */       setVisible(part, visible);
/*     */   }
/*     */ 
/*     */   protected void setVisible(IWorkbenchPart part, boolean visible) {
/*  83 */     IBoxDecorator decorator = getRegistry().getDecorator(part);
/*  84 */     if ((decorator == null) && (!visible))
/*  85 */       return;
/*  86 */     if (decorator == null)
/*  87 */       decorator = decorate(part);
/*  88 */     if (decorator != null)
/*  89 */       decorator.enableUpdates(visible);
/*     */   }
/*     */ 
/*     */   protected IBoxDecorator decorate(IWorkbenchPart part) {
/*  93 */     IBoxDecorator result = null;
/*  94 */     IBoxProvider provider = getRegistry().getBoxProvider(part);
/*  95 */     if (provider != null)
/*  96 */       result = provider.decorate(part);
/*  97 */     if (result != null)
/*  98 */       getRegistry().addDecorator(result, part);
/*  99 */     return result;
/*     */   }
/*     */ 
/*     */   protected void undecorate(IWorkbenchPartReference partRef) {
/* 103 */     IWorkbenchPart part = partRef.getPart(false);
/* 104 */     if (part != null) {
/* 105 */       IBoxDecorator decorator = getRegistry().removeDecorator(part);
/* 106 */       if (decorator != null)
/* 107 */         decorator.getProvider().releaseDecorator(decorator); 
/*     */     }
/*     */   }
/*     */ 
/*     */   class BoxDecoratorPartListener implements IPartListener2 {
/*     */     BoxDecoratorPartListener() {
/*     */     }
/*     */ 
/* 115 */     public void partActivated(IWorkbenchPartReference partRef) { EnableEditBox.this.setVisible(partRef, true); }
/*     */ 
/*     */     public void partBroughtToTop(IWorkbenchPartReference partRef)
/*     */     {
/* 119 */       EnableEditBox.this.setVisible(partRef, true);
/*     */     }
/*     */ 
/*     */     public void partClosed(IWorkbenchPartReference partRef) {
/* 123 */       EnableEditBox.this.undecorate(partRef);
/*     */     }
/*     */ 
/*     */     public void partDeactivated(IWorkbenchPartReference partRef) {
/*     */     }
/*     */ 
/*     */     public void partHidden(IWorkbenchPartReference partRef) {
/* 130 */       EnableEditBox.this.setVisible(partRef, false);
/*     */     }
/*     */ 
/*     */     public void partInputChanged(IWorkbenchPartReference partRef) {
/* 134 */       EnableEditBox.this.setVisible(partRef, false);
/* 135 */       EnableEditBox.this.setVisible(partRef, true);
/*     */     }
/*     */ 
/*     */     public void partOpened(IWorkbenchPartReference partRef) {
/*     */     }
/*     */ 
/*     */     public void partVisible(IWorkbenchPartReference partRef) {
/* 142 */       EnableEditBox.this.setVisible(partRef, true);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.actions.EnableEditBox
 * JD-Core Version:    0.6.2
 */