package pm.eclipse.editbox;

import java.util.Collection;
import org.eclipse.ui.IWorkbenchPart;

public abstract interface IBoxProvider
{
  public abstract String getId();

  public abstract String getName();

  public abstract boolean supports(IWorkbenchPart paramIWorkbenchPart);

  public abstract IBoxDecorator decorate(IWorkbenchPart paramIWorkbenchPart);

  public abstract void releaseDecorator(IBoxDecorator paramIBoxDecorator);

  public abstract IBoxSettings getEditorsBoxSettings();

  public abstract IBoxSettingsStore getSettingsStore();

  public abstract IBoxSettings createSettings();

  public abstract IBoxDecorator createDecorator();

  public abstract Collection<String> getBuilders();

  public abstract IBoxBuilder createBoxBuilder(String paramString);
}

/* Location:           D:\application_programs\pm.eclipse.editbox_0.0.23.jar
 * Qualified Name:     pm.eclipse.editbox.IBoxProvider
 * JD-Core Version:    0.6.2
 */