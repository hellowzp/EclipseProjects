package cn.edu.nwsuaf.qhs.artificialintelligence.eightpuzzle;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

public class EightPuzzleAlgorithm {

	private int[][] array = new int[3][3];
	private int[][] target = new int[3][3];
	private EightPuzzle ep, target_ep;
	private int depth = 0;
	private Stack<EightPuzzle> ep_stack = new Stack<EightPuzzle>();
	private LinkedList<EightPuzzle> searched_list = new LinkedList<EightPuzzle>();
	private Queue<EightPuzzle> ep_queue = new LinkedList<EightPuzzle>();

	public EightPuzzleAlgorithm() {

		// ��ʼ��ջ�Ͷ��У��Լ��б�
		ep_stack.clear();
		searched_list.clear();
		ep_queue.clear();

		Scanner scanner = new Scanner(System.in);
		// �����ʼλ��
		System.out.println("�������ʼλ�ã���������0�����հ׿飬���磺2 8 3 1 0 4 7 6 5����");
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				array[i][j] = scanner.nextInt();
			}
		}
		// ����Ŀ��λ��
		System.out.println("������Ŀ��λ�ã���������0�����հ׿飬���磺2 8 3 1 4 0 7 6 5����");
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				target[i][j] = scanner.nextInt();
			}
		}

		ep = new EightPuzzle(array);
		ep.setDepth(depth);
		// ����ջ��Ԫ��
		ep_stack.push(ep);
		target_ep = new EightPuzzle(target);
		scanner.close();
		// ���ö���Ԫ��
		ep_queue.offer(ep);
	}

	// �����������
	// ջ�ķ�ʽʵ��
	public void depthFirstSearch() {
		System.out.println("���������������·����");
		if (!searched_list.isEmpty())
			searched_list.clear();
		
		while (!ep_stack.isEmpty()) {
			EightPuzzle move_ep = ep_stack.pop();
			depth = move_ep.getDepth();
			move_ep.getPostion();
			int x = move_ep.getBlankPos_x(), y = move_ep.getBlankPos_y();
			move_ep.print();
			searched_list.add(move_ep);

			if (move_ep.isEquals(target_ep)) {
				System.out.println("�����ҵ��ˣ��ѩn��b��");
				return;
			}
			depth++;
			EightPuzzle temp = null;

			temp = move_ep.depthClone();

			if (EightPuzzleOperator.canMove(x, y, 1)) {
				temp = EightPuzzleOperator.movePosition(move_ep, 1);
				temp.setDepth(depth);
				if (!searched_list.contains(temp)) {
					ep_stack.push(temp);
				}
			}
			if (EightPuzzleOperator.canMove(x, y, 2)) {
				temp = EightPuzzleOperator.movePosition(move_ep, 2);
				temp.setDepth(depth);
				if (!searched_list.contains(temp)) {
					ep_stack.push(temp);
				}
			}
			if (EightPuzzleOperator.canMove(x, y, -1)) {
				temp = EightPuzzleOperator.movePosition(move_ep, -1);
				temp.setDepth(depth);
				if (!searched_list.contains(temp)) {
					ep_stack.push(temp);
				}
			}
			if (EightPuzzleOperator.canMove(x, y, -2)) {
				temp = EightPuzzleOperator.movePosition(move_ep, -2);
				temp.setDepth(depth);
				if (!searched_list.contains(temp)) {
					ep_stack.push(temp);
				}
			}
		}
		System.out.println("�ǳ��ź���û������������Ҫ��Ŀ�꣡%>_<%");
	}

	// �����������(�н磬������Ϊ5)
	// ջ�ķ�ʽʵ������
	public void boundedDepthFirstSearch() {
		System.out.println("�н����������������·����");
		if (!searched_list.isEmpty())
			searched_list.clear();
		while (!ep_stack.isEmpty()) {
			EightPuzzle move_ep = ep_stack.pop();
			depth = move_ep.getDepth();
			move_ep.getPostion();
			int x = move_ep.getBlankPos_x(), y = move_ep.getBlankPos_y();
			move_ep.print();
			searched_list.add(move_ep);

			if (move_ep.isEquals(target_ep)) {
				System.out.println("�����ҵ��ˣ��ѩn��b��");
				return;
			}
			if (depth < 4) {
				depth++;
				EightPuzzle temp = null;

				temp = move_ep.depthClone();

				if (EightPuzzleOperator.canMove(x, y, 1)) {
					temp = EightPuzzleOperator.movePosition(move_ep, 1);
					temp.setDepth(depth);
					if (!searched_list.contains(temp)||(searched_list.contains(temp)&&
							searched_list.get(searched_list.indexOf(temp)).getDepth()!=temp.getDepth())) {
						ep_stack.push(temp);
					}
				}
				if (EightPuzzleOperator.canMove(x, y, 2)) {
					temp = EightPuzzleOperator.movePosition(move_ep, 2);
					temp.setDepth(depth);
					if (!searched_list.contains(temp)||(searched_list.contains(temp)&&
							searched_list.get(searched_list.indexOf(temp)).getDepth()!=temp.getDepth())) {
						ep_stack.push(temp);
					}
				}
				if (EightPuzzleOperator.canMove(x, y, -1)) {
					temp = EightPuzzleOperator.movePosition(move_ep, -1);
					temp.setDepth(depth);
					if (!searched_list.contains(temp)||(searched_list.contains(temp)&&
							searched_list.get(searched_list.indexOf(temp)).getDepth()!=temp.getDepth())) {
						ep_stack.push(temp);
					}
				}
				if (EightPuzzleOperator.canMove(x, y, -2)) {
					temp = EightPuzzleOperator.movePosition(move_ep, -2);
					temp.setDepth(depth);
					if (!searched_list.contains(temp)||(searched_list.contains(temp)&&
							searched_list.get(searched_list.indexOf(temp)).getDepth()!=temp.getDepth())) {
						ep_stack.push(temp);
					}
				}
			}
		}
		System.out.println("�ǳ��ź���û������������Ҫ��Ŀ�꣡%>_<%");
	}

	// ���ȣ���ȣ���������ʵ��
	public void breadthFirstSearch() {
		if (!searched_list.isEmpty())
			searched_list.clear();
		System.out.println("���������������·����");
		while (!ep_queue.isEmpty()) {
			EightPuzzle move_ep = ep_queue.poll();
			depth = move_ep.getDepth();
			move_ep.getPostion();
			int x = move_ep.getBlankPos_x(), y = move_ep.getBlankPos_y();
			move_ep.print();
			searched_list.add(move_ep);

			if (move_ep.isEquals(target_ep)) {
				System.out.println("�����ҵ��ˣ��ѩn��b��");
				return;
			}
			depth++;
			EightPuzzle temp = null;

			temp = move_ep.depthClone();

			if (EightPuzzleOperator.canMove(x, y, 1)) {
				temp = EightPuzzleOperator.movePosition(move_ep, 1);
				temp.setDepth(depth);
				if (!searched_list.contains(temp)) {
					ep_queue.offer(temp);
				}
			}
			if (EightPuzzleOperator.canMove(x, y, 2)) {
				temp = EightPuzzleOperator.movePosition(move_ep, 2);
				temp.setDepth(depth);
				if (!searched_list.contains(temp)) {
					ep_queue.offer(temp);
				}
			}
			if (EightPuzzleOperator.canMove(x, y, -1)) {
				temp = EightPuzzleOperator.movePosition(move_ep, -1);
				temp.setDepth(depth);
				if (!searched_list.contains(temp)) {
					ep_queue.offer(temp);
				}
			}
			if (EightPuzzleOperator.canMove(x, y, -2)) {
				temp = EightPuzzleOperator.movePosition(move_ep, -2);
				temp.setDepth(depth);
				if (!searched_list.contains(temp)) {
					ep_queue.offer(temp);
				}
			}
		}
		System.out.println("�ǳ��ź���û������������Ҫ��Ŀ�꣡%>_<%");
	}

	/*public void search() {
		// this.getPostion();
		// this.depthFirstSearch(blankPos_x, blankPos_y, 1);
		this.depthFirstSearch();
		this.boundedDepthFirstSearch();
		this.breadthFirstSearch();
	}*/

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EightPuzzleAlgorithm epa = new EightPuzzleAlgorithm();
		epa.depthFirstSearch();
		epa.boundedDepthFirstSearch();
		epa.breadthFirstSearch();
	}
	/*
	 * �������� ��1��2 8 3 1 0 4 7 6 5 2 8 3 1 4 0 7 6 5 ��2��2 8 3 1 0 4 7 6 5
	 * 
	 */
}
