                ____________________________________________________
               /    ______                 __    __                /|
       	      /    / ____/                / /   /_/               / |
             /    / /_____  _____________/ /________________     / /
            /    / __  / / / / __  /  __/ __  / / __  / ___/    / /
           /     ___/ / /_/ / / / /__  / / / / / / / / ___/    / /
          /    /_____/_____/_/ /_/____/_/ /_/_/_/ /_/____/    / /
         /                                                   / /
        /     Web : www.sunshine2k.de                       / /    		
       /            www.bastian-molkenthin.de              / /
      /       Mail: webmaster@sunshine2k.de               / /
     /___________________________________________________/ /
     \____________________________________________________/


SimpleParser:
-------------
SimpleParser is a little application that evaluates simple mathematical expressions using three different algorithms. For more information, please have a look at the included article.

Commandline Options:
--------------------
If running without commandline arguments, the hardcoded terms I used for testing are evaluated.
But you can specify a valid term as first commandline argument to calculate this one.

Running the app (Java Runtime required):
----------------------------------------
Best choice to run the code is to open the project in Netbeans and run it from there.
If you insist running the app from commandline, then go to subdirectory build\class and type:
java SimpleParser.ParserTest


If you use my code, please give me some credits and/or link my website.

Comments, bugs, criticism? Mail me!

Sunshine, October 2K10

