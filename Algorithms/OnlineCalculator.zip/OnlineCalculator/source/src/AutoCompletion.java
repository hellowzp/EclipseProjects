/*
 * That's some kind of lame intellisense clone for my online calculator.
 * Author : Sunshine
 * WEB : www.sunshine2k.de
 */

import java.awt.FontMetrics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Arrays;
import javax.swing.JApplet;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;

import javax.swing.MenuElement;
import javax.swing.MenuSelectionManager;

/**
 *
 * @author Sunshine
 */
public class AutoCompletion extends JPopupMenu {
    
    private final static String[] KEYWORDS = {
        "sin", "cos", "tan", "asin", "acos", "atan", "sinh", "cosh", "tanh",
        "log", "log10", "sqrt", "floor", "round", "todeg", "torad"}; 
    
    private JApplet applet;
    private JTextField parentField;
    private FontMetrics fm;
    public boolean Enabled;
    
    public AutoCompletion(JTextField parentfield, JApplet applet)
    {
        super();
        this.parentField = parentfield;
        this.applet = applet;
        Arrays.sort(KEYWORDS);
        MyMenuItem.backgroundColor = applet.getBackground();
        fm = parentField.getGraphics().getFontMetrics();
        Enabled = true;

        // add a keylistener to the textfield
        parentField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent ke)
            {
                // on pressing enter in parentField we should select the currently
                // selected item in the menu so send explicitly the keyevent
                // note that the parent textfield has always the focus.
                if (ke.getKeyCode() == KeyEvent.VK_ENTER)
                {
                    getThis().requestFocus();
                    getThis().processKeyEvent(ke);
                }
                // if we type a non-actionkey show intellisense menu
                else if (!ke.isActionKey())
                    MyShow();                
            }
        });
        
       
        // this listener receives the Enter KeyEvent which was explicitly sent
        // from the parentField
        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER)
                {
                    // find selected menuitem
                    MenuElement[] path = MenuSelectionManager.defaultManager().getSelectedPath();
                    for (int i = 0; i < path.length; i++)
                        if (path[i].getComponent() instanceof JMenuItem)
                            ((JMenuItem)path[i]).doClick(); // simulate a leftclick
                }
            }
        });
        
    }
    
    public AutoCompletion getThis() { return this; }
    
    private String getCurrentToken(String text)
    {
        int i;
        for (i = text.length() - 1; i >= 0; i--)
        {
            if (text.charAt(i) == ' ') break;
        }
        return text.substring(i+1);
    }
    
    private int getTokenIndex(String text)
    {
        int i;
        for (i = text.length() - 1; i >= 0; i--)
        {
            if (text.charAt(i) == ' ') break;
        }
        return i+1;
    }
    
    
    public void MyShow()
    {
        if (!Enabled) 
        { 
            setVisible(false); 
            return; 
        }
        
        // ActionListener for each menuitem in our lust
        // insert selected command in textfield
        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                StringBuffer s = new StringBuffer(parentField.getText());
                int index = getTokenIndex(parentField.getText()); 
                s.delete(index, s.length());
                s.insert(index, e.getActionCommand());
                parentField.setText(s.toString());
                setVisible(false);
            }  
        };

        JMenuItem item = null;
        this.removeAll();
        
        // get beginning of word user is typing
        String s = getCurrentToken(parentField.getText());
        
        this.setVisible(false);
        if (s.isEmpty()) 
            return;
        
        
        boolean itemAdded = false;
        for (int i = 0; i < KEYWORDS.length; i++)
        {
            if (KEYWORDS[i].startsWith(s) && !(s.length() > KEYWORDS[i].length()))
            {
                item = new JMenuItem(KEYWORDS[i]);
                item.addActionListener(actionListener);
                add(item);
                itemAdded = true;
            }
        }
        if (itemAdded)
            this.show(applet, parentField.getX() + fm.stringWidth(parentField.getText())//+ parentField.getText().length() * 5 
                    , parentField.getY() + parentField.getHeight() );
        
        parentField.requestFocus();
        
    }    

}
