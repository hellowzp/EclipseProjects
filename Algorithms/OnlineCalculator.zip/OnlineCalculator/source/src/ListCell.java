/*
 * Author : Sunshine
 * WEB : www.sunshine2k.de
 */

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import javax.swing.JList;
import javax.swing.JPanel;

/**
 * This class represents one entry in the resultbox. In fact every line in the
 * resultbox is a ownerdrawn extended JPanel.
 * @author Sunshine
 */
public class ListCell extends JPanel {
    
    private Object value;
    private int index;             
    private boolean isSelected;
    private boolean cellHasFocus;
    private JList list;
    
    private Font font = new Font("Courier", Font.BOLD, 12);
            
    /** Creates a new instance of ListCell */
    public ListCell(JList list, Object value, int index, 
                boolean isSelected, boolean cellHasFocus) 
    {
        this.list = list;
        this.value = value;
        this.index = index;
        this.isSelected = isSelected;
        this.cellHasFocus = cellHasFocus;
    }
    
    /**
     * Called from parent control the draw the entry.
     * @param g The graphics handle.
     */
    @Override
    protected void paintComponent(Graphics g) 
    {
        super.paintComponent(g);
     
        String text = "";
        FontMetrics fm = g.getFontMetrics(font);
        g.setFont(font);
        // background
        g.setColor(isSelected ? list.getSelectionBackground() : list
            .getBackground());
        g.fillRect(0, 0, getWidth(), getHeight());
        
        // a separator needs special handle
        if (((ListItem)value).getType() == ItemType.SEPARATOR)
        {
            g.setColor(Color.GRAY);
            g.drawLine(0, getHeight()/2, getWidth(), getHeight()/2);
            return;
        }
        
        // write text line
        switch ( ((ListItem)value).getType() )
        {
            case RESULT:
            {
                g.setColor(Color.GREEN);
                text = "Result : ";
            }
            break;
            case TERM:
            {
                g.setColor(Color.ORANGE);
                text = "Term : ";
            }
            break;
            case ERROR:
            {
                g.setColor(Color.RED);
                text = "Error : ";
            }
            break;
            default:
            {
                g.setColor(Color.BLACK);
                text = "";
            }
            break;
        }
        g.drawString(text, 0, fm.getAscent());
        g.setColor(Color.DARK_GRAY);
        g.drawString(((ListItem)value).getString(), fm.stringWidth(text), fm.getAscent());
    }
    
    /**
     * Called from parent control to determine the size of one entry.
     * @return the dimension of this entry. In fact the dimension of the
     * text string of this entry.
     */
    @Override
    public Dimension getPreferredSize() {
        String text;
        Graphics g = getGraphics();
        FontMetrics fm = g.getFontMetrics(font);
        switch ( ((ListItem)value).getType() )
        {
            case ERROR: text = "Error : "; break;
            case TERM: text = "Term : "; break;
            case RESULT: text = "Result : "; break;
            default: text = "";
        }
        text += ((ListItem)value).getString();
        return new Dimension(fm.stringWidth(text), fm.getHeight());
            
      }
    
}

