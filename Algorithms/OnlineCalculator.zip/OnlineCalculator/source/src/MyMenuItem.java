/*
 * That's some kind of lame intellisense clone for my online calculator.
 * Author : Sunshine
 * WEB : www.sunshine2k.de
 */

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import javax.swing.JMenuItem;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 *
 * @author Sunshine
 */
public class MyMenuItem extends JMenuItem {
    
    private Font font = new Font("Courier", Font.BOLD, 12);
    
    private String text;
    public static Color backgroundColor;
    private boolean status;
    
    public MyMenuItem(final String text) { 
        super(text); 
        this.text = text; 
         this.addChangeListener(new ChangeListener() {

            public void stateChanged(ChangeEvent e) {
                invalidate();
            }
             
         });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        FontMetrics fm = g.getFontMetrics(font);
        g.setFont(font);
        
        g.setColor(isArmed() ? Color.WHITE : backgroundColor);
        g.fillRect(0, 0, this.getWidth(), this.getHeight());
        
        g.setColor(isArmed() ? Color.RED : Color.BLACK);
        g.drawString(text , 0, fm.getAscent());
    }
    
    @Override
    public Dimension getPreferredSize()
    {
        return new Dimension(100, 20);
    }
}
