/*
 * Author : Sunshine
 * WEB : www.sunshine2k.de
 */

/**
 * This structure identifies the type of a entry inside the resultbox.
 * @author Sunshine
 */
public enum ItemType {
    DEFAULT, RESULT, TERM, ERROR, SEPARATOR
}
