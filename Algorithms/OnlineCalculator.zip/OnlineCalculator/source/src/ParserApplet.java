/*
 * ParserApplet.java
 *
 * Created on 25. Juni 2008, 16:02
 * 
 * Author : Sunshine
 * WEB : www.sunshine2k.de
 * 
 * 5-Sep-2008:
 * - added autocompletion feature
 */


import Parser.*;
import java.awt.AWTException;
import java.awt.Robot;
//import java.awt.Toolkit;
//import java.awt.datatransfer.Clipboard;
//import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ListSelectionModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;



/**
 * The applet.
 * @author  Sunshine
 */
public class ParserApplet extends javax.swing.JApplet {
    
    public static final int APPLETWIDTH = 450;
    public static final int APPLETHEIGHT = 430;
    private String menuItemTexts[] = {"Copy Line To Textfield", "Clear List"};
    
    private ListData listdata;
    private Parser parser;
    private AutoCompletion autoCompletion;
    
    /** Initializes the applet ParserApplet */
    @Override
    public void init() {
        try {
            java.awt.EventQueue.invokeAndWait(new Runnable() {
                public void run() {
                    initComponents();
                }
            });
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        this.setSize(APPLETWIDTH, APPLETHEIGHT);
        resultList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION );
        resultList.setCellRenderer(new MyListRenderer());
        
        listdata = new ListData(resultList);

        // init parser
        parser = new Parser();
        
        
        // add mouselistener for resultlist popupmenu 
        this.resultList.addMouseListener(new MouseAdapter() {
            
            // as we need the index of the list where to cursor is,
            // we would normally have to select it with a leftclick.
            // Cause the popupmenu is triggered by a rightclick, we
            // simulate a leftclick to select a listitem.
            @Override
            public void mousePressed(MouseEvent evt) {
                if ( SwingUtilities.isRightMouseButton(evt) )
                {
                    try
 					{
 						Robot robot = new java.awt.Robot();
 						robot.mousePress(InputEvent.BUTTON1_MASK);
 						robot.mouseRelease(InputEvent.BUTTON1_MASK);
 					}
 					catch (AWTException ex) {  ex.toString(); }
   
				}  
            }     
            
            // show contextmenu by rightclicking on list
            @Override
            public void mouseReleased(MouseEvent evt) {
                if (evt.isPopupTrigger()) 
                    showPopupMenu(evt);
            }
            
        });
        
        // add evaluatebutton handler
        this.evaluateButton.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) {
                evalButtonHandler();
            }
            
        });
        
        // react on return inside expression-textbox
        this.termField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent ke)
            {
                if (ke.getKeyCode() == KeyEvent.VK_ENTER)
                    if (autoCompletion != null && !autoCompletion.isVisible())
                        evaluateButton.doClick();  
            }
        });
        termField.requestFocus();
        
        // additional output base stuff
        for (int i = 2; i <= 36; i++)
            this.outBaseCombobox.addItem(Integer.toString(i));
        
        this.outBaseCheckbox.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED)
                {
                    outBaseLabel.setEnabled(true);
                    outBaseCombobox.setEnabled(true);
                }
                else if (e.getStateChange() == ItemEvent.DESELECTED)
                {
                    outBaseLabel.setEnabled(false);
                    outBaseCombobox.setEnabled(false);
                }
            }
            
        });
        
        // enable/disable autocompletion feature
        this.AutoCompleteCheckbox.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED)
                {
                    AutocompleteLabel.setEnabled(true);
                    autoCompletion.Enabled = true;
                }
                else if (e.getStateChange() == ItemEvent.DESELECTED)
                {
                    autoCompletion.Enabled = false;
                    AutocompleteLabel.setEnabled(false);
                }
            }
        });
        
        // simulate a button click cause evaluating a term for the first term
        // takes quite long - the java VM loads there several things.
        // So force this delay here at startup. 
        this.evaluateButton.doClick();
        this.listdata.clear();
        
        // load and init autocompletion
        autoCompletion = new AutoCompletion(this.termField, this);
    };
    
    /**
     * @return The this-reference of this applet.
     */
    public javax.swing.JApplet getThis() { return this; }
    
    /**
     * Called when user presses 'Evaluate' or Return inside the expression box.
     * Evaluates the entered expression and updates the resultbox.
     */
    public void evalButtonHandler()
    {
        
        double res;
        
        if (termField.getText().length() == 0)
        {
            listdata.addItem("No expression entered.", ItemType.DEFAULT);
            resultList.ensureIndexIsVisible(listdata.size()-1);
            return;
        }
        
        // normally insert a separator between two calculations, but not at the very beginning
        if (resultList.getModel().getSize() != 0)
            listdata.addItem("", ItemType.SEPARATOR);
        
        parser.setTerm(termField.getText());
        listdata.addItem(termField.getText(), ItemType.TERM);
        
        try {
            res = parser.evaluate();
            listdata.addItem("" + res, ItemType.RESULT);
            
            // print result also in another numerical base
            if (this.outBaseCheckbox.isSelected())
            {
                int base = this.outBaseCombobox.getSelectedIndex()+2;
                
                // fix @ 4-Sep-08
                // if it's a negative number, remove the preceding minus sign
                // Possible improvement: should I implement two-complement for binary numbers?
                boolean neg = false;
                if (res < 0) { res = -res; neg = true; }
                String resbase = Bases.fromDec(Double.toString(res), base);
                listdata.addItem("In Base " + base + " : " + (neg ? "-" : "") +  resbase, ItemType.RESULT);
                // end fix
            }
            
            termField.select(0, termField.getText().length());
            
        } catch (InvalidBracketsException ex) {
            listdata.addItem("Invalid Bracket Term - " + ex.getMessage(), ItemType.ERROR);
        } catch (ParserException ex) {
            listdata.addItem("Parser Exception - " + ex.getMessage(), ItemType.ERROR);
        } catch (BaseConversionException ex) {
            listdata.addItem("Base Conversion Exception - " + ex.getMessage(), ItemType.ERROR);
        } 
        
        resultList.ensureIndexIsVisible(listdata.size()-1);
    }
    
    
    /**
     * Shows the resultbox popupmenu and handles the commands.
     * @param evt
     */
    public void showPopupMenu(MouseEvent evt)
    {
        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getActionCommand().equals(menuItemTexts[0]))
                {
                    // copy to clipboard - does not work in an applet cause of security reasons
                    /*
                    System.out.println(listdata.getString(resultList.getSelectedIndex()));
                    Clipboard systemClipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                    systemClipboard.setContents(new StringSelection(listdata.getString(resultList.getSelectedIndex())), null);
                     */
                    termField.setText(listdata.getString(resultList.getSelectedIndex()));
                    termField.requestFocus();
                    termField.select(0, termField.getText().length());
                }
                else if (e.getActionCommand().equals(menuItemTexts[1]))
                {
                    listdata.clear();
                }
                resultList.ensureIndexIsVisible(listdata.size()-1);
            }
            
        };
        JPopupMenu menu = new JPopupMenu();
        // copy line item
        JMenuItem item = new JMenuItem(this.menuItemTexts[0]);
        item.addActionListener(actionListener);
        menu.add(item);
        // clear list item
        item = new JMenuItem(this.menuItemTexts[1]);
        item.addActionListener(actionListener);
        menu.add(item);
      
        menu.show(resultList, evt.getX(), evt.getY()); 

    }
  
    @Override
    public String getAppletInfo() {
        return "Mathematical Expression Parser" + System.getProperty("line.separator") + 
               "------------------------------" + System.getProperty("line.separator") + 
               "Author: Sunshine" + System.getProperty("line.separator") + 
               "WEB: www.sunshine2k.de" + System.getProperty("line.separator") + 
               "     http://calc.sunshine2k.de" + System.getProperty("line.separator") + 
               "Version: 1.0" + System.getProperty("line.separator") + 
               "July, 2008";
    }

    /** This method is called from within the init() method to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        resultList = new javax.swing.JList();
        evaluateButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        termField = new javax.swing.JTextField();
        outBaseCheckbox = new javax.swing.JCheckBox();
        outBaseLabel = new javax.swing.JLabel();
        outBaseCombobox = new javax.swing.JComboBox();
        AutoCompleteCheckbox = new javax.swing.JCheckBox();
        AutocompleteLabel = new javax.swing.JLabel();

        jButton1.setText("jButton1");

        resultList.setBackground(new java.awt.Color(230, 230, 230));
        resultList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        resultList.setAutoscrolls(false);
        jScrollPane1.setViewportView(resultList);

        evaluateButton.setText("Evaluate");

        jLabel1.setText("Expression:");

        outBaseLabel.setText("Print result also in base:");
        outBaseLabel.setEnabled(false);

        outBaseCombobox.setEnabled(false);

        AutoCompleteCheckbox.setSelected(true);

        AutocompleteLabel.setText("Autocompletion");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 435, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(termField, javax.swing.GroupLayout.DEFAULT_SIZE, 375, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(AutoCompleteCheckbox)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(AutocompleteLabel))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(outBaseCheckbox)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(outBaseLabel)
                                .addGap(18, 18, 18)
                                .addComponent(outBaseCombobox, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 79, Short.MAX_VALUE)
                                .addComponent(evaluateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(termField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(outBaseCombobox, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(evaluateButton)
                        .addComponent(outBaseLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(outBaseCheckbox, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(AutoCompleteCheckbox, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AutocompleteLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 21, Short.MAX_VALUE))
                .addGap(24, 24, 24))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox AutoCompleteCheckbox;
    private javax.swing.JLabel AutocompleteLabel;
    private javax.swing.JButton evaluateButton;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JCheckBox outBaseCheckbox;
    private javax.swing.JComboBox outBaseCombobox;
    private javax.swing.JLabel outBaseLabel;
    private javax.swing.JList resultList;
    private javax.swing.JTextField termField;
    // End of variables declaration//GEN-END:variables

}
