/*
 * Author : Sunshine
 * WEB : www.sunshine2k.de
 */

import java.awt.Component;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

/**
 *
 * @author Sunshine
 */
public class MyListRenderer implements ListCellRenderer {

    public Component getListCellRendererComponent(JList list, Object value, int index, 
                            boolean isSelected, boolean cellHasFocus) 
    {
        return new ListCell(list, value, index, isSelected, cellHasFocus);

    }

}
