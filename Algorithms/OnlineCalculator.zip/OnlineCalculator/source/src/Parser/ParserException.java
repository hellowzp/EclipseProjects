/*
 * Author : Sunshine
 * WEB : www.sunshine2k.de
 */

package Parser;

/**
 * Main parser exception thrown if term to be evaluated is invalid.
 * @author Sunshine (www.sunshine2k.de)
 *
 */
public class ParserException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ParserException() { super(); }
	
	public ParserException(String s) {
		super(s);
	}

}
