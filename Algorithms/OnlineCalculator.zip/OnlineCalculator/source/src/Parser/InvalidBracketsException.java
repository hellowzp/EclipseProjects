/*
 * Author : Sunshine
 * WEB : www.sunshine2k.de
 */

package Parser;

/**
 * Parser Exception if mathematical term contains an invalid bracket term.
 * @author Sunshine (www.sunshine2k.de)
 *
 */
public class InvalidBracketsException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public InvalidBracketsException() { super(); }
	
	public InvalidBracketsException(String s) {
		super(s);
	}
}
