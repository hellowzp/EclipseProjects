/* 
 * Author : Sunshine
 * WEB : www.sunshine2k.de
 */

package Parser;

/**
 * This class provides methods to convert decimal numbers to other numeric bases and the other
 * way round.
 * @author Sunshine (www.sunshine2k.de)
 * @version 1.0
 */
public class Bases {
	
	/**
	 * Converts the given character to a number.
	 * @param c the character. Can be a digit (0...9) or a letter (a...z)
	 * @return the number that the character represents in decimal base. Behavior is not determined
	 * if an invalid character is specified.
	 */
	private static int convToNum(char c)
	{
		// make char upper case
		if (c >= '0' && c <= '9')
			return (int)(c - '0');
		else if (c >= 'a' && c <= 'z') 
			c = (char)((byte)c - (byte)'a' + (byte)'A');
		return (int)(10 + c - 'A');
		
	}
	
	/**
	 * Converts a decimal number to a character.
	 * @param num a number between 0 and 36
	 * @return the character if a valid number was specified, otherwise -1.
	 */
	private static char convToChar(int num)
	{
		if (num >= 0 && num <= 9)
			return (char)(num + '0');
		else if (num >= 10 && num <= 36)
			return (char)(num - 10 + 'A');
		else return (char)-1;
	}
	
	/**
	 * Checks if given string number only contains valid characters for its specified base.
	 * @param num the number to be checked
	 * @param base the numeric base. Valid bases are between 2 and 36.
	 * @return true if the string represents a valid number in the given numeric base.
	 */
	private static boolean isValid(String num, int base)
	{
		boolean result = true;
		char c;
		if (base < 2 || base > 36) return false;
		for (int i = 0; i < num.length(); i++)
		{
			c = num.charAt(i);
			if (c == '.') continue;
			if (base <= 10)
			{
				if (c >= '0'+base || c < '0')
				{
					//System.out.println("Base Error: " + c + "  " + base);
					result = false;
				}
			}
			else if (base > 10)
			{
				// make char upper case
				if (c >= 'a' && c <= 'z') 
					c = (char)((byte)c - (byte)'a' + (byte)'A');
				if ( (c >= 'A'+base-10 || c < 'A') && (c < '0' || c > '9'))
				{
					//System.out.println("Base Error: " + num.charAt(i) + "  " + base);
					result = false;
				}
			}
		}
		return result;
	}
	
	
	/**
	 * Transforms the given number specified in numeric base to decimal
	 * @param num the number to convert to base 10
	 * @param base the base in which number is given
	 * @return the converted number; if an error occurs or the given number does
	 * not match with the specified base, the return value is -1.
	 */
	public static double toDec(double num, double base) throws BaseConversionException 
	{
		int b = (int)base;
		String s = Double.toString(num);
		return toDec(s, b);
	}
	
	/**
	 * Transforms the given number string in base 'base' to decimal
	 * @param num the number to convert to base 10
	 * @param base the base in which number is given
	 * @return the converted number; if an error occurs or the given number does
	 * not match with the specified base, the return value is -1.
	 */
	public static double toDec(String num, int base) throws BaseConversionException
	{
		if (base < 2 || base > 36) 
            throw new BaseConversionException("Illegal base specified!");    //return -1;
        if (!isValid(num, base))
            throw new BaseConversionException(num + " not in base " + base);
        
		// convert it
		double res = 0;
		int count = 0;
		
		int dotpos = num.indexOf('.');
		if (dotpos == -1)		// we have a integer
		{
			for (int i = num.length() - 1; i >= 0; i--)
			{
				res += convToNum(num.charAt(i)) * Math.pow(base, count++);
			}
			return res;
		}
		else					// we have a decimal
		{
			for (int i = dotpos-1; i >= 0; i--)
				res += convToNum(num.charAt(i)) * Math.pow(base, count++);
			count = -1;
			for (int i = dotpos+1; i < num.length(); i++)
				res += convToNum(num.charAt(i)) * Math.pow(base, count--);
			return res;
		}
	}
	
	/**
	 * Converts the given number string with specified base in a decimal string.
	 * The number string must be an integer and not a fraction.
	 * @param num the number string to convert
	 * @param base the numeric base in which num is given
	 * @return the decimal value of num as a string
	 */
	private static String fromDecInt(String num, int base)
	{
		String res = "";
		int n = Integer.parseInt(num);
		int mod;
		while (n != 0)
		{
			mod = n % base;
			res = convToChar(mod) + res;
			n = n / base;
		}
		return res;
	}
	
	/**
	 * Converts the given number string with specified base in a decimal string.
	 * @param num the number string to convert
	 * @param base the numeric base in which num is given
	 * @return the decimal value of num as a string. If an error occurs or the number string
	 * 		   does not match the specified base, null is returned.
	 */
	public static String fromDec(String num, int base) throws BaseConversionException
	{
		String res = "";
		if (!isValid(num, 10)) 
			throw new BaseConversionException();    //return null;
		
		int dotpos = num.indexOf('.');
		if (dotpos == -1)		// we have a integer
		{
			return fromDecInt(num, base);
		}
		else		// we have a decimal
		{
			// first process the part before the dot - like a normal integer
			String part1 = num.substring(0, dotpos);
			if (part1.length() > 0)
				res = fromDecInt(part1, base);
			res += '.';
			
			// now process the part after the dot
			String part2 = num.substring(dotpos, num.length());
			double part2num = Double.parseDouble(part2);
			
			// to be sure break after a predefined number of iterations
			int count = 0;
			while (part2num != 0)
			{
				part2num *= base;
				res = res + convToChar((int)Math.floor(part2num));
				part2num -= (int)Math.floor(part2num);
				if (++count == 20) break;
			}

		}
		return res;
	}
	
	
	/*
	 * TEST MAIN
	 */
    /*
	public static void main(String[] args)
	{
		
	}*/

}
