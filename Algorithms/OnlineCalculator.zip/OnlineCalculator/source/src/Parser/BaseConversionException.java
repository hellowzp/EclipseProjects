/*
 * Author : Sunshine
 * WEB : www.sunshine2k.de
 */

package Parser;

/**
 *
 * @author Sunshine
 */
public class BaseConversionException extends Exception {
    
    public BaseConversionException() { super(); }
	
	public BaseConversionException(String s) {
		super(s);
	}
}
