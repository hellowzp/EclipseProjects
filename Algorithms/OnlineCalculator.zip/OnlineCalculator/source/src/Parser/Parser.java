/*
 * Author : Sunshine
 * WEB : www.sunshine2k.de
 */

package Parser;

/**
 * This class parses a mathematical term given as a string, evaluates it and returns the result
 * as a number.
 * @author Sunshine (www.sunshine2k.de)
 * @version 1.0
 */
public class Parser {
	
	private StringBuffer myterm;
	
    public Parser() { }
    
	public Parser(String term)
	{
		setTerm(term);
	}
        
    public void setTerm(String term)
    {
       this.myterm = new StringBuffer(term);
    }
	
	
	/**
	 * Returns the last position of c inside the most inner pair of brackets in the string s.
	 * @param s the string in which is searched for
	 * @param c the character to find
	 * @return the index of the first occurrence of the character
	 */
	private int find(String s, char c)
	{
		int count = 0;
		//for (int i = 0; i < s.length(); i++)
        for (int i = s.length() - 1; i >= 0; i--)
		{
            if (s.charAt(i) == '(') count++;
			if (s.charAt(i) == ')') count--;
			if (s.charAt(i) == c && count == 0) return i;
		}
		return -1;
	}
	
	/**
	 * Returns the index of the first occurrence of c1 directly followed by c2 inside the string.
	 * It's the same as searching for the substring composed of c1 + c2.
	 * @param s the string in which is searched for
	 * @param c1 the first character to find
	 * @param c2 the second character to find
	 * @return the index of the first occurrence of the character sequence c1 and c2.
	 */
	private int find(String s, char c1, char c2)
	{
		int count = 0;
		for (int i = 0; i < s.length() - 1; i++)
		{
			if (s.charAt(i) == '(') count++;
			if (s.charAt(i) == ')') count--;
			if (s.charAt(i) == c1 && s.charAt(i+1) == c2 && count == 0) return i;
		}
		return -1;
	}
	
	/**
	 * Finds the string inside the first pair of brackets in s.
	 * @param s the string in which the inner argument of the first brackets pair is searched for
	 * @return the substring inside the first pair of brackets in s. If s contains not a valid bracket term,
	 * e.g does not contain '(' and ')', an empty string is returned.
	 */
	private String getFirstBracketsString(String s)
	{
		int index = s.indexOf("(");
        // fix 5-Sep-2008:
        if (index == -1) return "";
        // end fix
        int count = 0;
        for (int i = index; i < s.length(); i++)
        {
            if (s.charAt(i) == '(') count++;
            else if (s.charAt(i) == ')') count--;
            if (s.charAt(i) == ')' && count == 0)
                return s.substring(index+1, i); 
        }
        return "";
		//int index2 = s.indexOf(")");
		//if (index > -1 && index2 > -1 && index2 > index)
		//	return s.substring(index+1, index2);
		//else
		//	return "";
	}
	
	/**
	 * Deletes all spaces inside the given string.
	 * @param s the string from which all spaces are removed.
	 * @return the string without any spaces at all.
	 */
	private String deleteSpaces(String s)
	{
		//System.out.println("Begin deleteSpaces: " + s);
		StringBuffer buf = new StringBuffer(s);
		for (int i = 0; i < buf.length(); i++)
		{
			if (buf.charAt(i) == ' ')
			{
				buf.deleteCharAt(i);
				i--;
			}
		}
		//System.out.println("After deleteSpaces: " + buf.toString());
		return buf.toString();
	}
	
	/**
	 * That's the main function. It parses and evaluates the mathematical term 
	 * given in the constructor.
	 * @return the numerical result of the term.
	 * @throws InvalidBracketsException
	 * @throws ParserException
	 */
	public double evaluate() throws InvalidBracketsException, ParserException, BaseConversionException 
	{ 
		String str = deleteSpaces(myterm.toString().toLowerCase());
		return evaluate(str); 
	}
	
	/**
	 * Parses and evaluates the mathematical term given in the constructor.
	 * @param s the term to evaluate
	 * @return the numerical result of the term.
	 * @throws InvalidBracketsException
	 * @throws ParserException
	 */
	private double evaluate(String s) throws InvalidBracketsException, ParserException, BaseConversionException 
	{
		int index;
        
        // something is wrong
        if (s.equals(""))
            throw new ParserException("Empty string");
		
		// if we a minus/plus sign before a number, insert a zero
		if (s.charAt(0) == '-' || s.charAt(0) == '+')
			s = '0' + s;
        
        // fix @ 4-Sep-08
        for (int i = 0; i < s.length(); i++)
        {
            if (s.charAt(i) == '-' && !Character.isDigit(s.charAt(i-1)))
                    s = s.substring(0, i) + '0' + s.substring(i+1, s.length());                 
        }
        // end fix
		
		// note: the order of the following operators is important!
		
		if ((index = find(s, '|')) >= 0)
		{
			//System.out.println(s.substring(0, index));
			//System.out.println(s.substring(index+1, s.length()));
			
			return ((int)(evaluate(s.substring(0, index))) | 
					(int)(evaluate(s.substring(index+1, s.length()))));
		}	
		else if ((index = find(s, '&')) >= 0)
		{
			//System.out.println(s.substring(0, index));
			//System.out.println(s.substring(index+1, s.length()));
			
			return ((int)(evaluate(s.substring(0, index))) & 
					(int)(evaluate(s.substring(index+1, s.length()))));
		}	
		
		else if ((index = find(s, '#')) >= 0)
		{
			//System.out.println(s.substring
			//System.out.println(s.substring(index+1, s.length()));
			
			return ((int)(evaluate(s.substring(0, index))) ^ 
					(int)(evaluate(s.substring(index+1, s.length()))));
		}	
		
		// x>>y is the same as x / (2^y)
		else if ((index = find(s, '>', '>')) >= 0)
		{
			//System.out.println(s.substring(0, index));
			//System.out.println(s.substring(index+2, s.length()));
			
			return (int)(evaluate(s.substring(0, index)) / 
					Math.pow(2, evaluate(s.substring(index+2, s.length()))));
		}
		
		// x<<y is the same as x * (2^y)
		else if ((index = find(s, '<', '<')) >= 0)
		{
			//System.out.println(s.substring(0, index));
			//System.out.println(s.substring(index+2, s.length()));
			
			return (int)(evaluate(s.substring(0, index)) * 
					Math.pow(2, evaluate(s.substring(index+2, s.length()))));
		}
		else if ((index = find(s, '-')) >= 0)
		{
			//System.out.println(s.substring(0, index));
			//System.out.println(s.substring(index+1, s.length()));
			
			return (evaluate(s.substring(0, index)) - 
					evaluate(s.substring(index+1, s.length())));
		}
		else if ((index = find(s, '+')) >= 0)
		{
			//System.out.println(s.substring(0, index));
			//System.out.println(s.substring(index+1, s.length()));
			
			return (evaluate(s.substring(0, index)) + 
					evaluate(s.substring(index+1, s.length())));
		}
		else if ((index = find(s, '*')) >= 0)
		{
			//System.out.println(s.substring(0, index));
			//System.out.println(s.substring(index+1, s.length()));
			
			return (evaluate(s.substring(0, index)) * 
					evaluate(s.substring(index+1, s.length())));
		}
		else if ((index = find(s, '/')) >= 0)
		{
			//System.out.println(s.substring(0, index));
			//System.out.println(s.substring(index+1, s.length()));
			
			return (evaluate(s.substring(0, index)) / 
					evaluate(s.substring(index+1, s.length())));
		}
		else if ((index = find(s, '%')) >= 0)
		{
			//System.out.println(s.substring(0, index));
			//System.out.println(s.substring(index+1, s.length()));
			
			return (evaluate(s.substring(0, index)) % 
					evaluate(s.substring(index+1, s.length())));
		}
		else if ((index = find(s, '^')) >= 0)
		{
			//System.out.println(s.substring(0, index));
			//System.out.println(s.substring(index+1, s.length()));
			
			return Math.pow(evaluate(s.substring(0, index)), 
							evaluate(s.substring(index+1, s.length())));
		}
		
		// remove brackets at the beginning and end
		if (s.charAt(0) == '(')
			if (s.charAt(s.length()-1) == ')')
				return (evaluate(s.substring(1, s.length()-1)));
			else
				throw new InvalidBracketsException(s);
		
		// handle mathematical functions
		else if (s.startsWith("sqrt"))
			return Math.sqrt(evaluate(getFirstBracketsString(s)));
		else if (s.startsWith("log10"))
			return Math.log10(evaluate(getFirstBracketsString(s)));
		else if (s.startsWith("log"))
			return Math.log(evaluate(getFirstBracketsString(s)));
		else if (s.startsWith("asin"))
			return Math.asin(evaluate(getFirstBracketsString(s)));
		else if (s.startsWith("acos"))
			return Math.acos(evaluate(getFirstBracketsString(s)));
		else if (s.startsWith("atan"))
			return Math.atan(evaluate(getFirstBracketsString(s)));
		else if (s.startsWith("sinh"))
			return Math.sinh(evaluate(getFirstBracketsString(s)));
		else if (s.startsWith("cosh"))
			return Math.cosh(evaluate(getFirstBracketsString(s)));
		else if (s.startsWith("tanh"))
			return Math.tanh(evaluate(getFirstBracketsString(s)));
        else if (s.startsWith("sin"))
			return Math.sin(evaluate(getFirstBracketsString(s)));
		else if (s.startsWith("cos"))
			return Math.cos(evaluate(getFirstBracketsString(s)));
		else if (s.startsWith("tan"))
			return Math.tan(evaluate(getFirstBracketsString(s)));
		else if (s.startsWith("todeg"))
			return Math.toDegrees(evaluate(getFirstBracketsString(s)));
		else if (s.startsWith("torad"))
			return Math.toRadians(evaluate(getFirstBracketsString(s)));
		else if (s.startsWith("round"))
			return Math.round(evaluate(getFirstBracketsString(s)));
		else if (s.startsWith("floor"))
			return Math.floor(evaluate(getFirstBracketsString(s)));
		else if (s.startsWith("pi"))
			return Math.PI;
		else if (s.startsWith("e"))
			return Math.E;
		
		// just for fun :-)
		else if (s.startsWith("rand"))
			return Math.random();
		
		// here check if argument is given in a special numeric base
		if ((index = find(s, '@')) >= 0)
		{
            // DOES NOT WORK
			//return Bases.toDec(evaluate(s.substring(0, index)), 
			//		           evaluate(s.substring(index+1, s.length())));
            int base = (int)(evaluate(s.substring(index+1, s.length())));
            //Integer.parseInt(s.substring(index+1, s.length()));
            return Bases.toDec(s.substring(0, index), base);
		}
		else if (s.startsWith("!"))
		{
			double tmp = evaluate(s.substring(1, s.length()));
			StringBuffer strbuf = new StringBuffer(Bases.fromDec(Double.toString(tmp),2));
			for (int i = 0; i < strbuf.length(); i++)
			{
				if (strbuf.charAt(i) == '0')
					strbuf.setCharAt(i, '1');
				else if (strbuf.charAt(i) == '1')
					strbuf.setCharAt(i, '0');
			}
			return Bases.toDec(strbuf.toString(), 2);
		}
		
		try {
			return Double.parseDouble(s);
		} catch (NumberFormatException ex) {
			throw new ParserException(s);
		}
	}

	
	public static void Print(String s, double res)
	{
		System.out.println("Term = " + s + "  = " + res);
	}
	
	
	/**
     * A main class for easy testing.
	 * @param args
	 */
    /*
	public static void main(String[] args) {
		
		long start = System.currentTimeMillis();
		String s = "3+";	
		Parser parseTest = new Parser(s);
		
		double res = 0;
		try {
			res = parseTest.evaluate();
		}
		catch (InvalidBracketsException ex) {
			System.out.println(ex.toString());
		}
		catch (ParserException ex) {
			System.out.println(ex.toString());
		}
        catch (BaseConversionException ex) {
			System.out.println(ex.toString());
		}
		
		long duration = System.currentTimeMillis() - start;
		System.out.println("Duration: " + duration);
		Print(s, res);

	}*/

}
