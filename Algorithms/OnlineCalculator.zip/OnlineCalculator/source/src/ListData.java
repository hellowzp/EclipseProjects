/*
 * Author : Sunshine
 * WEB : www.sunshine2k.de
 */


import java.util.Vector;
import javax.swing.JList;

/**
 * This class holds and handles the items for the resultbox.
 * @author Sunshine
 */
public class ListData {
    
    private JList list;                 // parent list
    private Vector<ListItem> items;     // the actual listdata
    
    public ListData(JList list) {
        this.list = list;
        this.items = new Vector<ListItem>();
    }
    
    public void addItem(String s) 
    { 
        items.add(new ListItem(s, ItemType.DEFAULT)); 
        update();
    }
    
    public void addItem(String s, ItemType t) 
    {
        items.add(new ListItem(s, t));
        update();
    }
    
    private void update() { list.setListData(items); }
    
    public void clear() 
    {
        items.clear();
        update();
    }
    
    public int size() { return items.size(); }
    
    public String getString(int index)
    {
        if (index < 0 || index > items.size() ) return "";
        ListItem li = items.get(index);
        if (li.getType() == ItemType.SEPARATOR)
            return "Separator";
        else
            return li.getString();
        
    }

}

/**
 * Helper class which represents one dataitem in the list.
 * @author Sunshine
 */
class ListItem {
    
    private String text;
    private ItemType type;
    
    public ListItem(String s, ItemType t) 
    { 
        this.text = s; 
        this.type = t;
    }
    
    public ListItem(String s) { this(s, ItemType.DEFAULT); }
    
    public String getString() { return text; }
    public ItemType getType() { return type; }
    
    
}
