                ____________________________________________________
               /    ______                 __    __                /|
       	      /    / ____/                / /   /_/               / |
             /    / /_____  _____________/ /________________     / /
            /    / __  / / / / __  /  __/ __  / / __  / ___/    / /
           /     ___/ / /_/ / / / /__  / / / / / / / / ___/    / /
          /    /_____/_____/_/ /_/____/_/ /_/_/_/ /_/____/    / /
         /                                                   / /
        /     Web : www.sunhine2k.de                        / /
       /            www.bastian-molkenthin.de              / /    					
      /       Mail: webmaster@sunhine2k.de                / /
     /___________________________________________________/ /
     \____________________________________________________/


Online Calculator:
==================

Version 1.1

So after 4 months after completing my little calculator, I publish now my source.
It's clean coded and some of you may find the source really useful - e.g. my autocomplete feature. I hope you don't expect a full-blown parser engine - I kept it as simple as possible - and the result is a straightforward recursive parsing function.

So have fun - and please, if you use this source or parts of it or do anything with it - please give my some credits and link to my site!


Comments, bugs, criticism? Mail me!

Sunshine, December 2K8


