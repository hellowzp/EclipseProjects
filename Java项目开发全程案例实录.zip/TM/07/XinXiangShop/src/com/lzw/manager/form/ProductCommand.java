package com.lzw.manager.form;
public class ProductCommand {
	private String page="1";
	
	public String getPage() {
		return page;
	}

	public void setPage(String action) {
		this.page = action;
	}
}
