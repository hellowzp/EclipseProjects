package com.lzw.manager.form;
public class LoginForm {
	private String manager;
	private String PWD;
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	public String getPWD() {
		return PWD;
	}
	public void setPWD(String pwd) {
		PWD = pwd;
	}
}
