package com.lzw.manager.form;
public class SuperTypeForm {
	String delid[];

	public String[] getDelid() {
		return delid;
	}
	public void setDelid(String[] delid) {
		this.delid = delid;
	}
}
