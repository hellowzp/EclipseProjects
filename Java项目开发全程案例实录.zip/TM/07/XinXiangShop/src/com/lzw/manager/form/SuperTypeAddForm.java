package com.lzw.manager.form;
public class SuperTypeAddForm {
	private String typename;

	public String getTypename() {
		return typename;
	}

	public void setTypename(String typename) {
		this.typename = typename;
	}
}
