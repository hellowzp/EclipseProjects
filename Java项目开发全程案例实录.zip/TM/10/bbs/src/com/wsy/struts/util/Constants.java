package com.wsy.struts.util;

public class Constants {
	public static final int  TOPIC_PAGE_SIZE=5;
}
