package res;
public class Resource {
}
