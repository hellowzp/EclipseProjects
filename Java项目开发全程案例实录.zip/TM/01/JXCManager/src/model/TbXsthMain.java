package model;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
public class TbXsthMain implements java.io.Serializable {
	private String xsthId;
	private String pzs;
	private String je;
	private String ysjl;
	private String khname;
	private String thdate;
	private String czy;
	private String jsr;
	private String jsfs;
	private Set tbXsthDetails = new HashSet(0);
	public TbXsthMain() {
	}
	public TbXsthMain(String xsthId,String pzs, String je, String ysjl, String khname,
			String thdate, String czy, String jsr, String jsfs) {
		this.xsthId=xsthId;
		this.pzs = pzs;
		this.je = je;
		this.ysjl = ysjl;
		this.khname = khname;
		this.thdate = thdate;
		this.czy = czy;
		this.jsr = jsr;
		this.jsfs = jsfs;
	}
	public String getXsthId() {
		return this.xsthId;
	}
	public void setXsthId(String xsthId) {
		this.xsthId = xsthId;
	}

	public String getPzs() {
		return this.pzs;
	}

	public void setPzs(String pzs) {
		this.pzs = pzs;
	}

	public String getJe() {
		return this.je;
	}

	public void setJe(String je) {
		this.je = je;
	}

	public String getYsjl() {
		return this.ysjl;
	}

	public void setYsjl(String ysjl) {
		this.ysjl = ysjl;
	}

	public String getKhname() {
		return this.khname;
	}

	public void setKhname(String khname) {
		this.khname = khname;
	}

	public String getThdate() {
		return this.thdate;
	}

	public void setThdate(String thdate) {
		this.thdate = thdate;
	}

	public String getCzy() {
		return this.czy;
	}

	public void setCzy(String czy) {
		this.czy = czy;
	}

	public String getJsr() {
		return this.jsr;
	}

	public void setJsr(String jsr) {
		this.jsr = jsr;
	}

	public String getJsfs() {
		return this.jsfs;
	}

	public void setJsfs(String jsfs) {
		this.jsfs = jsfs;
	}

	public Set getTbXsthDetails() {
		return this.tbXsthDetails;
	}

	public void setTbXsthDetails(Set tbXsthDetails) {
		this.tbXsthDetails = tbXsthDetails;
	}
}