package com.mwq.form;


public class SendLetterForm{
	private String content;
	private String toMan;

	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}

	public String getToMan() {
		return toMan;
	}
	public void setToMan(String toMan) {
		this.toMan = toMan;
	}
}