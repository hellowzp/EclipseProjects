/*==============================================================*/
/* DBMS name:      ORACLE Version 10g                           */
/* Created on:     2010-9-17 14:15:09                           */
/*==============================================================*/


alter table tb_bring_up_ontent
   drop constraint FK_TB_BRING_REFERENCE_TB_BRING;

alter table tb_bring_up_ontent
   drop constraint FK_TB_BRING_REFERENCE_TB_RECOR;

alter table tb_dept
   drop constraint FK_TB_DEPT_REFERENCE_TB_DEPT;

alter table tb_duty_info
   drop constraint FK_TB_DUTY__REFERENCE_TB_RECOR;

alter table tb_duty_info
   drop constraint FK_TB_DUTY__REFERENCE_TB_DEPT;

alter table tb_duty_info
   drop constraint FK_TB_DUTY__REFERENCE_TB_DUTY;

alter table tb_duty_info
   drop constraint FK_TB_DUTY__REFERENCE_TB_ACCES;

alter table tb_manager
   drop constraint FK_TB_MANAG_REFERENCE_TB_RECOR;

alter table tb_personal_info
   drop constraint FK_TB_PERSO_REFERENCE_TB_RECOR;

alter table tb_reckoning_info
   drop constraint FK_TB_RECKO_REFERENCE_TB_RECKO;

alter table tb_reckoning_info
   drop constraint FK_TB_RECKO_REFERENCE_TB_ACCOU;

alter table tb_reckoning_list
   drop constraint FK_TB_RECKO_REFERENCE_TB_RECKO;

alter table tb_reckoning_list
   drop constraint FK_TB_RECKO_REFERENCE_TB_RECOR;

alter table tb_record
   drop constraint FK_TB_RECOR_REFERENCE_TB_NATIO;

alter table tb_record
   drop constraint FK_TB_RECOR_REFERENCE_TB_NATIV;

alter table tb_rewards_and_punishment
   drop constraint FK_TB_REWAR_REFERENCE_TB_RECOR;

alter table tb_rewards_and_punishment
   drop constraint FK_TB_REWAR_REFERENCE_TB_DEPT;

alter table tb_rewards_and_punishment
   drop constraint FK_TB_REWAR_REFERENCE_TB_RECOR;

alter table tb_timecard
   drop constraint FK_TB_TIMEC_REFERENCE_TB_RECOR;

alter table tb_timecard
   drop constraint FK_TB_TIMEC_REFERENCE_TB_ACCOU;

alter table tb_timecard
   drop constraint FK_TB_TIMEC_REFERENCE_TB_DEPT;

alter table tb_timecard
   drop constraint FK_TB_TIMEC_REFERENCE_TB_RECOR;

drop table tb_accession_form cascade constraints;

drop table tb_account_item cascade constraints;

drop table tb_bring_up_content cascade constraints;

drop table tb_bring_up_ontent cascade constraints;

drop table tb_dept cascade constraints;

drop table tb_duty cascade constraints;

drop table tb_duty_info cascade constraints;

drop table tb_manager cascade constraints;

drop table tb_nation cascade constraints;

drop table tb_native_place cascade constraints;

drop table tb_personal_info cascade constraints;

drop table tb_reckoning cascade constraints;

drop table tb_reckoning_info cascade constraints;

drop table tb_reckoning_list cascade constraints;

drop table tb_record cascade constraints;

drop table tb_rewards_and_punishment cascade constraints;

drop table tb_timecard cascade constraints;

/*==============================================================*/
/* Table: tb_accession_form                                   */
/*==============================================================*/
create table tb_accession_form  (
   id                 int                             not null,
   name               varchar2(20)                    not null,
   constraint PK_TB_ACCESSION_FORM primary key (id)
);

comment on column tb_accession_form.id is
'����';

comment on column tb_accession_form.name is
'�ù���ʽ����';

/*==============================================================*/
/* Table: tb_account_item                                     */
/*==============================================================*/
create table tb_account_item  (
   id                 int                             not null,
   name               varchar2(10)                    not null,
   type               char(4)                         not null,
   unit               char(2)                         not null,
   is_timecard        char(2)                         not null,
   constraint PK_TB_ACCOUNT_ITEM primary key (id)
);

comment on column tb_account_item.id is
'����';

comment on column tb_account_item.name is
'��Ŀ����';

comment on column tb_account_item.type is
'���ͣ�����/�۳���';

comment on column tb_account_item.unit is
'��λ��ʱ/��/�ˣ�';

comment on column tb_account_item.is_timecard is
'�Ƿ����ڿ���';

/*==============================================================*/
/* Table: tb_bring_up_content                                 */
/*==============================================================*/
create table tb_bring_up_content  (
   id                 int                             not null,
   name               varchar2(40)                    not null,
   content            varchar2(100)                   not null,
   object             varchar2(100)                   not null,
   start_date         date                            not null,
   end_date           date                            not null,
   unit               varchar2(40)                    not null,
   lecturer           varchar2(10)                    not null,
   place              varchar2(60)                    not null,
   constraint PK_TB_BRING_UP_CONTENT primary key (id)
);

comment on column tb_bring_up_content.id is
'����';

comment on column tb_bring_up_content.name is
'��ѵ����';

comment on column tb_bring_up_content.content is
'��ѵ����';

comment on column tb_bring_up_content.object is
'��ѵ����';

comment on column tb_bring_up_content.start_date is
'��ѵ��ʼ����';

comment on column tb_bring_up_content.end_date is
'��ѵ��������';

comment on column tb_bring_up_content.unit is
'��ѵ��λ';

comment on column tb_bring_up_content.lecturer is
'��ѵ��ʦ';

comment on column tb_bring_up_content.place is
'��ѵ�ص�';

/*==============================================================*/
/* Table: tb_bring_up_ontent                                  */
/*==============================================================*/
create table tb_bring_up_ontent  (
   id                 int                             not null,
   bring_up_content_id int                             not null,
   record_id          int                             not null,
   score              int,
   up_to_grade        char(2),
   remark             varchar2(60),
   constraint PK_TB_BRING_UP_ONTENT primary key (id)
);

comment on column tb_bring_up_ontent.id is
'����';

comment on column tb_bring_up_ontent.bring_up_content_id is
'���';

comment on column tb_bring_up_ontent.record_id is
'���';

comment on column tb_bring_up_ontent.score is
'��ѵ�÷�';

comment on column tb_bring_up_ontent.up_to_grade is
'�Ƿ�ͨ��';

comment on column tb_bring_up_ontent.remark is
'��ע';

/*==============================================================*/
/* Table: tb_dept                                             */
/*==============================================================*/
create table tb_dept  (
   id                 int                             not null,
   parent_id          int                             not null,
   name               varchar2(20),
   constraint PK_TB_DEPT primary key (id)
);

comment on column tb_dept.id is
'����';

comment on column tb_dept.parent_id is
'���';

comment on column tb_dept.name is
'��������';

/*==============================================================*/
/* Table: tb_duty                                             */
/*==============================================================*/
create table tb_duty  (
   id                 int                             not null,
   name               varchar2(20)                    not null,
   constraint PK_TB_DUTY primary key (id)
);

comment on column tb_duty.id is
'����';

comment on column tb_duty.name is
'��������';

/*==============================================================*/
/* Table: tb_duty_info                                        */
/*==============================================================*/
create table tb_duty_info  (
   id                 int                             not null,
   dept_id            int                             not null,
   duty_id            int                             not null,
   accession_date     date                            not null,
   accession_form_id  int                             not null,
   dimission_date     date,
   dimission_reason   varchar2(100),
   first_pact_date    date,
   pact_start_date    date,
   pact_end_date      date,
   bank_name          varchar2(60),
   bank_NO            varchar2(30),
   society_safety_NO  varchar2(30),
   annuity_safety_NO  varchar2(30),
   dole_safety_NO     varchar2(30),
   medicare_safety_NO varchar2(30),
   compo_safety_NO    varchar2(30),
   accumulation_fund_NO varchar2(30),
   constraint PK_TB_DUTY_INFO primary key (id)
);

comment on column tb_duty_info.id is
'����';

comment on column tb_duty_info.dept_id is
'���';

comment on column tb_duty_info.duty_id is
'���';

comment on column tb_duty_info.accession_date is
'��ְ����';

comment on column tb_duty_info.accession_form_id is
'���';

comment on column tb_duty_info.dimission_date is
'��ְ����';

comment on column tb_duty_info.dimission_reason is
'��ְԭ��';

comment on column tb_duty_info.first_pact_date is
'ת������';

comment on column tb_duty_info.pact_start_date is
'��ǰ��ͬ��ʼ����';

comment on column tb_duty_info.pact_end_date is
'��ǰ��ͬ��������';

comment on column tb_duty_info.bank_name is
'��������';

comment on column tb_duty_info.bank_NO is
'���п���';

comment on column tb_duty_info.society_safety_NO is
'��ᱣ�պ�';

comment on column tb_duty_info.annuity_safety_NO is
'���ϱ��պ�';

comment on column tb_duty_info.dole_safety_NO is
'ʧҵ���պ�';

comment on column tb_duty_info.medicare_safety_NO is
'ҽ�Ʊ��պ�';

comment on column tb_duty_info.compo_safety_NO is
'���˱��պ�';

comment on column tb_duty_info.accumulation_fund_NO is
'�������ʺ�';

/*==============================================================*/
/* Table: tb_manager                                          */
/*==============================================================*/
create table tb_manager  (
   id                 int                             not null,
   password           varchar2(20)                    not null,
   state              char(4)                         not null,
   purview            char(10)                        not null,
   constraint PK_TB_MANAGER primary key (id)
);

comment on column tb_manager.id is
'����';

comment on column tb_manager.password is
'����';

comment on column tb_manager.state is
'״̬';

comment on column tb_manager.purview is
'Ȩ��';

/*==============================================================*/
/* Table: tb_nation                                           */
/*==============================================================*/
create table tb_nation  (
   id                 int                             not null,
   name               varchar2(20)                    not null,
   constraint PK_TB_NATION primary key (id)
);

comment on column tb_nation.id is
'����';

comment on column tb_nation.name is
'����';

/*==============================================================*/
/* Table: tb_native_place                                     */
/*==============================================================*/
create table tb_native_place  (
   id                 int                             not null,
   name               varchar2(20)                    not null,
   constraint PK_TB_NATIVE_PLACE primary key (id)
);

comment on column tb_native_place.id is
'����';

comment on column tb_native_place.name is
'����';

/*==============================================================*/
/* Table: tb_personal_info                                    */
/*==============================================================*/
create table tb_personal_info  (
   id                 INT                             not null,
   QQ                   varchar2(20),
   E_mail             varchar2(30),
   handset            varchar2(15),
   telephone          varchar2(15),
   address            varchar2(100),
   postalcode         char(6),
   second_school_age  varchar2(10),
   second_specialty   varchar2(40),
   graduate_school    varchar2(40),
   graduate_date      date,
   party_member_date  date,
   computer_grade     varchar2(10),
   likes              varchar2(50),
   ones_strong_suit   varchar2(50),
   constraint PK_TB_PERSONAL_INFO primary key (id)
);

comment on column tb_personal_info.id is
'����';

comment on column tb_personal_info.QQ is
'QQ';

comment on column tb_personal_info.E_mail is
'E_mail';

comment on column tb_personal_info.handset is
'�ƶ��绰';

comment on column tb_personal_info.telephone is
'�̶��绰';

comment on column tb_personal_info.address is
'��ͥסַ';

comment on column tb_personal_info.postalcode is
'��������';

comment on column tb_personal_info.second_school_age is
'�ڶ�ѧ��';

comment on column tb_personal_info.second_specialty is
'�ڶ�רҵ';

comment on column tb_personal_info.graduate_school is
'��ҵԺУ';

comment on column tb_personal_info.graduate_date is
'��ҵʱ��';

comment on column tb_personal_info.party_member_date is
'�뵳����';

comment on column tb_personal_info.computer_grade is
'����ˮƽ';

comment on column tb_personal_info.likes is
'����';

comment on column tb_personal_info.ones_strong_suit is
'�س�';

/*==============================================================*/
/* Table: tb_reckoning                                        */
/*==============================================================*/
create table tb_reckoning  (
   id                 int                             not null,
   name               varchar2(20)                    not null,
   explain            varchar2(100)                   not null,
   constraint PK_TB_RECKONING primary key (id)
);

comment on column tb_reckoning.id is
'����';

comment on column tb_reckoning.name is
'����';

comment on column tb_reckoning.explain is
'˵��';

/*==============================================================*/
/* Table: tb_reckoning_info                                   */
/*==============================================================*/
create table tb_reckoning_info  (
   id                 int                             not null,
   reckoning_id       int                             not null,
   account_item_id    int                             not null,
   money              int                             not null,
   constraint PK_TB_RECKONING_INFO primary key (id)
);

comment on column tb_reckoning_info.id is
'����';

comment on column tb_reckoning_info.reckoning_id is
'���';

comment on column tb_reckoning_info.account_item_id is
'���';

comment on column tb_reckoning_info.money is
'���';

/*==============================================================*/
/* Table: tb_reckoning_list                                   */
/*==============================================================*/
create table tb_reckoning_list  (
   record_id          int                             not null,
   reckoning_id       int                             not null,
   constraint PK_TB_RECKONING_LIST primary key (record_id)
);

comment on column tb_reckoning_list.record_id is
'���';

comment on column tb_reckoning_list.reckoning_id is
'���';

/*==============================================================*/
/* Table: tb_record                                           */
/*==============================================================*/
create table tb_record  (
   id                 int                             not null,
   record_number      char(6)                         not null,
   name               varchar2(10)                    not null,
   sex                char(2)                         not null,
   birthday           date                            not null,
   photo              char(10),
   ID_card            varchar2(20)                    not null,
   marriaged          char(4)                         not null,
   nation_id          int                             not null,
   native_place_id    int                             not null,
   address            varchar2(100)                   not null,
   postalcode         char(6)                         not null,
   party_member       char(2)                         not null,
   school_age         varchar2(10)                    not null,
   specialty          varchar2(40)                    not null,
   foreign_language   varchar2(10)                    not null,
   grade              varchar2(10)                    not null,
   constraint PK_TB_RECORD primary key (id)
);

comment on column tb_record.id is
'���';

comment on column tb_record.record_number is
'�������';

comment on column tb_record.name is
'����';

comment on column tb_record.sex is
'�Ա�';

comment on column tb_record.birthday is
'��������';

comment on column tb_record.photo is
'��Ƭ·��';

comment on column tb_record.ID_card is
'����֤��';

comment on column tb_record.marriaged is
'����״��';

comment on column tb_record.nation_id is
'����';

comment on column tb_record.native_place_id is
'����';

comment on column tb_record.address is
'������ַ';

comment on column tb_record.postalcode is
'��������';

comment on column tb_record.party_member is
'������ò';

comment on column tb_record.school_age is
'ѧ��';

comment on column tb_record.specialty is
'רҵ';

comment on column tb_record.foreign_language is
'��������';

comment on column tb_record.grade is
'����ˮƽ';

/*==============================================================*/
/* Table: tb_rewards_and_punishment                           */
/*==============================================================*/
create table tb_rewards_and_punishment  (
   id                 int                             not null,
   record_id          int                             not null,
   type               char(4)                         not null,
   reason             varchar2(60)                    not null,
   content            varchar2(100)                   not null,
   money              int                             not null,
   start_date         date                            not null,
   end_date           date                            not null,
   ratifier_dept_id   int                             not null,
   ratifier_record_id int                             not null,
   ratifier_date      date                            not null,
   constraint PK_TB_REWARDS_AND_PUNISHMENT primary key (id)
);

comment on column tb_rewards_and_punishment.id is
'����';

comment on column tb_rewards_and_punishment.record_id is
'���';

comment on column tb_rewards_and_punishment.type is
'�����';

comment on column tb_rewards_and_punishment.reason is
'ԭ��';

comment on column tb_rewards_and_punishment.content is
'����';

comment on column tb_rewards_and_punishment.money is
'���';

comment on column tb_rewards_and_punishment.start_date is
'��ʼ����';

comment on column tb_rewards_and_punishment.end_date is
'��������';

comment on column tb_rewards_and_punishment.ratifier_dept_id is
'��׼����';

comment on column tb_rewards_and_punishment.ratifier_record_id is
'��׼��';

comment on column tb_rewards_and_punishment.ratifier_date is
'��׼����';

/*==============================================================*/
/* Table: tb_timecard                                         */
/*==============================================================*/
create table tb_timecard  (
   id                 int                             not null,
   record_id          int                             not null,
   account_item_id    int                             not null,
   explain            varchar2(100)                   not null,
   start_date         date                            not null,
   end_date           date                            not null,
   ratifier_dept_id   int                             not null,
   ratifier_record_id int                             not null,
   ratifier_date      date                            not null,
   constraint PK_TB_TIMECARD primary key (id)
);

comment on column tb_timecard.id is
'����';

comment on column tb_timecard.record_id is
'���';

comment on column tb_timecard.account_item_id is
'���';

comment on column tb_timecard.explain is
'˵��';

comment on column tb_timecard.start_date is
'��ʼ����';

comment on column tb_timecard.end_date is
'��������';

comment on column tb_timecard.ratifier_dept_id is
'��׼����';

comment on column tb_timecard.ratifier_record_id is
'��׼��';

comment on column tb_timecard.ratifier_date is
'��׼����';

alter table tb_bring_up_ontent
   add constraint FK_TB_BRING_REFERENCE_TB_BRING foreign key (bring_up_content_id)
      references tb_bring_up_content (id);

alter table tb_bring_up_ontent
   add constraint FK_TB_BRING_REFERENCE_TB_RECOR foreign key (record_id)
      references tb_record (id);

alter table tb_dept
   add constraint FK_TB_DEPT_REFERENCE_TB_DEPT foreign key (parent_id)
      references tb_dept (id);

alter table tb_duty_info
   add constraint FK_TB_DUTY__REFERENCE_TB_RECOR foreign key (id)
      references tb_record (id);

alter table tb_duty_info
   add constraint FK_TB_DUTY__REFERENCE_TB_DEPT foreign key (dept_id)
      references tb_dept (id);

alter table tb_duty_info
   add constraint FK_TB_DUTY__REFERENCE_TB_DUTY foreign key (duty_id)
      references tb_duty (id);

alter table tb_duty_info
   add constraint FK_TB_DUTY__REFERENCE_TB_ACCES foreign key (accession_form_id)
      references tb_accession_form (id);

alter table tb_manager
   add constraint FK_TB_MANAG_REFERENCE_TB_RECOR foreign key (id)
      references tb_record (id);

alter table tb_personal_info
   add constraint FK_TB_PERSO_REFERENCE_TB_RECOR foreign key (id)
      references tb_record (id);

alter table tb_reckoning_info
   add constraint FK_TB_RECKO_REFERENCE_TB_RECKO foreign key (reckoning_id)
      references tb_reckoning (id);

alter table tb_reckoning_info
   add constraint FK_TB_RECKO_REFERENCE_TB_ACCOU foreign key (account_item_id)
      references tb_account_item (id);

alter table tb_reckoning_list
   add constraint FK_TB_RECKO_REFERENCE_TB_RECKO foreign key (reckoning_id)
      references tb_reckoning (id);

alter table tb_reckoning_list
   add constraint FK_TB_RECKO_REFERENCE_TB_RECOR foreign key (record_id)
      references tb_record (id);

alter table tb_record
   add constraint FK_TB_RECOR_REFERENCE_TB_NATIO foreign key (nation_id)
      references tb_nation (id);

alter table tb_record
   add constraint FK_TB_RECOR_REFERENCE_TB_NATIV foreign key (native_place_id)
      references tb_native_place (id);

alter table tb_rewards_and_punishment
   add constraint FK_TB_REWAR_REFERENCE_TB_RECOR foreign key (record_id)
      references tb_record (id);

alter table tb_rewards_and_punishment
   add constraint FK_TB_REWAR_REFERENCE_TB_DEPT foreign key (ratifier_dept_id)
      references tb_dept (id);

alter table tb_rewards_and_punishment
   add constraint FK_TB_REWAR_REFERENCE_TB_RECOR foreign key (ratifier_record_id)
      references tb_record (id);

alter table tb_timecard
   add constraint FK_TB_TIMEC_REFERENCE_TB_RECOR foreign key (record_id)
      references tb_record (id);

alter table tb_timecard
   add constraint FK_TB_TIMEC_REFERENCE_TB_ACCOU foreign key (account_item_id)
      references tb_account_item (id);

alter table tb_timecard
   add constraint FK_TB_TIMEC_REFERENCE_TB_DEPT foreign key (ratifier_dept_id)
      references tb_dept (id);

alter table tb_timecard
   add constraint FK_TB_TIMEC_REFERENCE_TB_RECOR foreign key (ratifier_record_id)
      references tb_record (id);

