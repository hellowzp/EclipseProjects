/*     */ package org.eclipsercp.book.tools;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ 
/*     */ class ImportSamplesOperation$6
/*     */   implements Comparator
/*     */ {
/*     */   final ImportSamplesOperation.5 this$1;
/*     */ 
/*     */   ImportSamplesOperation$6(ImportSamplesOperation.5 param5)
/*     */   {
/*   1 */     this.this$1 = param5;
/*     */   }
/*     */ 
/*     */   public int compare(Object arg0, Object arg1)
/*     */   {
/* 414 */     return ((String)arg0).toLowerCase().compareTo(((String)arg1).toLowerCase());
/*     */   }
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.tools.ImportSamplesOperation.6
 * JD-Core Version:    0.6.2
 */