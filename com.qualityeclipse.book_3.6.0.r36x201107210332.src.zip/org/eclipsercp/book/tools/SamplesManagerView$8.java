/*     */ package org.eclipsercp.book.tools;
/*     */ 
/*     */ import org.eclipse.jface.viewers.TableViewer;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ 
/*     */ class SamplesManagerView$8
/*     */   implements Runnable
/*     */ {
/*     */   final SamplesManagerView.7 this$1;
/*     */ 
/*     */   SamplesManagerView$8(SamplesManagerView.7 param7)
/*     */   {
/*   1 */     this.this$1 = param7;
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/* 482 */     if ((SamplesManagerView.access$4(SamplesManagerView.7.access$0(this.this$1)) != null) && (!SamplesManagerView.access$4(SamplesManagerView.7.access$0(this.this$1)).getControl().isDisposed()))
/* 483 */       SamplesManagerView.access$4(SamplesManagerView.7.access$0(this.this$1)).setInput(SamplesManagerView.access$5(SamplesManagerView.7.access$0(this.this$1)));
/*     */   }
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.tools.SamplesManagerView.8
 * JD-Core Version:    0.6.2
 */