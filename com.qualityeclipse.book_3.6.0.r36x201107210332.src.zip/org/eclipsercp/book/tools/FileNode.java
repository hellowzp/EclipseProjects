/*     */ package org.eclipsercp.book.tools;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import org.eclipse.compare.BufferedContent;
/*     */ import org.eclipse.compare.CompareUI;
/*     */ import org.eclipse.compare.IEditableContent;
/*     */ import org.eclipse.compare.IEncodedStreamContentAccessor;
/*     */ import org.eclipse.compare.IModificationDate;
/*     */ import org.eclipse.compare.ITypedElement;
/*     */ import org.eclipse.compare.structuremergeviewer.IStructureComparator;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ 
/*     */ public class FileNode extends BufferedContent
/*     */   implements IEncodedStreamContentAccessor, IStructureComparator, ITypedElement, IEditableContent, IModificationDate
/*     */ {
/*     */   private File fFile;
/*     */   private ArrayList fChildren;
/*     */ 
/*     */   public FileNode(File file)
/*     */   {
/*  29 */     this.fFile = file;
/*  30 */     if (file == null)
/*  31 */       throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   public File getFile()
/*     */   {
/*  36 */     return this.fFile;
/*     */   }
/*     */ 
/*     */   public InputStream getContents()
/*     */     throws CoreException
/*     */   {
/*  42 */     if (this.fFile.isFile()) {
/*     */       try
/*     */       {
/*  45 */         return new FileInputStream(this.fFile);
/*     */       }
/*     */       catch (FileNotFoundException _ex)
/*     */       {
/*  49 */         return null;
/*     */       }
/*     */     }
/*  52 */     return null;
/*     */   }
/*     */ 
/*     */   public long getModificationDate()
/*     */   {
/*  57 */     return this.fFile.lastModified();
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  62 */     if (this.fFile != null) {
/*  63 */       return this.fFile.getName();
/*     */     }
/*  65 */     return null;
/*     */   }
/*     */ 
/*     */   public String getType()
/*     */   {
/*  70 */     if (this.fFile.isDirectory())
/*  71 */       return "FOLDER";
/*  72 */     String s = new Path(this.fFile.getName()).getFileExtension();
/*  73 */     if (s != null) {
/*  74 */       return s;
/*     */     }
/*  76 */     return "???";
/*     */   }
/*     */ 
/*     */   public Image getImage()
/*     */   {
/*  81 */     if (this.fFile.isDirectory())
/*  82 */       return CompareUI.getImage("FOLDER");
/*  83 */     IPath path = new Path(this.fFile.getName());
/*  84 */     if (path.getFileExtension() == null) {
/*  85 */       return null;
/*     */     }
/*  87 */     return CompareUI.getImage(path.getFileExtension());
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/*  92 */     if ((other instanceof ITypedElement))
/*     */     {
/*  94 */       String otherName = ((ITypedElement)other).getName();
/*  95 */       return getName().equals(otherName);
/*     */     }
/*     */ 
/*  98 */     return super.equals(other);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 104 */     return getName().hashCode();
/*     */   }
/*     */ 
/*     */   public Object[] getChildren()
/*     */   {
/* 109 */     if (this.fChildren == null)
/*     */     {
/* 111 */       this.fChildren = new ArrayList();
/* 112 */       if (this.fFile.isDirectory())
/*     */       {
/* 114 */         File[] members = this.fFile.listFiles();
/* 115 */         for (int i = 0; i < members.length; i++)
/*     */         {
/* 117 */           IStructureComparator child = createChild(members[i]);
/* 118 */           if (child != null) {
/* 119 */             this.fChildren.add(child);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 124 */     return this.fChildren.toArray();
/*     */   }
/*     */ 
/*     */   protected IStructureComparator createChild(File child)
/*     */   {
/* 129 */     if (Utils.ignoreDirectory(child)) {
/* 130 */       return null;
/*     */     }
/* 132 */     return new FileNode(child);
/*     */   }
/*     */ 
/*     */   public boolean isEditable()
/*     */   {
/* 137 */     return false;
/*     */   }
/*     */ 
/*     */   public ITypedElement replace(ITypedElement child, ITypedElement other)
/*     */   {
/* 142 */     return child;
/*     */   }
/*     */ 
/*     */   public String getCharset()
/*     */   {
/* 147 */     return null;
/*     */   }
/*     */ 
/*     */   protected InputStream createStream()
/*     */     throws CoreException
/*     */   {
/* 153 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.tools.FileNode
 * JD-Core Version:    0.6.2
 */