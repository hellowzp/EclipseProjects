/*     */ package org.eclipsercp.book.tools;
/*     */ 
/*     */ import org.eclipse.jface.action.Action;
/*     */ 
/*     */ class ResourceToFileCompareInput$2 extends Action
/*     */ {
/*     */   final ResourceToFileCompareInput.1 this$1;
/*     */ 
/*     */   ResourceToFileCompareInput$2(ResourceToFileCompareInput.1 param1)
/*     */   {
/*   1 */     this.this$1 = param1;
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/* 130 */     ResourceToFileCompareInput.1.access$0(this.this$1, null);
/*     */   }
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.tools.ResourceToFileCompareInput.2
 * JD-Core Version:    0.6.2
 */