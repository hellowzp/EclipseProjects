/*     */ package org.eclipsercp.book.tools;
/*     */ 
/*     */ import com.instantiations.book.BookLog;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.zip.ZipFile;
/*     */ import org.eclipse.compare.CompareConfiguration;
/*     */ import org.eclipse.compare.CompareEditorInput;
/*     */ import org.eclipse.compare.IContentChangeListener;
/*     */ import org.eclipse.compare.IContentChangeNotifier;
/*     */ import org.eclipse.compare.ITypedElement;
/*     */ import org.eclipse.compare.internal.BufferedResourceNode;
/*     */ import org.eclipse.compare.internal.Utilities;
/*     */ import org.eclipse.compare.structuremergeviewer.DiffNode;
/*     */ import org.eclipse.compare.structuremergeviewer.DiffTreeViewer;
/*     */ import org.eclipse.compare.structuremergeviewer.IDiffContainer;
/*     */ import org.eclipse.compare.structuremergeviewer.IDiffElement;
/*     */ import org.eclipse.compare.structuremergeviewer.IStructureComparator;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.jface.action.Action;
/*     */ import org.eclipse.jface.action.IAction;
/*     */ import org.eclipse.jface.action.IMenuManager;
/*     */ import org.eclipse.jface.action.Separator;
/*     */ import org.eclipse.jface.viewers.ISelection;
/*     */ import org.eclipse.jface.viewers.IStructuredSelection;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ 
/*     */ class ResourceToFileCompareInput extends CompareEditorInput
/*     */ {
/*     */   private boolean fThreeWay;
/*     */   private Object fRoot;
/*     */   private DiffTreeViewer fDiffViewer;
/*     */   private IAction fOpenAction;
/*     */   private final String chapTag1;
/*     */   private final String chapTag2;
/*     */   private IResource fLeftResource;
/*     */   private IStructureComparator fLeft;
/*     */   private File fRightZipFile;
/*     */   private File fRightResource;
/*     */   private IStructureComparator fRight;
/*     */   private IStructureComparator fAncestor;
/*     */ 
/*     */   ResourceToFileCompareInput(String chapTag1, String chapTag2, CompareConfiguration config)
/*     */   {
/* 115 */     super(config);
/* 116 */     this.fThreeWay = false;
/* 117 */     this.chapTag1 = chapTag1;
/* 118 */     this.chapTag2 = chapTag2;
/* 119 */     initializeCompareConfiguration();
/*     */   }
/*     */ 
/*     */   public Viewer createDiffViewer(Composite parent) {
/* 123 */     this.fDiffViewer = new DiffTreeViewer(parent, getCompareConfiguration()) {
/*     */       private Action fCopyAllRightToLeft;
/*     */ 
/* 126 */       protected void fillContextMenu(IMenuManager manager) { if (ResourceToFileCompareInput.this.fOpenAction == null) {
/* 127 */           ResourceToFileCompareInput.this.fOpenAction = new ResourceToFileCompareInput.2(this);
/*     */ 
/* 134 */           ResourceToFileCompareInput.this.fOpenAction.setText("&Show Comparison");
/*     */         }
/* 136 */         boolean enable = false;
/* 137 */         ISelection selection = getSelection();
/* 138 */         if ((selection instanceof IStructuredSelection)) {
/* 139 */           IStructuredSelection ss = (IStructuredSelection)selection;
/* 140 */           if (ss.size() == 1) {
/* 141 */             Object element = ss.getFirstElement();
/* 142 */             if ((element instanceof ResourceToFileCompareInput.MyDiffNode)) {
/* 143 */               ITypedElement te = ((ResourceToFileCompareInput.MyDiffNode)element).getId();
/* 144 */               if (te != null)
/* 145 */                 enable = !"FOLDER".equals(te.getType());
/*     */             }
/*     */             else {
/* 148 */               enable = true;
/*     */             }
/*     */           }
/*     */         }
/* 152 */         ResourceToFileCompareInput.this.fOpenAction.setEnabled(enable);
/* 153 */         if (this.fCopyAllRightToLeft == null) {
/* 154 */           this.fCopyAllRightToLeft = new ResourceToFileCompareInput.3(this, "Copy into &Workspace");
/*     */         }
/*     */ 
/* 161 */         this.fCopyAllRightToLeft.setEnabled(true);
/* 162 */         manager.add(ResourceToFileCompareInput.this.fOpenAction);
/* 163 */         super.fillContextMenu(manager);
/* 164 */         manager.add(new Separator());
/* 165 */         manager.add(this.fCopyAllRightToLeft);
/*     */       }
/*     */     };
/* 171 */     return this.fDiffViewer;
/*     */   }
/*     */ 
/*     */   public String getTitle() {
/* 175 */     return getShortChapterName(this.chapTag1) + " / " + getShortChapterName(this.chapTag2);
/*     */   }
/*     */ 
/*     */   private static String getShortChapterName(String chapTag) {
/* 179 */     int index = chapTag.indexOf('/');
/* 180 */     return chapTag.substring(index + 1);
/*     */   }
/*     */ 
/*     */   private void copyAllRightToLeft(ISelection selection) {
/* 184 */     if ((selection instanceof IStructuredSelection))
/*     */     {
/*     */       Object element;
/* 186 */       for (Iterator elements = ((IStructuredSelection)selection).iterator(); elements.hasNext(); copy(element))
/* 187 */         element = elements.next();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void copy(Object element)
/*     */   {
/* 193 */     if ((element instanceof DiffNode)) {
/* 194 */       ((DiffNode)element).copy(false);
/*     */       try {
/* 196 */         commit(new NullProgressMonitor(), (DiffNode)element);
/*     */       }
/*     */       catch (CoreException localCoreException) {
/*     */       }
/*     */     }
/* 201 */     if ((element instanceof IDiffContainer)) {
/* 202 */       IDiffElement[] children = ((IDiffContainer)element).getChildren();
/* 203 */       for (int i = 0; i < children.length; i++) {
/* 204 */         IDiffElement node = children[i];
/* 205 */         copy(node);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   void setSelection(IResource root, File zipFile)
/*     */   {
/* 218 */     this.fThreeWay = false;
/*     */ 
/* 220 */     this.fLeftResource = root;
/* 221 */     this.fLeft = new EclipseResourceNode(this.fLeftResource) {
/*     */       final ZipFile zip;
/*     */ 
/*     */       protected boolean shouldCreateChild(IResource child) {
/* 225 */         if ((child instanceof IProject)) {
/*     */           try {
/* 227 */             return (this.zip == null) || (SampleZipFile.isSampleProject((IProject)child, this.zip));
/*     */           } catch (CoreException e) {
/* 229 */             BookLog.logError("Failed to determine if project is sample project: " + child, e);
/* 230 */             return true;
/*     */           }
/*     */         }
/* 233 */         return super.shouldCreateChild(child);
/*     */       }
/*     */     };
/* 237 */     this.fRightZipFile = zipFile;
/* 238 */     this.fRightResource = zipFile;
/* 239 */     this.fRight = new ZipFileNode(this.fRightResource);
/*     */ 
/* 241 */     this.fAncestor = new ZipFileNode(this.fRightZipFile);
/*     */   }
/*     */ 
/*     */   private ZipFile newZipFile(File file) {
/*     */     try {
/* 246 */       return new ZipFile(file);
/*     */     } catch (IOException e) {
/* 248 */       BookLog.logError("Failed to instantiate ZipFile for File: " + file, e);
/* 249 */     }return null;
/*     */   }
/*     */ 
/*     */   public boolean isEnabled(ISelection s)
/*     */   {
/* 254 */     return true;
/*     */   }
/*     */ 
/*     */   void initializeCompareConfiguration() {
/* 258 */     CompareConfiguration cc = getCompareConfiguration();
/* 259 */     cc.setProperty("IGNORE_WHITESPACE", Boolean.TRUE);
/* 260 */     cc.setProperty("org.eclipse.compare.internal.CONFIRM_SAVE_PROPERTY", Boolean.FALSE);
/* 261 */     cc.setLeftEditable(true);
/* 262 */     cc.setLeftLabel(getShortChapterName(this.chapTag1) + " (in workspace)");
/* 263 */     cc.setRightEditable(false);
/* 264 */     cc.setRightLabel(getShortChapterName(this.chapTag2) + " (in file system)");
/*     */   }
/*     */ 
/*     */   public Object prepareInput(IProgressMonitor monitor) throws InvocationTargetException
/*     */   {
/*     */     Object obj;
/*     */     try {
/* 271 */       this.fLeftResource.refreshLocal(2, monitor);
/* 272 */       if ((this.fThreeWay) && (this.fRightZipFile != null))
/* 273 */         monitor.beginTask(Utilities.getString("ResourceCompare.taskName"), -1);
/* 274 */       String leftLabel = this.fLeftResource.getName();
/* 275 */       String rightLabel = this.fRightResource.getName();
/* 276 */       if (rightLabel.endsWith(".zip"))
/* 277 */         rightLabel = rightLabel.substring(0, rightLabel.length() - 4);
/*     */       String title;
/*     */       String title;
/* 279 */       if (this.fThreeWay) {
/* 280 */         String format = Utilities.getString("ResourceCompare.threeWay.title");
/* 281 */         String ancestorLabel = this.fRightZipFile.getName();
/* 282 */         title = MessageFormat.format(format, new String[] { 
/* 283 */           ancestorLabel, leftLabel, rightLabel });
/*     */       }
/*     */       else
/*     */       {
/* 287 */         String format = Utilities.getString("ResourceCompare.twoWay.title");
/* 288 */         title = MessageFormat.format(format, new String[] { 
/* 289 */           leftLabel, rightLabel });
/*     */       }
/*     */ 
/* 292 */       setTitle(title);
/* 293 */       Differencer d = new Differencer()
/*     */       {
/*     */         protected Object visit(Object parent, int description, Object ancestor, Object left, Object right) {
/* 296 */           ResourceToFileCompareInput.MyDiffNode node = new ResourceToFileCompareInput.MyDiffNode(ResourceToFileCompareInput.this, (IDiffContainer)parent, description, (ITypedElement)ancestor, 
/* 297 */             (ITypedElement)left, (ITypedElement)right);
/* 298 */           Object leftNode = node.getLeft();
/* 299 */           if ((leftNode != null) && ((leftNode instanceof IContentChangeNotifier)))
/* 300 */             ((IContentChangeNotifier)leftNode).addContentChangeListener(node);
/* 301 */           return node;
/*     */         }
/*     */       };
/* 305 */       this.fRoot = d.findDifferences(this.fThreeWay, monitor, null, this.fAncestor, this.fLeft, this.fRight);
/* 306 */       obj = this.fRoot;
/*     */     }
/*     */     catch (CoreException e)
/*     */     {
/*     */       Object obj;
/* 309 */       throw new InvocationTargetException(e);
/*     */     }
/*     */     finally {
/* 312 */       monitor.done();
/*     */     }
/* 314 */     return obj;
/*     */   }
/*     */ 
/*     */   public void saveChanges(IProgressMonitor pm) throws CoreException {
/* 318 */     super.saveChanges(pm);
/* 319 */     if (!(this.fRoot instanceof DiffNode))
/* 320 */       return;
/*     */     try {
/* 322 */       commit(pm, (DiffNode)this.fRoot);
/*     */     }
/*     */     finally {
/* 325 */       if (this.fDiffViewer != null)
/* 326 */         this.fDiffViewer.refresh();
/* 327 */       setDirty(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void commit(IProgressMonitor pm, DiffNode node) throws CoreException {
/* 332 */     if ((node instanceof MyDiffNode))
/* 333 */       ((MyDiffNode)node).clearDirty();
/* 334 */     ITypedElement left = node.getLeft();
/* 335 */     if ((left instanceof EclipseResourceNode))
/* 336 */       ((EclipseResourceNode)left).commit(pm);
/* 337 */     ITypedElement right = node.getRight();
/* 338 */     if ((right instanceof EclipseResourceNode))
/* 339 */       ((EclipseResourceNode)right).commit(pm);
/* 340 */     IDiffElement[] children = node.getChildren();
/* 341 */     if (children != null)
/* 342 */       for (int i = 0; i < children.length; i++) {
/* 343 */         IDiffElement element = children[i];
/* 344 */         if ((element instanceof DiffNode))
/* 345 */           commit(pm, (DiffNode)element);
/*     */       }
/*     */   }
/*     */ 
/*     */   public Object getAdapter(Class adapter)
/*     */   {
/* 352 */     return null;
/*     */   }
/*     */ 
/*     */   private void collectDirtyResources(Object o, Set collector) {
/* 356 */     if ((o instanceof DiffNode)) {
/* 357 */       DiffNode node = (DiffNode)o;
/* 358 */       ITypedElement left = node.getLeft();
/* 359 */       if ((left instanceof BufferedResourceNode)) {
/* 360 */         BufferedResourceNode bn = (BufferedResourceNode)left;
/* 361 */         if (bn.isDirty()) {
/* 362 */           IResource resource = bn.getResource();
/* 363 */           if ((resource instanceof IFile))
/* 364 */             collector.add(resource);
/*     */         }
/*     */       }
/* 367 */       ITypedElement right = node.getRight();
/* 368 */       if ((right instanceof BufferedResourceNode)) {
/* 369 */         BufferedResourceNode bn = (BufferedResourceNode)right;
/* 370 */         if (bn.isDirty()) {
/* 371 */           IResource resource = bn.getResource();
/* 372 */           if ((resource instanceof IFile))
/* 373 */             collector.add(resource);
/*     */         }
/*     */       }
/* 376 */       IDiffElement[] children = node.getChildren();
/* 377 */       if (children != null)
/* 378 */         for (int i = 0; i < children.length; i++) {
/* 379 */           IDiffElement element = children[i];
/* 380 */           if ((element instanceof DiffNode))
/* 381 */             collectDirtyResources(element, collector);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   class MyDiffNode extends DiffNode
/*     */     implements IContentChangeListener
/*     */   {
/*     */     private boolean fDirty;
/*     */     private ITypedElement fLastId;
/*     */     private String fLastName;
/*     */ 
/*     */     public void fireChange()
/*     */     {
/*  62 */       super.fireChange();
/*  63 */       ResourceToFileCompareInput.this.setDirty(true);
/*  64 */       this.fDirty = true;
/*  65 */       if (ResourceToFileCompareInput.this.fDiffViewer != null)
/*  66 */         ResourceToFileCompareInput.this.fDiffViewer.refresh(this);
/*  67 */       ResourceToFileCompareInput.this.setDirty(true);
/*     */       try {
/*  69 */         ResourceToFileCompareInput.commit(new NullProgressMonitor(), this);
/*     */       }
/*     */       catch (CoreException localCoreException) {
/*     */       }
/*     */     }
/*     */ 
/*     */     void clearDirty() {
/*  76 */       this.fDirty = false;
/*     */     }
/*     */ 
/*     */     public String getName() {
/*  80 */       if (this.fLastName == null)
/*  81 */         this.fLastName = super.getName();
/*  82 */       if (this.fDirty) {
/*  83 */         return '<' + this.fLastName + '>';
/*     */       }
/*  85 */       return this.fLastName;
/*     */     }
/*     */ 
/*     */     public ITypedElement getId() {
/*  89 */       ITypedElement id = super.getId();
/*  90 */       if (id == null) {
/*  91 */         return this.fLastId;
/*     */       }
/*     */ 
/*  94 */       this.fLastId = id;
/*  95 */       return id;
/*     */     }
/*     */ 
/*     */     public void contentChanged(IContentChangeNotifier source)
/*     */     {
/* 100 */       fireChange();
/*     */     }
/*     */ 
/*     */     public MyDiffNode(IDiffContainer parent, int description, ITypedElement ancestor, ITypedElement left, ITypedElement right)
/*     */     {
/* 109 */       super(description, ancestor, left, right);
/* 110 */       this.fDirty = false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.tools.ResourceToFileCompareInput
 * JD-Core Version:    0.6.2
 */