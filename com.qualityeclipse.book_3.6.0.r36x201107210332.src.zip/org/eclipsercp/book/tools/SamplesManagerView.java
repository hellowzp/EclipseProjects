/*     */ package org.eclipsercp.book.tools;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import org.eclipse.compare.CompareConfiguration;
/*     */ import org.eclipse.compare.CompareUI;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.FileLocator;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.PluginVersionIdentifier;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.jface.action.Action;
/*     */ import org.eclipse.jface.action.IMenuManager;
/*     */ import org.eclipse.jface.action.IToolBarManager;
/*     */ import org.eclipse.jface.action.MenuManager;
/*     */ import org.eclipse.jface.action.Separator;
/*     */ import org.eclipse.jface.dialogs.Dialog;
/*     */ import org.eclipse.jface.dialogs.MessageDialog;
/*     */ import org.eclipse.jface.viewers.ArrayContentProvider;
/*     */ import org.eclipse.jface.viewers.DoubleClickEvent;
/*     */ import org.eclipse.jface.viewers.IDoubleClickListener;
/*     */ import org.eclipse.jface.viewers.IStructuredSelection;
/*     */ import org.eclipse.jface.viewers.TableViewer;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.jface.viewers.ViewerSorter;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Combo;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Link;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.ui.IActionBars;
/*     */ import org.eclipse.ui.IViewSite;
/*     */ import org.eclipse.ui.IWorkbench;
/*     */ import org.eclipse.ui.IWorkbenchPartSite;
/*     */ import org.eclipse.ui.PlatformUI;
/*     */ import org.eclipse.ui.browser.IWebBrowser;
/*     */ import org.eclipse.ui.browser.IWorkbenchBrowserSupport;
/*     */ import org.eclipse.ui.help.IWorkbenchHelpSystem;
/*     */ import org.eclipse.ui.part.ViewPart;
/*     */ import org.eclipse.ui.plugin.AbstractUIPlugin;
/*     */ import org.eclipse.update.configurator.ConfiguratorUtils;
/*     */ import org.eclipse.update.configurator.IPlatformConfiguration;
/*     */ import org.eclipse.update.configurator.IPlatformConfiguration.IFeatureEntry;
/*     */ import org.eclipse.update.standalone.InstallCommand;
/*     */ import org.eclipsercp.book.zip.ZipChaptersAction;
/*     */ import org.osgi.framework.Bundle;
/*     */ 
/*     */ public class SamplesManagerView extends ViewPart
/*     */ {
/*     */   private static final int IMPORT_ID = 101;
/*     */   private static final int COMPARE_ID = 102;
/*     */   private Combo categoryField;
/*  87 */   public static String ID = "com.qualityeclipse.book.tools.SamplesManagerView";
/*     */   private String defaultSampleDirectory;
/*     */   private TableViewer projectsList;
/*     */   private SampleZipFile[] discoveredSamplesDirectories;
/*     */   private String currentChapterTag;
/*     */   private Action importAction;
/*     */   private Action compareAction;
/*     */   private Action zipAction;
/*     */ 
/*     */   public SamplesManagerView()
/*     */   {
/*  97 */     this.defaultSampleDirectory = "";
/*  98 */     this.discoveredSamplesDirectories = new SampleZipFile[0];
/*  99 */     this.defaultSampleDirectory = findSamplesDirectory();
/*     */   }
/*     */ 
/*     */   public void createPartControl(Composite parent) {
/* 103 */     this.currentChapterTag = SampleZipFile.getCurrentChapterTag();
/* 104 */     Composite workArea = new Composite(parent, 0);
/* 105 */     GridLayout layout = new GridLayout();
/* 106 */     layout.numColumns = 2;
/* 107 */     workArea.setLayout(layout);
/* 108 */     workArea.setLayoutData(new GridData(1808));
/* 109 */     Link label = new Link(workArea, 64);
/* 110 */     GridData gridData = new GridData(16384, 128, true, false, 2, 1);
/* 111 */     label.setLayoutData(gridData);
/*     */ 
/* 113 */     label.setText("Import and Compare sample code for the book.\n<a>F1</a> for help, or browse <a>website</a>.");
/* 114 */     label.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 117 */         SamplesManagerView.this.handleLinkSelected(e);
/*     */       }
/*     */     });
/* 122 */     Label categoryLabel = new Label(workArea, 0);
/* 123 */     categoryLabel.setText("Category:");
/*     */ 
/* 125 */     this.categoryField = new Combo(workArea, 8);
/* 126 */     this.categoryField.setLayoutData(new GridData(4, 16777216, true, false));
/* 127 */     updateCategoryField();
/* 128 */     this.categoryField.addSelectionListener(new SelectionListener() {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 130 */         SamplesManagerView.this.updateProjectsList();
/*     */       }
/*     */       public void widgetDefaultSelected(SelectionEvent e) {
/* 133 */         widgetSelected(e);
/*     */       }
/*     */     });
/* 137 */     createProjectsList(workArea);
/* 138 */     Dialog.applyDialogFont(workArea);
/* 139 */     updateProjectsList();
/* 140 */     this.projectsList.addDoubleClickListener(new IDoubleClickListener()
/*     */     {
/*     */       public void doubleClick(DoubleClickEvent event) {
/* 143 */         SamplesManagerView.this.buttonPressed(101);
/*     */       }
/*     */     });
/* 147 */     PlatformUI.getWorkbench().getHelpSystem().setHelp(getShell(), "com.qualityeclipse.book.dialog");
/* 148 */     fillActionBars(this.projectsList.getControl());
/*     */   }
/*     */ 
/*     */   public String getSamplesDirectory() {
/* 152 */     return this.defaultSampleDirectory;
/*     */   }
/*     */ 
/*     */   public void updateCategoryField() {
/* 156 */     if ((this.categoryField == null) || (this.categoryField.isDisposed()))
/* 157 */       return;
/* 158 */     String selectedText = this.categoryField.getText();
/* 159 */     this.categoryField.removeAll();
/* 160 */     String samplesDirectory = getSamplesDirectory();
/* 161 */     if ((samplesDirectory == null) || (samplesDirectory.length() == 0))
/* 162 */       return;
/* 163 */     File directory = new File(samplesDirectory);
/* 164 */     Collection categoryNames = new TreeSet();
/* 165 */     if (directory.isDirectory()) {
/* 166 */       File[] contents = directory.listFiles();
/* 167 */       for (int i = 0; i < contents.length; i++) {
/* 168 */         File file = contents[i];
/* 169 */         if ((file.isDirectory()) && 
/* 170 */           (!Utils.ignoreDirectory(file))) {
/* 171 */           categoryNames.add(file.getName());
/*     */         }
/*     */       }
/*     */     }
/* 175 */     int selectedIndex = 0;
/* 176 */     int count = 0;
/* 177 */     for (Iterator iter = categoryNames.iterator(); iter.hasNext(); ) {
/* 178 */       String name = (String)iter.next();
/* 179 */       this.categoryField.add(name);
/* 180 */       if (name.equals(selectedText))
/* 181 */         selectedIndex = count;
/* 182 */       count++;
/*     */     }
/* 184 */     if (categoryNames.size() > 0)
/* 185 */       this.categoryField.select(selectedIndex);
/*     */   }
/*     */ 
/*     */   public String getCategoryName() {
/* 189 */     if ((this.categoryField != null) && (!this.categoryField.isDisposed()))
/* 190 */       return this.categoryField.getText();
/* 191 */     return "";
/*     */   }
/*     */ 
/*     */   public String getCategoryDirectory() {
/* 195 */     String path = getSamplesDirectory();
/* 196 */     if ((path == null) || (path.length() == 0))
/* 197 */       return "";
/* 198 */     String name = getCategoryName();
/* 199 */     if ((name == null) || (name.length() == 0))
/* 200 */       return "";
/* 201 */     return path + File.separator + name;
/*     */   }
/*     */ 
/*     */   private void handleLinkSelected(SelectionEvent e) {
/* 205 */     if (e.text.equals("F1"))
/* 206 */       PlatformUI.getWorkbench().getHelpSystem().displayHelp("com.qualityeclipse.book.dialog");
/* 207 */     else if (e.text.equals("website"))
/* 208 */       openWebBrowser();
/*     */   }
/*     */ 
/*     */   private void openWebBrowser()
/*     */   {
/*     */     try
/*     */     {
/* 215 */       PlatformUI.getWorkbench().getBrowserSupport().createBrowser("qualityeclipse").openURL(
/* 216 */         new URL("http://www.qualityeclipse.com"));
/*     */     }
/*     */     catch (Exception e1) {
/* 219 */       Utils.handleError(getShell(), e1, "Error", "Problems opening web browser");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void fillActionBars(Control control)
/*     */   {
/* 225 */     this.importAction = new Action("&Import") {
/*     */       public void run() {
/* 227 */         SamplesManagerView.this.buttonPressed(101);
/*     */       }
/*     */     };
/* 230 */     this.importAction.setImageDescriptor(AbstractUIPlugin.imageDescriptorFromPlugin("com.qualityeclipse.book", 
/* 231 */       "icons/import.gif"));
/* 232 */     this.importAction.setToolTipText("Import the selected chapter's code into the workspace.");
/*     */ 
/* 234 */     this.compareAction = new Action("&Compare") {
/*     */       public void run() {
/* 236 */         SamplesManagerView.this.buttonPressed(102);
/*     */       }
/*     */     };
/* 239 */     this.compareAction.setImageDescriptor(AbstractUIPlugin.imageDescriptorFromPlugin("com.qualityeclipse.book", 
/* 240 */       "icons/compare.gif"));
/* 241 */     this.compareAction
/* 242 */       .setToolTipText("Compare the projects in your workspace with the currently selected chapter's code.");
/*     */ 
/* 245 */     this.zipAction = new ZipChaptersAction(this, "&Zip...");
/* 246 */     this.zipAction.setImageDescriptor(AbstractUIPlugin.imageDescriptorFromPlugin("com.qualityeclipse.book", 
/* 247 */       "icons/exportzip_wiz.gif"));
/* 248 */     this.zipAction
/* 249 */       .setToolTipText("Zip the projects and place them into the samples plug-in.");
/*     */ 
/* 252 */     IActionBars bars = getViewSite().getActionBars();
/*     */ 
/* 254 */     IToolBarManager toolbar = bars.getToolBarManager();
/* 255 */     toolbar.add(this.importAction);
/* 256 */     toolbar.add(this.compareAction);
/*     */ 
/* 258 */     IMenuManager menu = bars.getMenuManager();
/* 259 */     menu.add(this.importAction);
/* 260 */     menu.add(this.compareAction);
/* 261 */     menu.add(new Separator());
/* 262 */     menu.add(this.zipAction);
/*     */ 
/* 264 */     MenuManager contextMenu = new MenuManager();
/* 265 */     contextMenu.add(this.importAction);
/* 266 */     contextMenu.add(this.compareAction);
/* 267 */     control.setMenu(contextMenu.createContextMenu(control));
/*     */   }
/*     */ 
/*     */   public Shell getShell() {
/* 271 */     IWorkbenchPartSite site = getSite();
/* 272 */     if (site == null)
/* 273 */       return null;
/* 274 */     return site.getShell();
/*     */   }
/*     */ 
/*     */   private boolean checkFeature(String feature, String version)
/*     */   {
/* 354 */     IPlatformConfiguration config = ConfiguratorUtils.getCurrentPlatformConfiguration();
/* 355 */     IPlatformConfiguration.IFeatureEntry[] features = config
/* 356 */       .getConfiguredFeatureEntries();
/* 357 */     PluginVersionIdentifier targetVersion = new PluginVersionIdentifier(version);
/* 358 */     for (int i = 0; i < features.length; i++) {
/* 359 */       String id = features[i].getFeatureIdentifier();
/* 360 */       if (feature.equals(id)) {
/* 361 */         PluginVersionIdentifier v = new PluginVersionIdentifier(features[i].getFeatureVersion());
/* 362 */         return targetVersion.isGreaterThan(v);
/*     */       }
/*     */     }
/*     */ 
/* 366 */     return true;
/*     */   }
/*     */ 
/*     */   protected void buttonPressed(int buttonId) {
/* 370 */     switch (buttonId) {
/*     */     case 101:
/* 372 */       createProjects();
/* 373 */       this.projectsList.refresh(true);
/* 374 */       break;
/*     */     case 102:
/* 377 */       compareChapters();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void downloadFeature(String feature, String version, String fromSite, IProgressMonitor monitor)
/*     */     throws Exception
/*     */   {
/* 385 */     InstallCommand command = new InstallCommand(feature, version, fromSite, null, "false");
/* 386 */     command.run(monitor);
/* 387 */     command.applyChangesNow();
/*     */   }
/*     */ 
/*     */   private void createProjects() {
/* 391 */     ImportSamplesOperation operation = new ImportSamplesOperation(getShell(), getSelectedSample());
/* 392 */     Utils.run(getShell(), operation);
/* 393 */     this.currentChapterTag = SampleZipFile.getCurrentChapterTag();
/*     */   }
/*     */ 
/*     */   private void createProjectsList(Composite listComposite) {
/* 397 */     this.projectsList = new TableViewer(listComposite, 2052);
/* 398 */     GridData listData = new GridData(4, 4, true, true, 2, 1);
/* 399 */     listData.heightHint = 125;
/* 400 */     listData.widthHint = 100;
/* 401 */     this.projectsList.getControl().setLayoutData(listData);
/* 402 */     this.projectsList.setSorter(new ViewerSorter()
/*     */     {
/*     */       public int compare(Viewer viewer, Object e1, Object e2) {
/* 405 */         SampleZipFile c1 = (SampleZipFile)e1;
/* 406 */         SampleZipFile c2 = (SampleZipFile)e2;
/* 407 */         int delta = c1.getChapterNum().compareTo(c2.getChapterNum());
/* 408 */         if (delta != 0)
/* 409 */           return delta;
/* 410 */         return c1.getChapterName().compareTo(c2.getChapterName());
/*     */       }
/*     */     });
/* 414 */     this.projectsList.setContentProvider(new ArrayContentProvider());
/* 415 */     this.projectsList.setLabelProvider(new ChaptersLabelProvider(this));
/* 416 */     this.projectsList.setInput(this.discoveredSamplesDirectories);
/* 417 */     this.projectsList.getControl().setFocus();
/*     */   }
/*     */ 
/*     */   private String findSamplesDirectory() {
/* 421 */     Bundle bundle = Platform.getBundle("com.qualityeclipse.book");
/* 422 */     if (bundle != null) {
/* 423 */       URL samples = bundle.getEntry("samples");
/* 424 */       if (samples != null) {
/*     */         try {
/* 426 */           samples = FileLocator.toFileURL(samples);
/* 427 */           if (samples.getProtocol().equals("file")) {
/* 428 */             File dir = new File(samples.getFile().replace('/', File.separatorChar));
/* 429 */             return dir.getAbsolutePath();
/*     */           }
/*     */         }
/*     */         catch (IOException e) {
/* 433 */           Utils.handleError(getShell(), e, "Error", "Problems finding samples directory");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 438 */     MessageDialog.openError(
/* 439 */       getShell(), 
/* 440 */       "Error finding samples code", 
/* 441 */       "The samples code plug-in is not installed. Please visit qualityeclipse.com for instructions on how to install the latest sample code for the \"Eclipse: Building Commercial Quality Plug-ins\" book.");
/* 442 */     return "";
/*     */   }
/*     */ 
/*     */   private void updateProjectsList() {
/* 446 */     String path = getCategoryDirectory();
/* 447 */     if ((path == null) || (path.length() == 0)) {
/* 448 */       this.discoveredSamplesDirectories = new SampleZipFile[0];
/* 449 */       this.projectsList.refresh(true);
/* 450 */       return;
/*     */     }
/*     */ 
/* 459 */     Job job = new Job(path) {
/*     */       private final String val$path;
/*     */ 
/* 462 */       protected IStatus run(IProgressMonitor monitor) { monitor.beginTask("Searching", 100);
/* 463 */         File directory = new File(this.val$path);
/* 464 */         SamplesManagerView.this.discoveredSamplesDirectories = new SampleZipFile[0];
/* 465 */         SortedMap files = new TreeMap();
/* 466 */         monitor.worked(10);
/*     */ 
/* 468 */         if (directory.isDirectory()) {
/* 469 */           if (!SamplesManagerView.this.collectProjectFilesFromDirectory(files, directory, monitor))
/* 470 */             return Status.OK_STATUS;
/* 471 */           SamplesManagerView.this.discoveredSamplesDirectories = ((SampleZipFile[])files.values().toArray(
/* 472 */             new SampleZipFile[files.values().size()]));
/*     */         }
/*     */         else {
/* 475 */           monitor.worked(60);
/*     */         }
/* 477 */         monitor.done();
/*     */ 
/* 479 */         SamplesManagerView.this.getShell().getDisplay().asyncExec(new SamplesManagerView.8(this));
/*     */ 
/* 487 */         return Status.OK_STATUS;
/*     */       }
/*     */     };
/* 491 */     job.schedule();
/*     */   }
/*     */ 
/*     */   private boolean collectProjectFilesFromDirectory(Map files, File directory, IProgressMonitor monitor) {
/* 495 */     if (monitor.isCanceled())
/* 496 */       return false;
/* 497 */     monitor.subTask("Reading " + directory.getPath());
/* 498 */     File[] contents = directory.listFiles();
/* 499 */     for (int i = 0; i < contents.length; i++) {
/* 500 */       File file = contents[i];
/* 501 */       if ((file.isFile()) && (file.getName().endsWith(".zip")))
/* 502 */         files.put(file, new SampleZipFile(file));
/* 503 */       if (monitor.isCanceled())
/* 504 */         return false;
/*     */     }
/* 506 */     return true;
/*     */   }
/*     */ 
/*     */   private void compareChapters() {
/* 510 */     SampleZipFile sample = getSelectedSample();
/* 511 */     if (sample == null)
/* 512 */       return;
/* 513 */     CompareConfiguration cc = new CompareConfiguration();
/* 514 */     ResourceToFileCompareInput input = new ResourceToFileCompareInput(this.currentChapterTag, sample
/* 515 */       .getChapterTag(), cc);
/* 516 */     input.setSelection(ResourcesPlugin.getWorkspace().getRoot(), sample.getZipFile());
/* 517 */     CompareUI.openCompareEditor(input);
/*     */   }
/*     */ 
/*     */   public SampleZipFile getSelectedSample() {
/* 521 */     IStructuredSelection selected = (IStructuredSelection)this.projectsList.getSelection();
/* 522 */     if ((selected != null) && (selected.size() == 1)) {
/* 523 */       return (SampleZipFile)selected.getFirstElement();
/*     */     }
/* 525 */     return null;
/*     */   }
/*     */ 
/*     */   public void setFocus() {
/* 529 */     this.projectsList.getControl().setFocus();
/*     */   }
/*     */ 
/*     */   public String getCurrentChapterTag() {
/* 533 */     return this.currentChapterTag;
/*     */   }
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.tools.SamplesManagerView
 * JD-Core Version:    0.6.2
 */