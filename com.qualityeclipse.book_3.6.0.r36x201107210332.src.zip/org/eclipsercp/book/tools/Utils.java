/*     */ package org.eclipsercp.book.tools;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.ILog;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.jface.dialogs.ErrorDialog;
/*     */ import org.eclipse.jface.dialogs.ProgressMonitorDialog;
/*     */ import org.eclipse.jface.operation.IRunnableWithProgress;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ public class Utils
/*     */ {
/*     */   private static final int BUF_SIZE = 4096;
/*     */ 
/*     */   public static void copy(File sourceFile, File destFile, boolean overwrite, IProgressMonitor monitor)
/*     */     throws IOException
/*     */   {
/*  31 */     monitor.subTask("Copying " + sourceFile.getName());
/*  32 */     if ((!overwrite) && (destFile.exists()))
/*  33 */       return;
/*  34 */     if (monitor.isCanceled())
/*  35 */       return;
/*  36 */     File parent = destFile.getParentFile();
/*  37 */     if ((parent != null) && (!parent.exists()))
/*  38 */       parent.mkdirs();
/*  39 */     if (sourceFile.isDirectory()) {
/*  40 */       if (ignoreDirectory(sourceFile))
/*  41 */         return;
/*  42 */       if (!destFile.exists())
/*  43 */         destFile.mkdir();
/*  44 */       File[] children = sourceFile.listFiles();
/*  45 */       for (int i = 0; i < children.length; i++) {
/*  46 */         File file = children[i];
/*  47 */         copy(file, new File(destFile, file.getName()), true, monitor);
/*     */       }
/*  49 */       return;
/*     */     }
/*  51 */     FileInputStream in = null;
/*  52 */     FileOutputStream out = null;
/*     */     try {
/*  54 */       in = new FileInputStream(sourceFile);
/*  55 */       out = new FileOutputStream(destFile);
/*  56 */       byte[] buffer = new byte[4096];
/*  57 */       int count = 0;
/*     */       do {
/*  59 */         out.write(buffer, 0, count);
/*  60 */         count = in.read(buffer, 0, buffer.length);
/*     */ 
/*  62 */         if (count == -1)
/*     */           break;
/*     */       }
/*  58 */       while (!
/*  62 */         monitor.isCanceled());
/*     */     }
/*     */     finally {
/*  65 */       close(out);
/*  66 */       close(in);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean ignoreDirectory(File dir)
/*     */   {
/*  78 */     return ignoreDirectory(dir.getName());
/*     */   }
/*     */ 
/*     */   public static boolean ignoreDirectory(String name)
/*     */   {
/*  89 */     return (name.equalsIgnoreCase("bin")) || (name.equalsIgnoreCase("cvs")) || (name.equalsIgnoreCase(".svn"));
/*     */   }
/*     */ 
/*     */   public static void close(OutputStream device) {
/*  93 */     if (device != null)
/*     */       try {
/*  95 */         device.close();
/*     */       }
/*     */       catch (IOException localIOException) {
/*     */       }
/*     */   }
/*     */ 
/*     */   public static void close(InputStream device) {
/* 102 */     if (device != null)
/*     */       try {
/* 104 */         device.close();
/*     */       }
/*     */       catch (IOException localIOException) {
/*     */       }
/*     */   }
/*     */ 
/*     */   public static void run(Shell shell, IRunnableWithProgress runnable) {
/* 111 */     ProgressMonitorDialog d = new ProgressMonitorDialog(shell);
/*     */     try {
/* 113 */       d.run(true, true, runnable);
/*     */     }
/*     */     catch (InvocationTargetException e)
/*     */     {
/* 117 */       ErrorDialog.openError(shell, "Import Error", "Error importing chapters", statusFrom(e.getTargetException()));
/*     */     }
/*     */     catch (InterruptedException e) {
/* 120 */       ErrorDialog.openError(shell, "Import Error", "Error importing chapters", statusFrom(e));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Status statusFrom(Throwable e) {
/* 125 */     return new Status(4, "com.qualityeclipse.book", 0, e.toString(), e);
/*     */   }
/*     */ 
/*     */   public static void handleError(Shell shell, Exception exception, String title, String message) {
/* 129 */     IStatus status = null;
/* 130 */     boolean log = false;
/* 131 */     boolean dialog = false;
/* 132 */     Throwable t = exception;
/* 133 */     if ((exception instanceof InvocationTargetException)) {
/* 134 */       t = ((InvocationTargetException)exception).getTargetException();
/* 135 */       if ((t instanceof CoreException)) {
/* 136 */         status = ((CoreException)t).getStatus();
/* 137 */         log = true;
/* 138 */         dialog = true;
/*     */       }
/*     */       else {
/* 141 */         if ((t instanceof InterruptedException))
/* 142 */           return;
/* 143 */         status = new Status(4, "com.qualityeclipse.book", 1, "Error", t);
/* 144 */         log = true;
/* 145 */         dialog = true;
/*     */       }
/*     */     }
/* 148 */     if (status == null)
/* 149 */       return;
/* 150 */     if (!status.isOK()) {
/* 151 */       IStatus toShow = status;
/* 152 */       if (status.isMultiStatus()) {
/* 153 */         IStatus[] children = status.getChildren();
/* 154 */         if (children.length == 1)
/* 155 */           toShow = children[0];
/*     */       }
/* 157 */       if (title == null)
/* 158 */         title = status.getMessage();
/* 159 */       if (message == null)
/* 160 */         message = status.getMessage();
/* 161 */       if ((dialog) && (shell != null))
/* 162 */         ErrorDialog.openError(shell, title, message, toShow);
/* 163 */       if ((log) || (shell == null))
/* 164 */         Platform.getLog(Platform.getBundle("com.qualityeclipse.book")).log(toShow);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void logError(String message, CoreException e) {
/* 169 */     IStatus status = new Status(4, "com.qualityeclipse.book", 0, message, e);
/* 170 */     Platform.getLog(Platform.getBundle("com.qualityeclipse.book")).log(status);
/*     */   }
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.tools.Utils
 * JD-Core Version:    0.6.2
 */