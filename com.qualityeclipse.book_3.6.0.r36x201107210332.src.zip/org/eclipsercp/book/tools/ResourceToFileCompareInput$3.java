/*     */ package org.eclipsercp.book.tools;
/*     */ 
/*     */ import org.eclipse.jface.action.Action;
/*     */ 
/*     */ class ResourceToFileCompareInput$3 extends Action
/*     */ {
/*     */   final ResourceToFileCompareInput.1 this$1;
/*     */ 
/*     */   ResourceToFileCompareInput$3(ResourceToFileCompareInput.1 param1, String $anonymous0)
/*     */   {
/* 154 */     super($anonymous0);
/*     */ 
/*   1 */     this.this$1 = param1;
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/* 157 */     ResourceToFileCompareInput.access$4(ResourceToFileCompareInput.1.access$1(this.this$1), this.this$1.getSelection());
/*     */   }
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.tools.ResourceToFileCompareInput.3
 * JD-Core Version:    0.6.2
 */