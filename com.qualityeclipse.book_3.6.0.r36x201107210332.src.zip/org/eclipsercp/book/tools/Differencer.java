/*     */ package org.eclipsercp.book.tools;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.compare.IStreamContentAccessor;
/*     */ import org.eclipse.compare.ITypedElement;
/*     */ import org.eclipse.compare.structuremergeviewer.DiffNode;
/*     */ import org.eclipse.compare.structuremergeviewer.IDiffContainer;
/*     */ import org.eclipse.compare.structuremergeviewer.IStructureComparator;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ 
/*     */ public class Differencer
/*     */ {
/*     */   public static final int NO_CHANGE = 0;
/*     */   public static final int ADDITION = 1;
/*     */   public static final int DELETION = 2;
/*     */   public static final int CHANGE = 3;
/*     */   public static final int CHANGE_TYPE_MASK = 3;
/*     */   public static final int LEFT = 4;
/*     */   public static final int RIGHT = 8;
/*     */   public static final int CONFLICTING = 12;
/*     */   public static final int DIRECTION_MASK = 12;
/*     */   public static final int PSEUDO_CONFLICT = 16;
/*     */ 
/*     */   public Object findDifferences(boolean threeWay, IProgressMonitor pm, Object data, Object ancestor, Object left, Object right)
/*     */   {
/*  80 */     Node root = new Node();
/*  81 */     int code = traverse(threeWay, root, pm, threeWay ? ancestor : null, left, right);
/*  82 */     if (code != 0) {
/*  83 */       List l = root.fChildren;
/*  84 */       if (l.size() > 0) {
/*  85 */         Node first = (Node)l.get(0);
/*  86 */         return first.visit(this, data, 0);
/*     */       }
/*     */     }
/*  89 */     return null;
/*     */   }
/*     */ 
/*     */   private int traverse(boolean threeWay, Node parent, IProgressMonitor pm, Object ancestor, Object left, Object right)
/*     */   {
/*  94 */     Object[] ancestorChildren = getChildren(ancestor);
/*  95 */     Object[] rightChildren = getChildren(right);
/*  96 */     Object[] leftChildren = getChildren(left);
/*  97 */     int code = 0;
/*  98 */     Node node = new Node(parent, ancestor, left, right);
/*  99 */     boolean content = true;
/* 100 */     if (((threeWay) && (ancestorChildren != null)) || ((!threeWay) && ((rightChildren != null) || (leftChildren != null)))) {
/* 101 */       Set allSet = new HashSet(20);
/* 102 */       Map ancestorSet = null;
/* 103 */       Map rightSet = null;
/* 104 */       Map leftSet = null;
/* 105 */       if (ancestorChildren != null) {
/* 106 */         ancestorSet = new HashMap(10);
/* 107 */         for (int i = 0; i < ancestorChildren.length; i++) {
/* 108 */           Object ancestorChild = ancestorChildren[i];
/* 109 */           ancestorSet.put(ancestorChild, ancestorChild);
/* 110 */           allSet.add(ancestorChild);
/*     */         }
/*     */       }
/*     */ 
/* 114 */       if (rightChildren != null) {
/* 115 */         rightSet = new HashMap(10);
/* 116 */         for (int i = 0; i < rightChildren.length; i++) {
/* 117 */           Object rightChild = rightChildren[i];
/* 118 */           rightSet.put(rightChild, rightChild);
/* 119 */           allSet.add(rightChild);
/*     */         }
/*     */       }
/*     */ 
/* 123 */       if (leftChildren != null) {
/* 124 */         leftSet = new HashMap(10);
/* 125 */         for (int i = 0; i < leftChildren.length; i++) {
/* 126 */           Object leftChild = leftChildren[i];
/* 127 */           leftSet.put(leftChild, leftChild);
/* 128 */           allSet.add(leftChild);
/*     */         }
/*     */       }
/*     */ 
/* 132 */       for (Iterator e = allSet.iterator(); e.hasNext(); ) {
/* 133 */         Object keyChild = e.next();
/* 134 */         content = false;
/* 135 */         if (pm != null) {
/* 136 */           if (pm.isCanceled())
/* 137 */             throw new OperationCanceledException();
/* 138 */           updateProgress(pm, keyChild);
/*     */         }
/* 140 */         Object ancestorChild = ancestorSet == null ? null : ancestorSet.get(keyChild);
/* 141 */         Object leftChild = leftSet == null ? null : leftSet.get(keyChild);
/* 142 */         Object rightChild = rightSet == null ? null : rightSet.get(keyChild);
/* 143 */         int c = traverse(threeWay, node, pm, ancestorChild, leftChild, rightChild);
/* 144 */         if ((c & 0x3) != 0) {
/* 145 */           code |= 3;
/* 146 */           code |= c & 0xC;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 151 */     if (content)
/* 152 */       code = compare(threeWay, ancestor, left, right);
/* 153 */     node.fCode = code;
/* 154 */     return code;
/*     */   }
/*     */ 
/*     */   protected Object visit(Object data, int result, Object ancestor, Object left, Object right) {
/* 158 */     return new DiffNode((IDiffContainer)data, result, (ITypedElement)ancestor, (ITypedElement)left, 
/* 159 */       (ITypedElement)right);
/*     */   }
/*     */ 
/*     */   private int compare(boolean threeway, Object ancestor, Object left, Object right) {
/* 163 */     int description = 0;
/* 164 */     if (threeway) {
/* 165 */       if (ancestor == null) {
/* 166 */         if (left == null) {
/* 167 */           if (right == null) {
/* 168 */             throw new RuntimeException();
/*     */           }
/* 170 */           description = 9;
/*     */         }
/* 172 */         else if (right == null) {
/* 173 */           description = 5;
/*     */         }
/*     */         else {
/* 176 */           description = 13;
/* 177 */           if (contentsEqual(left, right))
/* 178 */             description |= 16;
/*     */         }
/*     */       }
/* 181 */       else if (left == null) {
/* 182 */         if (right == null)
/* 183 */           description = 30;
/* 184 */         else if (contentsEqual(ancestor, right))
/* 185 */           description = 6;
/*     */         else
/* 187 */           description = 15;
/*     */       }
/* 189 */       else if (right == null) {
/* 190 */         if (contentsEqual(ancestor, left))
/* 191 */           description = 10;
/*     */         else
/* 193 */           description = 15;
/*     */       }
/*     */       else {
/* 196 */         boolean ay = contentsEqual(ancestor, left);
/* 197 */         boolean am = contentsEqual(ancestor, right);
/* 198 */         if ((!ay) || (!am))
/* 199 */           if ((ay) && (!am)) {
/* 200 */             description = 11;
/* 201 */           } else if ((!ay) && (am)) {
/* 202 */             description = 7;
/*     */           }
/*     */           else {
/* 205 */             description = 15;
/* 206 */             if (contentsEqual(left, right))
/* 207 */               description |= 16;
/*     */           }
/*     */       }
/*     */     }
/* 211 */     else if (left == null) {
/* 212 */       if (right == null) {
/* 213 */         throw new RuntimeException();
/*     */       }
/* 215 */       description = 1;
/*     */     }
/* 217 */     else if (right == null) {
/* 218 */       description = 2;
/* 219 */     } else if (!contentsEqual(left, right)) {
/* 220 */       description = 3;
/* 221 */     }return description;
/*     */   }
/*     */ 
/*     */   protected boolean contentsEqual(Object input1, Object input2) {
/* 225 */     if (input1 == input2) {
/* 226 */       return true;
/*     */     }
/* 228 */     InputStream is1 = null;
/* 229 */     InputStream is2 = null;
/*     */     try
/*     */     {
/* 232 */       is1 = getStream(input1);
/* 233 */       is2 = getStream(input2);
/*     */ 
/* 235 */       if ((is1 == null) && (is2 == null))
/* 236 */         return true;
/* 237 */       if ((is1 == null) || (is2 == null))
/* 238 */         return false; int c1;
/*     */       int c2;
/*     */       do { c1 = is1.read();
/* 242 */         c2 = is2.read();
/* 243 */         if ((c1 == -1) && (c2 == -1))
/* 244 */           return true; }
/* 245 */       while (c1 == c2);
/* 246 */       return false;
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 250 */       return false;
/*     */     }
/*     */     finally {
/* 253 */       Utils.close(is1);
/* 254 */       Utils.close(is2);
/*     */     }
/*     */   }
/*     */ 
/*     */   private InputStream getStream(Object o) {
/* 259 */     if ((o instanceof IStreamContentAccessor))
/*     */       try {
/* 261 */         return ((IStreamContentAccessor)o).getContents();
/*     */       }
/*     */       catch (CoreException localCoreException) {
/*     */       }
/* 265 */     return null;
/*     */   }
/*     */ 
/*     */   protected Object[] getChildren(Object input) {
/* 269 */     if ((input instanceof IStructureComparator)) {
/* 270 */       return ((IStructureComparator)input).getChildren();
/*     */     }
/* 272 */     return null;
/*     */   }
/*     */ 
/*     */   protected void updateProgress(IProgressMonitor progressMonitor, Object node) {
/* 276 */     if ((node instanceof ITypedElement)) {
/* 277 */       String name = ((ITypedElement)node).getName();
/* 278 */       String fmt = "Comparing";
/* 279 */       String msg = MessageFormat.format(fmt, new String[] { 
/* 280 */         name });
/*     */ 
/* 282 */       progressMonitor.subTask(msg);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class Node
/*     */   {
/*     */     List fChildren;
/*     */     int fCode;
/*     */     Object fAncestor;
/*     */     Object fLeft;
/*     */     Object fRight;
/*     */ 
/*     */     void add(Node child)
/*     */     {
/*  40 */       if (this.fChildren == null)
/*  41 */         this.fChildren = new ArrayList();
/*  42 */       this.fChildren.add(child);
/*     */     }
/*     */ 
/*     */     Object visit(Differencer d, Object parent, int level) {
/*  46 */       if (this.fCode == 0)
/*  47 */         return null;
/*  48 */       Object data = d.visit(parent, this.fCode, this.fAncestor, this.fLeft, this.fRight);
/*  49 */       if (this.fChildren != null)
/*     */       {
/*     */         Node n;
/*  51 */         for (Iterator i = this.fChildren.iterator(); i.hasNext(); n.visit(d, data, level + 1)) {
/*  52 */           n = (Node)i.next();
/*     */         }
/*     */       }
/*  55 */       return data;
/*     */     }
/*     */ 
/*     */     Node()
/*     */     {
/*     */     }
/*     */ 
/*     */     Node(Node parent, Object ancestor, Object left, Object right)
/*     */     {
/*  68 */       parent.add(this);
/*  69 */       this.fAncestor = ancestor;
/*  70 */       this.fLeft = left;
/*  71 */       this.fRight = right;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.tools.Differencer
 * JD-Core Version:    0.6.2
 */