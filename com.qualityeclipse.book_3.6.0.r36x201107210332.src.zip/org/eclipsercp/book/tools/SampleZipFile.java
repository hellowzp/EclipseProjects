/*    */ package org.eclipsercp.book.tools;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.util.zip.ZipFile;
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.resources.IWorkspace;
/*    */ import org.eclipse.core.resources.IWorkspaceRoot;
/*    */ import org.eclipse.core.resources.ResourcesPlugin;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.ui.IWorkbench;
/*    */ import org.eclipse.ui.IWorkbenchWindow;
/*    */ import org.eclipse.ui.PlatformUI;
/*    */ 
/*    */ public class SampleZipFile
/*    */ {
/*    */   private final File zipFile;
/*    */   private final String chapterName;
/*    */   private final Integer chapterNum;
/*    */   private final String chapterTag;
/*    */ 
/*    */   SampleZipFile(File file)
/*    */   {
/* 19 */     this.zipFile = file;
/* 20 */     this.chapterName = file.getName().substring(0, file.getName().length() - 4);
/* 21 */     this.chapterNum = extractChapterNum();
/* 22 */     this.chapterTag = (getCategoryName() + "/" + getChapterName());
/*    */   }
/*    */ 
/*    */   private Integer extractChapterNum() {
/* 26 */     int first = this.chapterName.indexOf(' ');
/* 27 */     int second = this.chapterName.indexOf(' ', first + 1);
/*    */     try {
/* 29 */       return new Integer(this.chapterName.substring(first + 1, second));
/*    */     } catch (StringIndexOutOfBoundsException _ex) {
/*    */     }
/* 32 */     return new Integer(0);
/*    */   }
/*    */ 
/*    */   public static String getCurrentChapterTag()
/*    */   {
/* 37 */     String tag = "?/0";
/* 38 */     IProject[] projects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
/* 39 */     for (int i = 0; i < projects.length; i++) {
/* 40 */       IProject project = projects[i];
/*    */       try {
/* 42 */         if (project.isAccessible()) {
/* 43 */           String cat = project.getPersistentProperty(ISamplesManagerConstants.CATEGORY_KEY);
/* 44 */           String chap = project.getPersistentProperty(ISamplesManagerConstants.CHAPTER_NAME_KEY);
/* 45 */           if ((cat != null) && (chap != null))
/* 46 */             tag = cat + "/" + chap;
/*    */         }
/*    */       }
/*    */       catch (CoreException e) {
/* 50 */         Utils.handleError(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), e, "Error", 
/* 51 */           "Error finding current chapter number.");
/*    */       }
/*    */     }
/*    */ 
/* 55 */     return tag;
/*    */   }
/*    */ 
/*    */   public String getChapterTag() {
/* 59 */     return this.chapterTag;
/*    */   }
/*    */ 
/*    */   public String getChapterName() {
/* 63 */     return this.chapterName;
/*    */   }
/*    */ 
/*    */   public String getCategoryName() {
/* 67 */     return this.zipFile.getParentFile().getName();
/*    */   }
/*    */ 
/*    */   public Integer getChapterNum() {
/* 71 */     return this.chapterNum;
/*    */   }
/*    */ 
/*    */   public File getZipFile() {
/* 75 */     return this.zipFile;
/*    */   }
/*    */ 
/*    */   public static boolean isSampleProject(IProject project, ZipFile zip)
/*    */     throws CoreException
/*    */   {
/* 87 */     if ((project.isAccessible()) && 
/* 88 */       (project.getPersistentProperty(ISamplesManagerConstants.SAMPLES_KEY) != null)) {
/* 89 */       return true;
/*    */     }
/*    */ 
/* 92 */     String relPath = project.getName() + "/.project";
/* 93 */     return (zip.getEntry(relPath) != null) || (zip.getEntry("/" + relPath) != null);
/*    */   }
/*    */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.tools.SampleZipFile
 * JD-Core Version:    0.6.2
 */