/*     */ package org.eclipsercp.book.tools;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.TreeSet;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IMarker;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IProjectDescription;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.SubProgressMonitor;
/*     */ import org.eclipse.core.runtime.jobs.IJobManager;
/*     */ import org.eclipse.core.runtime.preferences.InstanceScope;
/*     */ import org.eclipse.jface.dialogs.Dialog;
/*     */ import org.eclipse.jface.dialogs.MessageDialogWithToggle;
/*     */ import org.eclipse.jface.operation.IRunnableWithProgress;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.ui.IEditorDescriptor;
/*     */ import org.eclipse.ui.IEditorRegistry;
/*     */ import org.eclipse.ui.IWorkbench;
/*     */ import org.eclipse.ui.IWorkbenchPage;
/*     */ import org.eclipse.ui.IWorkbenchWindow;
/*     */ import org.eclipse.ui.PartInitException;
/*     */ import org.eclipse.ui.PlatformUI;
/*     */ import org.eclipse.ui.part.FileEditorInput;
/*     */ import org.eclipse.ui.preferences.ScopedPreferenceStore;
/*     */ import org.eclipse.ui.progress.UIJob;
/*     */ import org.osgi.service.prefs.Preferences;
/*     */ 
/*     */ public class ImportSamplesOperation
/*     */   implements IRunnableWithProgress
/*     */ {
/*     */   private static final int BUFSIZE = 1024;
/*     */   private SampleZipFile sampleZipFile;
/*     */   private Shell shell;
/*     */ 
/*     */   public ImportSamplesOperation(Shell shell, SampleZipFile sampleDirectory)
/*     */   {
/*  67 */     this.shell = shell;
/*  68 */     this.sampleZipFile = sampleDirectory;
/*     */   }
/*     */ 
/*     */   public void run(IProgressMonitor monitor) {
/*  72 */     if (this.sampleZipFile == null) {
/*  73 */       return;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  97 */       importChapters(this.sampleZipFile, monitor);
/*  98 */       openDefaultEditor();
/*     */     }
/*     */     catch (IOException e) {
/* 101 */       Utils.handleError(this.shell, e, "Error", "Importing projects");
/*     */     }
/*     */     catch (CoreException e) {
/* 104 */       Utils.handleError(this.shell, e, "Error", "Importing projects");
/*     */     }
/*     */     catch (InvocationTargetException e) {
/* 107 */       Utils.handleError(this.shell, e, "Error", "Importing projects");
/*     */     }
/*     */     catch (InterruptedException e) {
/* 110 */       Utils.handleError(this.shell, e, "Error", "Importing projects");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void openDefaultEditor() {
/* 115 */     UIJob job = new UIJob("Opening editor")
/*     */     {
/*     */       public IStatus runInUIThread(IProgressMonitor monitor)
/*     */       {
/* 119 */         IProject project = getProject();
/* 120 */         if (project == null) {
/* 121 */           return Status.OK_STATUS;
/*     */         }
/* 123 */         IFile fileToOpen = getFileToOpen(project);
/* 124 */         if (fileToOpen == null) {
/* 125 */           return Status.OK_STATUS;
/*     */         }
/* 127 */         IWorkbench workbench = PlatformUI.getWorkbench();
/* 128 */         IEditorRegistry registry = workbench.getEditorRegistry();
/* 129 */         IWorkbenchPage page = workbench.getActiveWorkbenchWindow().getActivePage();
/* 130 */         IEditorDescriptor descriptor = registry.getDefaultEditor(fileToOpen.getName());
/*     */         String id;
/*     */         String id;
/* 132 */         if (descriptor == null)
/* 133 */           id = "org.eclipse.ui.DefaultTextEditor";
/*     */         else
/* 135 */           id = descriptor.getId();
/*     */         try {
/* 137 */           page.openEditor(new FileEditorInput(fileToOpen), id);
/* 138 */           return Status.OK_STATUS;
/*     */         }
/*     */         catch (PartInitException e) {
/* 141 */           Utils.handleError(ImportSamplesOperation.this.shell, e, "Error", "Error opening editor");
/*     */         }
/* 143 */         return Status.OK_STATUS;
/*     */       }
/*     */ 
/*     */       private IFile getFileToOpen(IProject project)
/*     */       {
/* 151 */         String[] allFileNames = { "favorites.product", "plugin.xml", "META-INF/MANIFEST.MF" };
/* 152 */         for (int i = 0; i < allFileNames.length; i++) {
/* 153 */           IFile file = project.getFile(allFileNames[i]);
/* 154 */           if ((file != null) && (file.exists()))
/* 155 */             return file;
/*     */         }
/* 157 */         return null;
/*     */       }
/*     */ 
/*     */       private IProject getProject()
/*     */       {
/* 165 */         IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
/* 166 */         String[] allProjNames = { "com.qualityeclipse.favorites", "lab" };
/* 167 */         for (int i = 0; i < allProjNames.length; i++) {
/* 168 */           IProject project = root.getProject(allProjNames[i]);
/* 169 */           if ((project != null) && (project.exists()))
/* 170 */             return project;
/*     */         }
/* 172 */         return null;
/*     */       }
/*     */     };
/* 176 */     job.schedule(750L);
/*     */   }
/*     */ 
/*     */   private void importChapters(SampleZipFile sample, IProgressMonitor monitor)
/*     */     throws CoreException, InvocationTargetException, InterruptedException, IOException
/*     */   {
/* 191 */     Collection projectsToDelete = new ArrayList();
/*     */ 
/* 193 */     monitor.beginTask("Importing", 100);
/* 194 */     IProject[] projects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
/* 195 */     SubProgressMonitor subDeleteMonitor = new SubProgressMonitor(monitor, 30);
/* 196 */     subDeleteMonitor.beginTask("Deleting projects", projects.length * 100);
/*     */ 
/* 198 */     ZipFile zip = new ZipFile(sample.getZipFile());
/*     */     try {
/* 200 */       for (int i = 0; i < projects.length; i++) {
/* 201 */         IProject project = projects[i];
/* 202 */         if (SampleZipFile.isSampleProject(project, zip))
/* 203 */           projectsToDelete.add(project);
/*     */       }
/*     */     }
/*     */     finally {
/* 207 */       zip.close();
/*     */     }
/* 209 */     subDeleteMonitor.done();
/* 210 */     if (!promptToOverwrite(projectsToDelete)) {
/* 211 */       return;
/*     */     }
/*     */ 
/* 214 */     SubProgressMonitor subImportMonitor = new SubProgressMonitor(monitor, 70);
/* 215 */     subImportMonitor.beginTask("Importing projects", (projectsToDelete.size() * 2 + 3) * 100);
/* 216 */     List importedProjects = new ArrayList();
/* 217 */     Object workspaceOperation = new IWorkspaceRunnable() {
/*     */       private final Collection val$projectsToDelete;
/*     */       private final SampleZipFile val$sample;
/*     */ 
/*     */       public void run(IProgressMonitor monitor) throws CoreException { try { for (Iterator iter = this.val$projectsToDelete.iterator(); iter.hasNext(); ) {
/* 223 */             IProject project = (IProject)iter.next();
/* 224 */             project.delete(true, true, new SubProgressMonitor(monitor, 100));
/*     */           }
/*     */ 
/* 228 */           Collection projectNamesFound = new TreeSet();
/* 229 */           File rootDir = ResourcesPlugin.getWorkspace().getRoot().getLocation().toFile();
/* 230 */           ImportSamplesOperation.this.expandZip(this.val$sample.getZipFile(), rootDir, projectNamesFound, new SubProgressMonitor(monitor, 60));
/*     */ 
/* 233 */           for (Iterator iter = projectNamesFound.iterator(); iter.hasNext(); )
/* 234 */             ImportSamplesOperation.this.createExistingProject(this.val$sample, (String)iter.next(), true, new SubProgressMonitor(monitor, 40));
/*     */         } catch (IOException e)
/*     */         {
/* 237 */           throw new CoreException(Utils.statusFrom(e));
/*     */         }
/*     */         catch (InvocationTargetException e) {
/* 240 */           throw new CoreException(Utils.statusFrom(e));
/*     */         }
/*     */         catch (InterruptedException e) {
/* 243 */           throw new CoreException(Utils.statusFrom(e));
/*     */         }
/*     */       }
/*     */     };
/* 247 */     ResourcesPlugin.getWorkspace().run((IWorkspaceRunnable)workspaceOperation, ResourcesPlugin.getWorkspace().getRoot(), 1, 
/* 248 */       subImportMonitor);
/*     */     try
/*     */     {
/* 251 */       IJobManager jobManager = Platform.getJobManager();
/* 252 */       jobManager.join(ResourcesPlugin.FAMILY_MANUAL_BUILD, monitor);
/* 253 */       jobManager.join(ResourcesPlugin.FAMILY_AUTO_BUILD, monitor);
/* 254 */       IWorkspaceRunnable closeRunnable = new IWorkspaceRunnable() {
/*     */         private final List val$importedProjects;
/*     */ 
/* 257 */         public void run(IProgressMonitor monitor) throws CoreException { boolean reopen = false;
/* 258 */           for (Iterator it = this.val$importedProjects.iterator(); it.hasNext(); ) {
/* 259 */             IProject project = (IProject)it.next();
/* 260 */             if ((project.exists()) && (ImportSamplesOperation.this.existsProblems(project))) {
/* 261 */               reopen = true;
/*     */             }
/*     */           }
/* 264 */           if (reopen) {
/* 265 */             IProject[] projects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
/* 266 */             for (int i = 0; i < projects.length; i++) {
/* 267 */               IProject project = projects[i];
/* 268 */               project.close(new NullProgressMonitor());
/*     */             }
/*     */           }
/*     */         }
/*     */       };
/* 275 */       IWorkspaceRunnable openRunnable = new IWorkspaceRunnable() {
/*     */         private final List val$importedProjects;
/*     */ 
/* 278 */         public void run(IProgressMonitor monitor) throws CoreException { for (Iterator it = this.val$importedProjects.iterator(); it.hasNext(); ) {
/* 279 */             IProject project = (IProject)it.next();
/* 280 */             project.open(new NullProgressMonitor());
/*     */           }
/*     */         }
/*     */       };
/* 286 */       ResourcesPlugin.getWorkspace().run(closeRunnable, new NullProgressMonitor());
/* 287 */       ResourcesPlugin.getWorkspace().run(openRunnable, new NullProgressMonitor());
/*     */     }
/*     */     catch (InterruptedException localInterruptedException) {
/*     */     }
/* 291 */     subImportMonitor.done();
/* 292 */     monitor.done();
/*     */   }
/*     */ 
/*     */   protected void expandZip(File zipFile, File destDir, Collection projectNamesFound, IProgressMonitor monitor)
/*     */     throws IOException
/*     */   {
/* 310 */     monitor.beginTask("Expanding " + zipFile.getName(), 100);
/* 311 */     Path root = new Path(destDir.getPath());
/* 312 */     ZipInputStream zipStream = new ZipInputStream(new FileInputStream(zipFile));
/*     */     try { String pathStr;
/*     */       int index;
/*     */       do { ZipEntry entry;
/*     */         do { if (monitor.isCanceled())
/* 316 */             throw new OperationCanceledException();
/* 317 */           monitor.worked(1);
/*     */ 
/* 320 */           entry = zipStream.getNextEntry();
/* 321 */           if (entry == null)
/*     */             break; }
/* 323 */         while (entry.isDirectory());
/*     */ 
/* 325 */         pathStr = entry.getName();
/* 326 */         index = pathStr.lastIndexOf('/'); }
/* 327 */       while (index == -1);
/*     */ 
/* 329 */       String fileName = pathStr.substring(index + 1);
/* 330 */       String dirName = pathStr.substring(0, index);
/* 331 */       if (dirName.startsWith("/")) {
/* 332 */         dirName = dirName.substring(1);
/*     */       }
/*     */ 
/* 335 */       if ((fileName.equals(".project")) && (dirName.indexOf('/') == -1)) {
/* 336 */         projectNamesFound.add(dirName);
/*     */       }
/*     */ 
/* 339 */       File dir = root.append(dirName).toFile();
/* 340 */       dir.mkdirs();
/* 341 */       FileOutputStream out = new FileOutputStream(new File(dir, fileName));
/*     */       try {
/* 343 */         byte[] buf = new byte[1024];
/*     */ 
/* 345 */         int count = zipStream.read(buf);
/* 346 */         if (count != -1)
/*     */         {
/* 348 */           out.write(buf, 0, count);
/*     */         }
/*     */       }
/*     */       finally {
/* 352 */         out.close();
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 357 */       zipStream.close();
/*     */     }
/* 359 */     monitor.done();
/*     */   }
/*     */ 
/*     */   protected boolean existsProblems(IProject proj) throws CoreException {
/* 363 */     IMarker[] markers = proj.findMarkers("org.eclipse.core.resources.problemmarker", true, 2);
/* 364 */     if (markers.length > 0) {
/* 365 */       for (int i = 0; i < markers.length; i++) {
/* 366 */         if (isLaunchProblem(markers[i]))
/* 367 */           return true;
/*     */       }
/*     */     }
/* 370 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean isLaunchProblem(IMarker problemMarker) throws CoreException {
/* 374 */     Integer severity = (Integer)problemMarker.getAttribute("severity");
/* 375 */     if (severity != null) {
/* 376 */       return severity.intValue() >= 2;
/*     */     }
/* 378 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean promptToOverwrite(Collection projectsToDelete)
/*     */   {
/* 395 */     if (projectsToDelete.size() == 0)
/* 396 */       return true;
/* 397 */     Preferences prefs = new InstanceScope().getNode("com.qualityeclipse.book");
/* 398 */     boolean defaultValue = prefs.getBoolean("dont_ask_again_to_overwrite", true);
/* 399 */     if (!defaultValue) {
/* 400 */       return true;
/*     */     }
/*     */ 
/* 404 */     boolean[] retVal = new boolean[1];
/* 405 */     this.shell.getDisplay().syncExec(new Runnable() { private final Collection val$projectsToDelete;
/*     */       private final boolean[] val$retVal;
/*     */ 
/* 408 */       public void run() { ScopedPreferenceStore store = new ScopedPreferenceStore(new InstanceScope(), 
/* 409 */           "com.qualityeclipse.book");
/* 410 */         StringBuffer buf = new StringBuffer(250);
/* 411 */         buf.append("The following projects will be deleted as part of the import operation:\n");
/* 412 */         Collection projectNames = new TreeSet(new ImportSamplesOperation.6(this));
/*     */ 
/* 417 */         for (Iterator iter = this.val$projectsToDelete.iterator(); iter.hasNext(); )
/* 418 */           projectNames.add(((IProject)iter.next()).getName());
/* 419 */         for (Iterator iter = projectNames.iterator(); iter.hasNext(); )
/* 420 */           buf.append("\n      " + iter.next());
/* 421 */         buf.append("\n\nDo you wish to continue?");
/* 422 */         Dialog d = MessageDialogWithToggle.openOkCancelConfirm(ImportSamplesOperation.this.shell, "Warning", buf.toString(), 
/* 423 */           "Don't show this message again", false, store, "dont_ask_again_to_overwrite");
/* 424 */         this.val$retVal[0] = (d.getReturnCode() == 0 ? 1 : false);
/*     */         try {
/* 426 */           store.save();
/*     */         }
/*     */         catch (IOException e) {
/* 429 */           Utils.handleError(ImportSamplesOperation.this.shell, e, "Error", "Problems saving preferences");
/*     */         }
/*     */       }
/*     */     });
/* 434 */     return retVal[0];
/*     */   }
/*     */ 
/*     */   private boolean createExistingProject(SampleZipFile sample, String projDirName, boolean updateProperty, IProgressMonitor monitor)
/*     */     throws InvocationTargetException, InterruptedException
/*     */   {
/* 451 */     monitor.beginTask("Importing", 2000);
/*     */ 
/* 455 */     String projectName = projDirName;
/*     */ 
/* 457 */     IWorkspace workspace = ResourcesPlugin.getWorkspace();
/* 458 */     IProject project = workspace.getRoot().getProject(projectName);
/* 459 */     IProjectDescription description = workspace.newProjectDescription(projectName);
/*     */     try {
/* 461 */       description.setLocation(null);
/* 462 */       if (project.exists()) {
/* 463 */         if (!project.isOpen())
/* 464 */           project.open(null);
/* 465 */         project.delete(true, null);
/*     */       }
/* 467 */       project.create(description, new SubProgressMonitor(monitor, 1000));
/* 468 */       if (monitor.isCanceled())
/* 469 */         throw new OperationCanceledException();
/* 470 */       project.open(128, new SubProgressMonitor(monitor, 1000));
/* 471 */       if (updateProperty) {
/* 472 */         project.setPersistentProperty(ISamplesManagerConstants.CATEGORY_KEY, sample.getCategoryName());
/* 473 */         project.setPersistentProperty(ISamplesManagerConstants.CHAPTER_NAME_KEY, sample.getChapterName());
/*     */       }
/* 475 */       project.setPersistentProperty(ISamplesManagerConstants.SAMPLES_KEY, "rcpbook-project");
/*     */     }
/*     */     catch (Exception e) {
/* 478 */       Utils.handleError(this.shell, e, "Error", "Problem importing projects");
/*     */     }
/* 480 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.tools.ImportSamplesOperation
 * JD-Core Version:    0.6.2
 */