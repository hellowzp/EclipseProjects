/*     */ package org.eclipsercp.book.tools;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.eclipse.compare.IEditableContent;
/*     */ import org.eclipse.compare.IStreamContentAccessor;
/*     */ import org.eclipse.compare.ITypedElement;
/*     */ import org.eclipse.compare.ResourceNode;
/*     */ import org.eclipse.compare.structuremergeviewer.IStructureComparator;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IFolder;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ public class EclipseResourceNode extends ResourceNode
/*     */ {
/*     */   private boolean fDirty;
/*     */   private IFile fDeleteFile;
/*     */ 
/*     */   public EclipseResourceNode(IResource resource)
/*     */   {
/*  30 */     super(resource);
/*  31 */     this.fDirty = false;
/*     */   }
/*     */ 
/*     */   protected IStructureComparator createChild(IResource child) {
/*  35 */     if (shouldCreateChild(child)) {
/*  36 */       return new EclipseResourceNode(child);
/*     */     }
/*  38 */     return null;
/*     */   }
/*     */ 
/*     */   protected boolean shouldCreateChild(IResource child) {
/*  42 */     String name = child.getName();
/*  43 */     if (child.isDerived())
/*  44 */       return false;
/*  45 */     if (Utils.ignoreDirectory(child.getName()))
/*  46 */       return false;
/*  47 */     return true;
/*     */   }
/*     */ 
/*     */   public void setContent(byte[] contents) {
/*  51 */     this.fDirty = true;
/*  52 */     super.setContent(contents);
/*     */   }
/*     */ 
/*     */   public void commit(IProgressMonitor pm) throws CoreException {
/*  56 */     if (!this.fDirty)
/*  57 */       return;
/*  58 */     if (this.fDeleteFile != null) {
/*  59 */       this.fDeleteFile.delete(true, true, pm);
/*  60 */       return;
/*     */     }
/*  62 */     IResource resource = getResource();
/*  63 */     if (!(resource instanceof IFile))
/*  64 */       return;
/*  65 */     ByteArrayInputStream is = new ByteArrayInputStream(getContent());
/*     */     try {
/*  67 */       IFile file = (IFile)resource;
/*  68 */       if (file.exists()) {
/*  69 */         file.setContents(is, false, true, pm);
/*     */       }
/*     */       else {
/*  72 */         createParents(file);
/*  73 */         file.create(is, false, pm);
/*     */       }
/*  75 */       this.fDirty = false;
/*     */     }
/*     */     finally {
/*  78 */       fireContentChanged();
/*  79 */       if (is != null)
/*     */         try {
/*  81 */           is.close();
/*     */         }
/*     */         catch (IOException localIOException) {
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void createParents(IResource r) {
/*  89 */     IContainer p = r.getParent();
/*  90 */     if (p.getType() == 8)
/*  91 */       return;
/*  92 */     if ((p instanceof IContainer)) {
/*  93 */       IContainer f = p;
/*  94 */       if (!f.exists()) {
/*  95 */         createParents(f);
/*     */         try {
/*  97 */           if (f.getType() == 4) {
/*  98 */             IProject project = (IProject)f;
/*  99 */             project.create(new NullProgressMonitor());
/* 100 */             project.open(new NullProgressMonitor());
/*     */           }
/*     */           else {
/* 103 */             ((IFolder)f).create(true, true, new NullProgressMonitor());
/*     */           }
/*     */         }
/*     */         catch (CoreException localCoreException) {
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public ITypedElement replace(ITypedElement child, ITypedElement other) {
/* 113 */     if (child == null) {
/* 114 */       IResource resource = getResource();
/* 115 */       if ((resource instanceof IContainer)) {
/* 116 */         IContainer folder = (IContainer)resource;
/* 117 */         if (other.getType() == "FOLDER") {
/* 118 */           IResource childResource = null;
/* 119 */           if (folder.getType() == 8)
/* 120 */             childResource = ((IWorkspaceRoot)folder).getProject(other.getName());
/*     */           else
/* 122 */             childResource = folder.getFolder(new Path(other.getName()));
/* 123 */           child = new EclipseResourceNode(childResource);
/*     */         }
/*     */         else {
/* 126 */           IFile file = folder.getFile(new Path(other.getName()));
/* 127 */           child = new EclipseResourceNode(file);
/*     */         }
/*     */       }
/*     */     }
/* 131 */     if (other == null) {
/* 132 */       IResource resource = getResource();
/* 133 */       if ((resource instanceof IFolder)) {
/* 134 */         IFolder folder = (IFolder)resource;
/* 135 */         IFile file = folder.getFile(child.getName());
/* 136 */         if ((file != null) && (file.exists())) {
/* 137 */           this.fDeleteFile = file;
/* 138 */           this.fDirty = true;
/*     */         }
/*     */       }
/* 141 */       return null;
/*     */     }
/* 143 */     if (((other instanceof IStreamContentAccessor)) && ((child instanceof IEditableContent))) {
/* 144 */       IEditableContent dst = (IEditableContent)child;
/*     */       try {
/* 146 */         InputStream is = ((IStreamContentAccessor)other).getContents();
/* 147 */         if (is != null) {
/* 148 */           byte[] bytes = readBytes(is);
/* 149 */           if (bytes != null)
/* 150 */             dst.setContent(bytes);
/*     */         }
/*     */       }
/*     */       catch (CoreException localCoreException) {
/*     */       }
/*     */     }
/* 156 */     fireContentChanged();
/* 157 */     return child;
/*     */   }
/*     */ 
/*     */   public static byte[] readBytes(InputStream in) {
/* 161 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*     */     try {
/*     */       while (true) {
/* 164 */         int c = in.read();
/* 165 */         if (c == -1)
/*     */           break;
/* 167 */         bos.write(c);
/*     */       }
/* 169 */       return bos.toByteArray();
/*     */     }
/*     */     catch (IOException e) {
/* 172 */       return null;
/*     */     }
/*     */     finally {
/* 175 */       Utils.close(in);
/* 176 */       Utils.close(bos);
/*     */     }
/*     */   }
/*     */ 
/*     */   public InputStream getContents() throws CoreException {
/* 181 */     if (getResource().exists()) {
/* 182 */       return super.getContents();
/*     */     }
/* 184 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.tools.EclipseResourceNode
 * JD-Core Version:    0.6.2
 */