/*     */ package org.eclipsercp.book.tools;
/*     */ 
/*     */ import com.instantiations.book.Activator;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.TreeSet;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import org.eclipse.compare.BufferedContent;
/*     */ import org.eclipse.compare.CompareUI;
/*     */ import org.eclipse.compare.IEditableContent;
/*     */ import org.eclipse.compare.IEncodedStreamContentAccessor;
/*     */ import org.eclipse.compare.IModificationDate;
/*     */ import org.eclipse.compare.ITypedElement;
/*     */ import org.eclipse.compare.structuremergeviewer.IStructureComparator;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.ILog;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ 
/*     */ public class ZipFileNode extends BufferedContent
/*     */   implements IEncodedStreamContentAccessor, IStructureComparator, ITypedElement, IEditableContent, IModificationDate
/*     */ {
/*  47 */   private static final ZipFileNode[] NO_CHILDREN = new ZipFileNode[0];
/*     */   private final ZipCache zipCache;
/*     */   private final String zipPath;
/*     */   private ZipFileNode[] fChildren;
/*     */ 
/*     */   public ZipFileNode(File zipFile)
/*     */   {
/*  59 */     this(new ZipCache(zipFile), "");
/*     */   }
/*     */ 
/*     */   private ZipFileNode(ZipCache zipCache, String zipPath)
/*     */   {
/*  70 */     this.zipCache = zipCache;
/*  71 */     this.zipPath = zipPath;
/*     */   }
/*     */ 
/*     */   public InputStream getContents()
/*     */     throws CoreException
/*     */   {
/*  79 */     if ((this.zipPath.length() == 0) || (this.zipPath.charAt(this.zipPath.length() - 1) == '/'))
/*  80 */       return null; try { ZipInputStream zipStream = new ZipInputStream(new FileInputStream(this.zipCache.zipFile));
/*     */       String path;
/*     */       do {
/*  84 */         ZipEntry entry = zipStream.getNextEntry();
/*  85 */         if (entry == null) {
/*  86 */           logError("Failed to find " + this.zipPath + " in " + this.zipCache.zipFile.getPath(), null);
/*  87 */           return null;
/*     */         }
/*  89 */         path = entry.getName();
/*  90 */         if (path.charAt(0) == '/')
/*  91 */           path = path.substring(1); 
/*     */       }
/*  92 */       while (!path.equals(this.zipPath));
/*     */ 
/*  95 */       return zipStream;
/*     */     } catch (IOException e)
/*     */     {
/*  98 */       logError("Failed to read " + this.zipPath + " from " + this.zipCache.zipFile.getPath(), e);
/*  99 */     }return null;
/*     */   }
/*     */ 
/*     */   public long getModificationDate()
/*     */   {
/* 108 */     return this.zipCache.zipFile.lastModified();
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 117 */     if (this.zipPath.length() == 0) {
/* 118 */       String name = this.zipCache.zipFile.getName();
/* 119 */       if (name.endsWith(".zip"))
/* 120 */         name = name.substring(0, name.length() - 4);
/* 121 */       return name;
/*     */     }
/* 123 */     String name = this.zipPath;
/* 124 */     if (name.charAt(name.length() - 1) == '/')
/* 125 */       name = name.substring(0, name.length() - 1);
/* 126 */     return name.substring(name.lastIndexOf('/') + 1);
/*     */   }
/*     */ 
/*     */   public String getType()
/*     */   {
/* 133 */     if ((this.zipPath.length() == 0) || (this.zipPath.charAt(this.zipPath.length() - 1) == '/'))
/* 134 */       return "FOLDER";
/* 135 */     String name = this.zipPath.substring(this.zipPath.lastIndexOf('/') + 1);
/* 136 */     int index = name.lastIndexOf('.');
/* 137 */     if (index == -1)
/* 138 */       return "???";
/* 139 */     return name.substring(index + 1);
/*     */   }
/*     */ 
/*     */   public Image getImage()
/*     */   {
/* 146 */     return CompareUI.getImage(getType());
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 153 */     if ((other instanceof ITypedElement)) {
/* 154 */       String otherName = ((ITypedElement)other).getName();
/* 155 */       return getName().equals(otherName);
/*     */     }
/*     */ 
/* 158 */     return super.equals(other);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 166 */     return getName().hashCode();
/*     */   }
/*     */ 
/*     */   public Object[] getChildren()
/*     */   {
/* 177 */     if (this.fChildren != null) {
/* 178 */       return this.fChildren;
/*     */     }
/*     */ 
/* 181 */     if ((this.zipPath.length() > 0) && (this.zipPath.charAt(this.zipPath.length() - 1) != '/')) {
/* 182 */       this.fChildren = NO_CHILDREN;
/* 183 */       return this.fChildren;
/*     */     }
/*     */ 
/* 187 */     Collection childPaths = this.zipCache.getChildPaths(this.zipPath);
/* 188 */     this.fChildren = new ZipFileNode[childPaths.size()];
/* 189 */     Iterator iter = childPaths.iterator();
/* 190 */     for (int i = 0; i < this.fChildren.length; i++)
/* 191 */       this.fChildren[i] = new ZipFileNode(this.zipCache, (String)iter.next());
/* 192 */     return this.fChildren;
/*     */   }
/*     */ 
/*     */   public boolean isEditable() {
/* 196 */     return false;
/*     */   }
/*     */ 
/*     */   public ITypedElement replace(ITypedElement child, ITypedElement other) {
/* 200 */     return child;
/*     */   }
/*     */ 
/*     */   public String getCharset() {
/* 204 */     return null;
/*     */   }
/*     */ 
/*     */   protected InputStream createStream() throws CoreException {
/* 208 */     return null;
/*     */   }
/*     */ 
/*     */   private static void logError(String message, Throwable e) {
/* 212 */     Activator.getDefault().getLog().log(new Status(4, "com.qualityeclipse.book", 0, message, e));
/*     */   }
/*     */ 
/*     */   private static class ZipCache
/*     */   {
/*     */     final File zipFile;
/*     */     private Map childPathMap;
/*     */ 
/*     */     ZipCache(File zipFile)
/*     */     {
/* 224 */       this.zipFile = zipFile;
/*     */     }
/*     */ 
/*     */     public Collection getChildPaths(String parentPath)
/*     */     {
/* 235 */       if (this.childPathMap == null)
/* 236 */         initChildPathMap();
/* 237 */       Object childPaths = this.childPathMap.get(parentPath);
/* 238 */       if (childPaths == null)
/* 239 */         return new TreeSet();
/* 240 */       return (Collection)childPaths; } 
/*     */     // ERROR //
/*     */     private void initChildPathMap() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: new 43	java/util/TreeMap
/*     */       //   4: dup
/*     */       //   5: invokespecial 45	java/util/TreeMap:<init>	()V
/*     */       //   8: putfield 23	org/eclipsercp/book/tools/ZipFileNode$ZipCache:childPathMap	Ljava/util/Map;
/*     */       //   11: aconst_null
/*     */       //   12: astore_1
/*     */       //   13: new 46	java/util/zip/ZipInputStream
/*     */       //   16: dup
/*     */       //   17: new 48	java/io/FileInputStream
/*     */       //   20: dup
/*     */       //   21: aload_0
/*     */       //   22: getfield 15	org/eclipsercp/book/tools/ZipFileNode$ZipCache:zipFile	Ljava/io/File;
/*     */       //   25: invokespecial 50	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*     */       //   28: invokespecial 52	java/util/zip/ZipInputStream:<init>	(Ljava/io/InputStream;)V
/*     */       //   31: astore_1
/*     */       //   32: aload_1
/*     */       //   33: invokevirtual 55	java/util/zip/ZipInputStream:getNextEntry	()Ljava/util/zip/ZipEntry;
/*     */       //   36: astore_2
/*     */       //   37: aload_2
/*     */       //   38: ifnonnull +6 -> 44
/*     */       //   41: goto +207 -> 248
/*     */       //   44: aload_2
/*     */       //   45: invokevirtual 59	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
/*     */       //   48: astore_3
/*     */       //   49: aload_3
/*     */       //   50: iconst_0
/*     */       //   51: invokevirtual 65	java/lang/String:charAt	(I)C
/*     */       //   54: bipush 47
/*     */       //   56: if_icmpne +9 -> 65
/*     */       //   59: aload_3
/*     */       //   60: iconst_1
/*     */       //   61: invokevirtual 71	java/lang/String:substring	(I)Ljava/lang/String;
/*     */       //   64: astore_3
/*     */       //   65: ldc 75
/*     */       //   67: astore 4
/*     */       //   69: aload_3
/*     */       //   70: bipush 47
/*     */       //   72: aload 4
/*     */       //   74: invokevirtual 77	java/lang/String:length	()I
/*     */       //   77: invokevirtual 81	java/lang/String:indexOf	(II)I
/*     */       //   80: istore 5
/*     */       //   82: iload 5
/*     */       //   84: iconst_m1
/*     */       //   85: if_icmpne +6 -> 91
/*     */       //   88: goto +29 -> 117
/*     */       //   91: aload_3
/*     */       //   92: iconst_0
/*     */       //   93: iload 5
/*     */       //   95: iconst_1
/*     */       //   96: iadd
/*     */       //   97: invokevirtual 85	java/lang/String:substring	(II)Ljava/lang/String;
/*     */       //   100: astore 6
/*     */       //   102: aload_0
/*     */       //   103: aload 4
/*     */       //   105: aload 6
/*     */       //   107: invokespecial 88	org/eclipsercp/book/tools/ZipFileNode$ZipCache:addChild	(Ljava/lang/String;Ljava/lang/String;)V
/*     */       //   110: aload 6
/*     */       //   112: astore 4
/*     */       //   114: goto -45 -> 69
/*     */       //   117: aload_0
/*     */       //   118: aload 4
/*     */       //   120: aload_3
/*     */       //   121: invokespecial 88	org/eclipsercp/book/tools/ZipFileNode$ZipCache:addChild	(Ljava/lang/String;Ljava/lang/String;)V
/*     */       //   124: goto -92 -> 32
/*     */       //   127: astore_2
/*     */       //   128: new 92	java/lang/StringBuffer
/*     */       //   131: dup
/*     */       //   132: ldc 94
/*     */       //   134: invokespecial 96	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
/*     */       //   137: aload_0
/*     */       //   138: getfield 15	org/eclipsercp/book/tools/ZipFileNode$ZipCache:zipFile	Ljava/io/File;
/*     */       //   141: invokevirtual 99	java/io/File:getPath	()Ljava/lang/String;
/*     */       //   144: invokevirtual 104	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */       //   147: invokevirtual 108	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*     */       //   150: aload_2
/*     */       //   151: invokestatic 111	org/eclipsercp/book/tools/ZipFileNode:access$0	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */       //   154: aload_0
/*     */       //   155: getfield 15	org/eclipsercp/book/tools/ZipFileNode$ZipCache:zipFile	Ljava/io/File;
/*     */       //   158: ifnull +133 -> 291
/*     */       //   161: aload_1
/*     */       //   162: invokevirtual 117	java/util/zip/ZipInputStream:close	()V
/*     */       //   165: goto +126 -> 291
/*     */       //   168: astore 8
/*     */       //   170: new 92	java/lang/StringBuffer
/*     */       //   173: dup
/*     */       //   174: ldc 120
/*     */       //   176: invokespecial 96	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
/*     */       //   179: aload_0
/*     */       //   180: getfield 15	org/eclipsercp/book/tools/ZipFileNode$ZipCache:zipFile	Ljava/io/File;
/*     */       //   183: invokevirtual 99	java/io/File:getPath	()Ljava/lang/String;
/*     */       //   186: invokevirtual 104	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */       //   189: invokevirtual 108	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*     */       //   192: aload 8
/*     */       //   194: invokestatic 111	org/eclipsercp/book/tools/ZipFileNode:access$0	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */       //   197: goto +94 -> 291
/*     */       //   200: astore 7
/*     */       //   202: aload_0
/*     */       //   203: getfield 15	org/eclipsercp/book/tools/ZipFileNode$ZipCache:zipFile	Ljava/io/File;
/*     */       //   206: ifnull +39 -> 245
/*     */       //   209: aload_1
/*     */       //   210: invokevirtual 117	java/util/zip/ZipInputStream:close	()V
/*     */       //   213: goto +32 -> 245
/*     */       //   216: astore 8
/*     */       //   218: new 92	java/lang/StringBuffer
/*     */       //   221: dup
/*     */       //   222: ldc 120
/*     */       //   224: invokespecial 96	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
/*     */       //   227: aload_0
/*     */       //   228: getfield 15	org/eclipsercp/book/tools/ZipFileNode$ZipCache:zipFile	Ljava/io/File;
/*     */       //   231: invokevirtual 99	java/io/File:getPath	()Ljava/lang/String;
/*     */       //   234: invokevirtual 104	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */       //   237: invokevirtual 108	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*     */       //   240: aload 8
/*     */       //   242: invokestatic 111	org/eclipsercp/book/tools/ZipFileNode:access$0	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */       //   245: aload 7
/*     */       //   247: athrow
/*     */       //   248: aload_0
/*     */       //   249: getfield 15	org/eclipsercp/book/tools/ZipFileNode$ZipCache:zipFile	Ljava/io/File;
/*     */       //   252: ifnull +39 -> 291
/*     */       //   255: aload_1
/*     */       //   256: invokevirtual 117	java/util/zip/ZipInputStream:close	()V
/*     */       //   259: goto +32 -> 291
/*     */       //   262: astore 8
/*     */       //   264: new 92	java/lang/StringBuffer
/*     */       //   267: dup
/*     */       //   268: ldc 120
/*     */       //   270: invokespecial 96	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
/*     */       //   273: aload_0
/*     */       //   274: getfield 15	org/eclipsercp/book/tools/ZipFileNode$ZipCache:zipFile	Ljava/io/File;
/*     */       //   277: invokevirtual 99	java/io/File:getPath	()Ljava/lang/String;
/*     */       //   280: invokevirtual 104	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */       //   283: invokevirtual 108	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*     */       //   286: aload 8
/*     */       //   288: invokestatic 111	org/eclipsercp/book/tools/ZipFileNode:access$0	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */       //   291: return
/*     */       //
/*     */       // Exception table:
/*     */       //   from	to	target	type
/*     */       //   13	127	127	java/io/IOException
/*     */       //   154	165	168	java/io/IOException
/*     */       //   13	154	200	finally
/*     */       //   202	213	216	java/io/IOException
/*     */       //   248	259	262	java/io/IOException } 
/* 295 */     private void addChild(String parentPath, String childPath) { Collection children = (Collection)this.childPathMap.get(parentPath);
/* 296 */       if (children == null) {
/* 297 */         children = new TreeSet();
/* 298 */         this.childPathMap.put(parentPath, children);
/*     */       }
/* 300 */       children.add(childPath);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.tools.ZipFileNode
 * JD-Core Version:    0.6.2
 */