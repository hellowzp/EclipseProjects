/*    */ package org.eclipsercp.book.tools;
/*    */ 
/*    */ import org.eclipse.core.runtime.QualifiedName;
/*    */ 
/*    */ public abstract interface ISamplesManagerConstants
/*    */ {
/*    */   public static final String PLUGIN_ID = "com.qualityeclipse.book";
/*    */   public static final String SAMPLES_PLUGIN_ID = "com.qualityeclipse.book";
/*    */   public static final String FEATURE_ID = "com.qualityeclipse.book";
/*    */   public static final String SAMPLES_FOLDER = "samples";
/*    */   public static final String PATH_PREF = "path";
/*    */   public static final String PROMPT_OVERWRITE_PREF = "dont_ask_again_to_overwrite";
/*    */   public static final String IMAGE_IMPORT = "icons/import.gif";
/*    */   public static final String IMAGE_COMPARE = "icons/compare.gif";
/* 19 */   public static final QualifiedName SAMPLES_KEY = new QualifiedName("com.qualityeclipse.book", "sample-project");
/* 20 */   public static final QualifiedName CATEGORY_KEY = new QualifiedName("com.qualityeclipse.book", "category");
/* 21 */   public static final QualifiedName CHAPTER_NAME_KEY = new QualifiedName("com.qualityeclipse.book", "chapter-name");
/*    */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.tools.ISamplesManagerConstants
 * JD-Core Version:    0.6.2
 */