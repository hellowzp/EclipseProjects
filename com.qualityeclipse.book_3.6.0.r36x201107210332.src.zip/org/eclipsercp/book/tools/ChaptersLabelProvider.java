/*    */ package org.eclipsercp.book.tools;
/*    */ 
/*    */ import java.io.File;
/*    */ import org.eclipse.jface.resource.FontRegistry;
/*    */ import org.eclipse.jface.resource.ImageDescriptor;
/*    */ import org.eclipse.jface.resource.JFaceResources;
/*    */ import org.eclipse.jface.viewers.IFontProvider;
/*    */ import org.eclipse.jface.viewers.LabelProvider;
/*    */ import org.eclipse.swt.graphics.Font;
/*    */ import org.eclipse.swt.graphics.Image;
/*    */ import org.eclipse.ui.plugin.AbstractUIPlugin;
/*    */ 
/*    */ class ChaptersLabelProvider extends LabelProvider
/*    */   implements IFontProvider
/*    */ {
/*    */   private final SamplesManagerView view;
/*    */   private Image image;
/*    */ 
/*    */   ChaptersLabelProvider(SamplesManagerView view)
/*    */   {
/* 19 */     this.view = view;
/*    */   }
/*    */ 
/*    */   public String getText(Object element) {
/* 23 */     SampleZipFile chapterRecord = (SampleZipFile)element;
/* 24 */     String name = chapterRecord.getZipFile().getName();
/* 25 */     if (name.endsWith(".zip"))
/* 26 */       name = name.substring(0, name.length() - 4);
/* 27 */     if (getCurrentChapterTag().equals(chapterRecord.getChapterTag())) {
/* 28 */       return name + " (currently loaded)";
/*    */     }
/* 30 */     return name;
/*    */   }
/*    */ 
/*    */   private String getCurrentChapterTag() {
/* 34 */     return this.view.getCurrentChapterTag();
/*    */   }
/*    */ 
/*    */   public Image getImage(Object element) {
/* 38 */     if (this.image == null)
/* 39 */       this.image = AbstractUIPlugin.imageDescriptorFromPlugin("com.qualityeclipse.book", "icons/bkmrk_nav.gif")
/* 40 */         .createImage(true);
/* 41 */     return this.image;
/*    */   }
/*    */ 
/*    */   public Font getFont(Object element) {
/* 45 */     SampleZipFile chapterRecord = (SampleZipFile)element;
/* 46 */     if (getCurrentChapterTag().equals(chapterRecord.getChapterTag())) {
/* 47 */       return JFaceResources.getFontRegistry().getBold("org.eclipse.jface.defaultfont");
/*    */     }
/* 49 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.tools.ChaptersLabelProvider
 * JD-Core Version:    0.6.2
 */