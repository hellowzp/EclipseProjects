/*    */ package org.eclipsercp.book.zip;
/*    */ 
/*    */ import org.eclipse.core.resources.IWorkspace;
/*    */ import org.eclipse.core.resources.IWorkspaceRoot;
/*    */ import org.eclipse.core.resources.ResourcesPlugin;
/*    */ import org.eclipse.jface.viewers.IStructuredContentProvider;
/*    */ import org.eclipse.jface.viewers.Viewer;
/*    */ 
/*    */ class ZipChaptersTableContentProvider
/*    */   implements IStructuredContentProvider
/*    */ {
/*    */   private Object root;
/*    */ 
/*    */   public void inputChanged(Viewer viewer, Object oldInput, Object newInput)
/*    */   {
/* 13 */     this.root = newInput;
/*    */   }
/*    */ 
/*    */   public void dispose() {
/*    */   }
/*    */ 
/*    */   public Object[] getElements(Object inputElement) {
/* 20 */     if (inputElement == this.root)
/* 21 */       return ResourcesPlugin.getWorkspace().getRoot().getProjects();
/* 22 */     return new Object[0];
/*    */   }
/*    */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.zip.ZipChaptersTableContentProvider
 * JD-Core Version:    0.6.2
 */