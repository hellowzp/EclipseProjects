/*    */ package org.eclipsercp.book.zip;
/*    */ 
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.jface.viewers.ITableLabelProvider;
/*    */ import org.eclipse.jface.viewers.LabelProvider;
/*    */ import org.eclipse.swt.graphics.Image;
/*    */ 
/*    */ class ZipChaptersTableLabelProvider extends LabelProvider
/*    */   implements ITableLabelProvider
/*    */ {
/*    */   public String getColumnText(Object element, int columnIndex)
/*    */   {
/* 15 */     if ((element instanceof IProject))
/* 16 */       return ((IProject)element).getName();
/* 17 */     return Integer.toString(columnIndex) + " - " + element;
/*    */   }
/*    */ 
/*    */   public Image getColumnImage(Object element, int columnIndex) {
/* 21 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.zip.ZipChaptersTableLabelProvider
 * JD-Core Version:    0.6.2
 */