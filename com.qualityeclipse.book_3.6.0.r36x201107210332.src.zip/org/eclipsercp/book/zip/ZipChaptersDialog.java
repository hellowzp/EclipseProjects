/*     */ package org.eclipsercp.book.zip;
/*     */ 
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.jface.dialogs.Dialog;
/*     */ import org.eclipse.jface.dialogs.IDialogConstants;
/*     */ import org.eclipse.jface.viewers.CheckboxTableViewer;
/*     */ import org.eclipse.swt.events.ModifyEvent;
/*     */ import org.eclipse.swt.events.ModifyListener;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Table;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ public class ZipChaptersDialog extends Dialog
/*     */ {
/*  33 */   private static final IProject[] NO_PROJECTS = new IProject[0];
/*     */   private CheckboxTableViewer projectTableViewer;
/*     */   private Text chapterNameField;
/*     */   private Text categoryNameField;
/*     */   private Table table;
/*  40 */   private String categoryName = "";
/*  41 */   private String chapterName = "";
/*  42 */   private IProject[] selectedProjects = NO_PROJECTS;
/*     */   private Button okButton;
/*     */ 
/*     */   public ZipChaptersDialog(Shell parentShell)
/*     */   {
/*  51 */     super(parentShell);
/*     */   }
/*     */ 
/*     */   protected Control createDialogArea(Composite parent)
/*     */   {
/*  66 */     Composite container = (Composite)super.createDialogArea(parent);
/*  67 */     GridLayout gridLayout = new GridLayout();
/*  68 */     gridLayout.numColumns = 2;
/*  69 */     container.setLayout(gridLayout);
/*     */ 
/*  71 */     Label thisOperationWillLabel = new Label(container, 0);
/*  72 */     GridData gridData = new GridData(16384, 16777216, false, false, 2, 1);
/*  73 */     gridData.verticalIndent = 5;
/*  74 */     gridData.heightHint = 30;
/*  75 */     thisOperationWillLabel.setLayoutData(gridData);
/*  76 */     thisOperationWillLabel
/*  77 */       .setText("This operation will zip the selected projects and place that zip file into the samples plugin\nwith the given chapter name in the specified category");
/*     */ 
/*  79 */     Label categoryNameLabel = new Label(container, 0);
/*  80 */     categoryNameLabel.setText("Category name:");
/*     */ 
/*  82 */     this.categoryNameField = new Text(container, 2048);
/*  83 */     this.categoryNameField.addModifyListener(new ModifyListener() {
/*     */       public void modifyText(ModifyEvent e) {
/*  85 */         ZipChaptersDialog.this.updateCategoryName();
/*  86 */         ZipChaptersDialog.this.updatePageComplete();
/*     */       }
/*     */     });
/*  89 */     this.categoryNameField.setLayoutData(new GridData(4, 16777216, true, false));
/*     */ 
/*  91 */     Label chapterNameLabel = new Label(container, 0);
/*  92 */     chapterNameLabel.setText("Chapter Name:");
/*     */ 
/*  94 */     this.chapterNameField = new Text(container, 2048);
/*  95 */     this.chapterNameField.addModifyListener(new ModifyListener() {
/*     */       public void modifyText(ModifyEvent e) {
/*  97 */         ZipChaptersDialog.this.updateChapterName();
/*  98 */         ZipChaptersDialog.this.updatePageComplete();
/*     */       }
/*     */     });
/* 101 */     this.chapterNameField.setLayoutData(new GridData(4, 16777216, true, false));
/*     */ 
/* 103 */     Label instructions = new Label(container, 0);
/* 104 */     instructions.setLayoutData(new GridData(16384, 16777216, false, false, 2, 1));
/* 105 */     instructions.setText("Select projects to be zipped:");
/*     */ 
/* 107 */     this.projectTableViewer = CheckboxTableViewer.newCheckList(container, 2048);
/* 108 */     this.projectTableViewer.setContentProvider(new ZipChaptersTableContentProvider());
/* 109 */     this.projectTableViewer.setLabelProvider(new ZipChaptersTableLabelProvider());
/* 110 */     this.projectTableViewer.setInput(new Object());
/* 111 */     this.table = this.projectTableViewer.getTable();
/* 112 */     this.table.addSelectionListener(new SelectionAdapter() {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 114 */         ZipChaptersDialog.this.updateSelectedProjects();
/* 115 */         ZipChaptersDialog.this.updatePageComplete();
/*     */       }
/*     */ 
/*     */       public void widgetDefaultSelected(SelectionEvent e) {
/* 119 */         widgetSelected(e);
/*     */       }
/*     */     });
/* 122 */     this.table.setLayoutData(new GridData(4, 4, true, true, 2, 1));
/*     */ 
/* 124 */     initContent();
/* 125 */     return container;
/*     */   }
/*     */ 
/*     */   protected void createButtonsForButtonBar(Composite parent)
/*     */   {
/* 134 */     this.okButton = createButton(parent, 0, IDialogConstants.OK_LABEL, true);
/* 135 */     createButton(parent, 1, IDialogConstants.CANCEL_LABEL, false);
/* 136 */     updatePageComplete();
/*     */   }
/*     */ 
/*     */   protected Point getInitialSize()
/*     */   {
/* 143 */     return new Point(500, 375);
/*     */   }
/*     */ 
/*     */   protected void configureShell(Shell newShell)
/*     */   {
/* 150 */     super.configureShell(newShell);
/* 151 */     newShell.setText("Zip Chapters");
/*     */   }
/*     */ 
/*     */   private void initContent() {
/* 155 */     updateCategoryNameField();
/* 156 */     updateChapterNameField();
/* 157 */     updateSelectedProjectsTable();
/*     */   }
/*     */ 
/*     */   private void updatePageComplete() {
/* 161 */     if ((this.okButton != null) && (!this.okButton.isDisposed()))
/* 162 */       this.okButton.setEnabled((this.categoryName.length() > 0) && (this.chapterName.length() > 0) && (this.selectedProjects.length > 0));
/*     */   }
/*     */ 
/*     */   public String getCategoryName()
/*     */   {
/* 172 */     return this.categoryName;
/*     */   }
/*     */ 
/*     */   public void setCategoryName(String categoryName) {
/* 176 */     this.categoryName = (categoryName != null ? categoryName : "");
/* 177 */     updateCategoryNameField();
/*     */   }
/*     */ 
/*     */   private void updateCategoryName() {
/* 181 */     this.categoryName = this.categoryNameField.getText().trim();
/*     */   }
/*     */ 
/*     */   private void updateCategoryNameField() {
/* 185 */     if ((this.categoryNameField != null) && (!this.categoryNameField.isDisposed()))
/* 186 */       this.categoryNameField.setText(this.categoryName);
/*     */   }
/*     */ 
/*     */   public String getChapterName()
/*     */   {
/* 192 */     return this.chapterName;
/*     */   }
/*     */ 
/*     */   public void setChapterName(String chapterName) {
/* 196 */     this.chapterName = (chapterName != null ? chapterName : "");
/* 197 */     updateChapterNameField();
/*     */   }
/*     */ 
/*     */   private void updateChapterName() {
/* 201 */     this.chapterName = this.chapterNameField.getText().trim();
/*     */   }
/*     */ 
/*     */   private void updateChapterNameField() {
/* 205 */     if ((this.chapterNameField != null) && (!this.chapterNameField.isDisposed()))
/* 206 */       this.chapterNameField.setText(this.chapterName);
/*     */   }
/*     */ 
/*     */   public IProject[] getSelectedProjects()
/*     */   {
/* 212 */     return this.selectedProjects;
/*     */   }
/*     */ 
/*     */   public void setSelectedProjects(IProject[] projects) {
/* 216 */     this.selectedProjects = (projects != null ? projects : NO_PROJECTS);
/* 217 */     updateSelectedProjectsTable();
/*     */   }
/*     */ 
/*     */   private void updateSelectedProjects() {
/* 221 */     Object[] checked = this.projectTableViewer.getCheckedElements();
/* 222 */     this.selectedProjects = new IProject[checked.length];
/* 223 */     System.arraycopy(checked, 0, this.selectedProjects, 0, checked.length);
/*     */   }
/*     */ 
/*     */   private void updateSelectedProjectsTable() {
/* 227 */     if ((this.projectTableViewer != null) && (!this.projectTableViewer.getControl().isDisposed()))
/* 228 */       this.projectTableViewer.setCheckedElements(this.selectedProjects);
/*     */   }
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.zip.ZipChaptersDialog
 * JD-Core Version:    0.6.2
 */