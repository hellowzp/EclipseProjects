/*     */ package org.eclipsercp.book.zip;
/*     */ 
/*     */ import com.instantiations.book.Activator;
/*     */ import com.instantiations.book.dialogs.ExceptionDetailsDialog;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.ILog;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.jface.action.Action;
/*     */ import org.eclipse.jface.dialogs.MessageDialog;
/*     */ import org.eclipsercp.book.tools.ISamplesManagerConstants;
/*     */ import org.eclipsercp.book.tools.SampleZipFile;
/*     */ import org.eclipsercp.book.tools.SamplesManagerView;
/*     */ import org.eclipsercp.book.tools.Utils;
/*     */ 
/*     */ public class ZipChaptersAction extends Action
/*     */ {
/*     */   private final SamplesManagerView view;
/*     */ 
/*     */   public ZipChaptersAction(SamplesManagerView view, String text)
/*     */   {
/*  46 */     super(text);
/*  47 */     this.view = view;
/*     */   }
/*     */ 
/*     */   private String getInitialCategoryName() {
/*  51 */     return this.view.getCategoryName();
/*     */   }
/*     */ 
/*     */   private String getInitialChapterName() {
/*  55 */     SampleZipFile sampleDir = this.view.getSelectedSample();
/*  56 */     if (sampleDir == null)
/*  57 */       return "";
/*  58 */     String chapterName = sampleDir.getZipFile().getName();
/*  59 */     if (chapterName.endsWith(".zip"))
/*  60 */       chapterName = chapterName.substring(0, chapterName.length() - 4);
/*  61 */     return chapterName;
/*     */   }
/*     */ 
/*     */   private IProject[] getInitiallySelectedProjects() {
/*  65 */     IProject[] projects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
/*  66 */     Collection selection = new ArrayList();
/*  67 */     for (int i = 0; i < projects.length; i++) {
/*  68 */       IProject project = projects[i];
/*  69 */       if (project.isAccessible())
/*     */       {
/*     */         try {
/*  72 */           if (project.getPersistentProperty(ISamplesManagerConstants.SAMPLES_KEY) != null);
/*     */         }
/*     */         catch (CoreException e)
/*     */         {
/*  76 */           Utils.logError("Failed to get persistent property " + ISamplesManagerConstants.SAMPLES_KEY + 
/*  77 */             " from project" + project.getName(), e);
/*     */         }
/*     */ 
/*  80 */         selection.add(project);
/*     */       }
/*     */     }
/*  82 */     IProject[] selectedProjects = (IProject[])selection.toArray(new IProject[selection.size()]);
/*  83 */     return selectedProjects;
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*  90 */     ZipChaptersDialog dialog = new ZipChaptersDialog(this.view.getShell());
/*  91 */     dialog.setCategoryName(getInitialCategoryName());
/*  92 */     dialog.setChapterName(getInitialChapterName());
/*  93 */     dialog.setSelectedProjects(getInitiallySelectedProjects());
/*  94 */     if (dialog.open() != 0)
/*  95 */       return;
/*  96 */     zipChapter(dialog.getCategoryName(), dialog.getChapterName(), dialog.getSelectedProjects());
/*     */   }
/*     */ 
/*     */   private void zipChapter(String categoryName, String chapterName, IProject[] selectedProjects)
/*     */   {
/* 109 */     File dir = new File(this.view.getSamplesDirectory(), categoryName);
/* 110 */     if ((!dir.exists()) && (!dir.mkdirs())) {
/* 111 */       handleError("Failed to create directory: " + dir.getPath(), null);
/* 112 */       return;
/*     */     }
/* 114 */     this.view.updateCategoryField();
/*     */ 
/* 117 */     File zipFile = new File(dir, chapterName + ".zip");
/* 118 */     if (zipFile.exists()) {
/* 119 */       if (!MessageDialog.openConfirm(this.view.getShell(), "Overwrite " + zipFile.getName(), 
/* 120 */         "Do you want to overwrite the existing file " + zipFile.getPath()))
/* 121 */         return;
/* 122 */       if (!zipFile.delete()) {
/* 123 */         handleError("Failed to rewrite zip: " + zipFile.getPath(), null);
/* 124 */         return;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 131 */       stream = new ZipOutputStream(new FileOutputStream(zipFile)); } catch (FileNotFoundException e) {
/*     */       ZipOutputStream stream;
/* 134 */       handleError("Failed to open stream: " + zipFile.getPath(), e);
/*     */       return;
/*     */     }
/*     */     ZipOutputStream stream;
/*     */     try {
/* 140 */       for (int i = 0; i < selectedProjects.length; i++)
/* 141 */         zipResource(stream, selectedProjects[i]);
/*     */     }
/*     */     catch (Exception e) {
/* 144 */       handleError("Failed to write stream: " + zipFile.getPath(), e);
/* 145 */       return;
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 151 */         stream.close();
/*     */       }
/*     */       catch (IOException e) {
/* 154 */         handleError("Failed to close stream: " + zipFile.getPath(), e);
/* 155 */         return;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void zipResource(ZipOutputStream stream, IResource res)
/*     */     throws IOException, CoreException
/*     */   {
/* 167 */     if (!shouldInclude(res)) {
/* 168 */       return;
/*     */     }
/*     */ 
/* 171 */     if ((res instanceof IFile)) {
/* 172 */       IFile file = (IFile)res;
/* 173 */       String name = file.getFullPath().toString();
/* 174 */       if (name.startsWith("/"))
/* 175 */         name = name.substring(1);
/* 176 */       ZipEntry entry = new ZipEntry(name);
/* 177 */       stream.putNextEntry(entry);
/* 178 */       byte[] buf = new byte[1024];
/* 179 */       InputStream input = file.getContents();
/*     */       try
/*     */       {
/* 182 */         int count = input.read(buf);
/* 183 */         if (count != -1)
/*     */         {
/* 185 */           stream.write(buf, 0, count);
/*     */         }
/*     */       }
/*     */       finally {
/* 189 */         input.close();
/*     */       }
/* 191 */       stream.closeEntry();
/* 192 */       return;
/*     */     }
/*     */ 
/* 196 */     IContainer container = (IContainer)res;
/* 197 */     IResource[] members = container.members();
/* 198 */     for (int i = 0; i < members.length; i++)
/* 199 */       zipResource(stream, members[i]);
/*     */   }
/*     */ 
/*     */   private boolean shouldInclude(IResource res)
/*     */   {
/* 209 */     if (res.isDerived())
/* 210 */       return false;
/* 211 */     String name = res.getName();
/* 212 */     String path = res.getFullPath().toString();
/* 213 */     if (name.equals(".gwt-log"))
/* 214 */       return false;
/* 215 */     if (name.equals(".google_apis"))
/* 216 */       return false;
/* 217 */     if (path.indexOf("/war/WEB-INF/lib/") > 0)
/* 218 */       return !name.equals("gwt-servlet.jar");
/* 219 */     if ((path.indexOf("/war/") > 0) && (name.endsWith(".gwt.rpc")))
/* 220 */       return false;
/* 221 */     return true;
/*     */   }
/*     */ 
/*     */   private void handleError(String message, Throwable ex)
/*     */   {
/* 231 */     Status status = new Status(4, "com.qualityeclipse.book", 0, message, ex);
/* 232 */     Activator.getDefault().getLog().log(status);
/* 233 */     ExceptionDetailsDialog dialog = new ExceptionDetailsDialog(this.view.getShell(), "Zip Projects Error", null, 
/* 234 */       message, ex);
/* 235 */     dialog.open();
/*     */   }
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     org.eclipsercp.book.zip.ZipChaptersAction
 * JD-Core Version:    0.6.2
 */