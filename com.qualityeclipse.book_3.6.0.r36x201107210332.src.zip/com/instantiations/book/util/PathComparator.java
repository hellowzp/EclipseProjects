/*    */ package com.instantiations.book.util;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ 
/*    */ public class PathComparator
/*    */   implements Comparator
/*    */ {
/*    */   public int compare(Object o1, Object o2)
/*    */   {
/* 14 */     return comparePath((IPath)o1, (IPath)o2);
/*    */   }
/*    */ 
/*    */   public int comparePath(IPath p1, IPath p2) {
/* 18 */     int count = Math.min(p1.segmentCount(), p2.segmentCount());
/* 19 */     for (int i = 0; i < count; i++) {
/* 20 */       int result = p1.segment(i).compareTo(p2.segment(i));
/* 21 */       if (result != 0)
/* 22 */         return result;
/*    */     }
/* 24 */     if (p1.segmentCount() > count)
/* 25 */       return 1;
/* 26 */     if (p2.segmentCount() > count)
/* 27 */       return -1;
/* 28 */     return 0;
/*    */   }
/*    */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     com.instantiations.book.util.PathComparator
 * JD-Core Version:    0.6.2
 */