/*     */ package com.instantiations.book.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ 
/*     */ public class ClasspathUtil
/*     */ {
/*     */   public static final String PLUGINS_DIRNAME = "plugins";
/*     */   public static final String JAR_FILE_EXTENSION = "jar";
/*  22 */   public static final IPath[] NO_PATHS = new IPath[0];
/*     */ 
/*     */   public static IPath resolvePath(IPath path)
/*     */   {
/*  31 */     if ((path == null) || (path.segmentCount() < 1))
/*  32 */       return null;
/*  33 */     IPath varPath = JavaCore.getClasspathVariable(path.segment(0));
/*  34 */     if (varPath == null) {
/*  35 */       return null;
/*     */     }
/*     */ 
/*  40 */     return varPath.append(path.removeFirstSegments(1));
/*     */   }
/*     */ 
/*     */   public static int indexOfSegment(IPath path, String segName)
/*     */   {
/*  51 */     int segIndex = path.segmentCount();
/*     */     do { if (path.segment(segIndex).equals(segName))
/*  53 */         return segIndex;
/*  51 */       segIndex--; } while (segIndex >= 0);
/*     */ 
/*  54 */     return -1;
/*     */   }
/*     */ 
/*     */   public static boolean isJarPlugin(IPath path)
/*     */   {
/*  65 */     return (path.segmentCount() >= 2) && 
/*  64 */       (path.segment(path.segmentCount() - 2).equalsIgnoreCase("plugins")) && 
/*  65 */       (path.getFileExtension().equalsIgnoreCase("jar"));
/*     */   }
/*     */ 
/*     */   public static IPath findSimilarPluginPath(IPath path, IPath resolvedPath)
/*     */   {
/*  80 */     int segIndex = indexOfSegment(path, "plugins");
/*  81 */     if ((segIndex < 0) || (segIndex >= path.segmentCount() - 1))
/*  82 */       return null;
/*  83 */     segIndex++;
/*     */ 
/*  86 */     int resolvedSegIndex = resolvedPath.segmentCount() - (path.segmentCount() - segIndex);
/*  87 */     IPath resolvedPrefix = resolvedPath.uptoSegment(resolvedSegIndex);
/*  88 */     File pluginsDir = resolvedPrefix.toFile();
/*  89 */     if (!pluginsDir.exists()) {
/*  90 */       return null;
/*     */     }
/*     */ 
/*  93 */     String segName = path.segment(segIndex);
/*  94 */     String segNamePrefix = segName.substring(0, segName.indexOf('_') + 1);
/*  95 */     if (segNamePrefix.length() == 0)
/*  96 */       return null;
/*  97 */     IPath childPath = resolvedPath.removeFirstSegments(resolvedSegIndex + 1);
/*     */ 
/* 100 */     String[] names = pluginsDir.list();
/* 101 */     Arrays.sort(names);
/* 102 */     int i = names.length;
/*     */     do { if (names[i].startsWith(segNamePrefix))
/*     */       {
/* 105 */         if (names[i].endsWith(".jar")) {
/* 106 */           return path.uptoSegment(segIndex).append(names[i]);
/*     */         }
/*     */ 
/* 109 */         if (resolvedPrefix.append(names[i]).append(childPath).toFile().exists())
/* 110 */           return path.uptoSegment(segIndex).append(names[i]).append(childPath);
/*     */       }
/* 102 */       i--; } while (i >= 0);
/*     */ 
/* 116 */     return null;
/*     */   }
/*     */ 
/*     */   public static IPath[] getSrcPathPrefixes()
/*     */   {
/* 124 */     Collection prefixes = new HashSet();
/* 125 */     String[] varNames = JavaCore.getClasspathVariableNames();
/*     */ 
/* 128 */     for (int i = 0; i < varNames.length; i++) {
/* 129 */       String eachVarName = varNames[i];
/* 130 */       IPath resolvedVarPath = JavaCore.getClasspathVariable(eachVarName);
/* 131 */       if ((resolvedVarPath != null) && (resolvedVarPath.segmentCount() >= 1))
/*     */       {
/* 133 */         if (resolvedVarPath.lastSegment().equals("src")) {
/* 134 */           prefixes.add(new Path(eachVarName));
/*     */         }
/*     */       }
/*     */     }
/* 138 */     for (int i = 0; i < varNames.length; i++) {
/* 139 */       String eachVarName = varNames[i];
/* 140 */       IPath resolvedVarPath = JavaCore.getClasspathVariable(eachVarName);
/* 141 */       if ((resolvedVarPath != null) && (resolvedVarPath.segmentCount() >= 1))
/*     */       {
/* 143 */         IPath pluginsPath = resolvedVarPath.append("plugins");
/* 144 */         File pluginsDir = pluginsPath.toFile();
/* 145 */         if (pluginsDir.exists())
/*     */         {
/* 147 */           String[] names = pluginsDir.list();
/* 148 */           for (int j = 0; j < names.length; j++) {
/* 149 */             String pluginDirName = names[j];
/*     */ 
/* 151 */             if (pluginDirName.endsWith(".jar"))
/* 152 */               pluginDirName = pluginDirName.substring(0, pluginDirName.length() - 4);
/* 153 */             IPath prefix = pluginsPath.append(pluginDirName).append("src");
/* 154 */             if (prefix.toFile().exists())
/* 155 */               prefixes.add(new Path(eachVarName).append("plugins").append(pluginDirName).append("src")); 
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 159 */     return (IPath[])prefixes.toArray(new IPath[prefixes.size()]);
/*     */   }
/*     */ 
/*     */   public static IPath[] getExpectedSrcPaths(IPath binPath, IPath[] srcPathPrefixes)
/*     */   {
/* 171 */     if ((binPath == null) || (binPath.segmentCount() < 3) || (!binPath.segment(binPath.segmentCount() - 1).endsWith(".jar"))) {
/* 172 */       return NO_PATHS;
/*     */     }
/*     */ 
/* 175 */     String binVarName = binPath.segment(0);
/*     */ 
/* 178 */     int segIndex = indexOfSegment(binPath, "plugins");
/* 179 */     if ((segIndex < 0) || (segIndex >= binPath.segmentCount() - 1)) {
/* 180 */       return NO_PATHS;
/*     */     }
/*     */ 
/* 183 */     ArrayList relPaths = new ArrayList();
/* 184 */     IPath eachRelPath = binPath.removeFirstSegments(segIndex + 1);
/*     */ 
/* 187 */     if (eachRelPath.segmentCount() == 1) {
/* 188 */       String pluginIdVer = eachRelPath.lastSegment();
/* 189 */       if (pluginIdVer.endsWith(".jar"))
/* 190 */         pluginIdVer = pluginIdVer.substring(0, pluginIdVer.length() - 4);
/* 191 */       relPaths.add(new Path(pluginIdVer).append("src.zip"));
/*     */     }
/*     */     else
/*     */     {
/* 195 */       String srcFileName1 = eachRelPath.lastSegment();
/* 196 */       srcFileName1 = srcFileName1.substring(0, srcFileName1.length() - 4) + "src.zip";
/* 197 */       eachRelPath = eachRelPath.removeLastSegments(1);
/*     */ 
/* 200 */       String srcFileName2 = eachRelPath.lastSegment();
/* 201 */       if ((srcFileName2.equals("runtime")) && (eachRelPath.segmentCount() > 1))
/* 202 */         srcFileName2 = eachRelPath.segment(eachRelPath.segmentCount() - 2);
/* 203 */       int charIndex = srcFileName2.lastIndexOf('_');
/* 204 */       if (charIndex != -1)
/* 205 */         srcFileName2 = srcFileName2.substring(0, charIndex);
/* 206 */       srcFileName2 = srcFileName2 + "-source.zip";
/*     */ 
/* 209 */       relPaths.add(eachRelPath.append(srcFileName1));
/* 210 */       relPaths.add(eachRelPath.append(srcFileName2));
/* 211 */       if (eachRelPath.lastSegment().equals("runtime")) {
/* 212 */         eachRelPath = eachRelPath.removeLastSegments(1);
/* 213 */         relPaths.add(eachRelPath.append(srcFileName1));
/* 214 */         relPaths.add(eachRelPath.append(srcFileName2));
/*     */       }
/* 216 */       relPaths.add(new Path(srcFileName1));
/* 217 */       relPaths.add(new Path(srcFileName2));
/*     */     }
/*     */ 
/* 221 */     ArrayList found = new ArrayList();
/* 222 */     int binVarNameCount = 0;
/* 223 */     for (int i = 0; i < srcPathPrefixes.length; i++) {
/* 224 */       IPath eachPrefix = srcPathPrefixes[i];
/* 225 */       IPath resolvedPrefix = resolvePath(eachPrefix);
/* 226 */       for (Iterator iter = relPaths.iterator(); iter.hasNext(); ) {
/* 227 */         eachRelPath = (IPath)iter.next();
/* 228 */         if (resolvedPrefix.append(eachRelPath).toFile().exists())
/*     */         {
/* 230 */           IPath eachPath = eachPrefix.append(eachRelPath);
/* 231 */           if (eachPath.segment(0).equals(binVarName))
/* 232 */             found.add(binVarNameCount++, eachPath);
/*     */           else {
/* 234 */             found.add(eachPath);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 239 */     return (IPath[])found.toArray(new IPath[found.size()]);
/*     */   }
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     com.instantiations.book.util.ClasspathUtil
 * JD-Core Version:    0.6.2
 */