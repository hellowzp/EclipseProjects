/*     */ package com.instantiations.book.dialogs;
/*     */ 
/*     */ import com.instantiations.book.Activator;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ public class ExceptionDetailsDialog extends AbstractDetailsDialog
/*     */ {
/*     */   private final Object details;
/*     */ 
/*     */   public ExceptionDetailsDialog(Shell parentShell, String title, Image image, String message, Object details)
/*     */   {
/*  41 */     super(parentShell, getTitle(title, details), getImage(image, details), getMessage(message, details));
/*     */ 
/*  43 */     this.details = details;
/*     */   }
/*     */ 
/*     */   protected Control createDetailsArea(Composite parent)
/*     */   {
/*  49 */     Composite panel = new Composite(parent, 0);
/*  50 */     panel.setLayoutData(new GridData(1808));
/*  51 */     GridLayout layout = new GridLayout();
/*  52 */     layout.marginHeight = 0;
/*  53 */     layout.marginWidth = 0;
/*  54 */     panel.setLayout(layout);
/*     */ 
/*  57 */     createProductInfoArea(panel);
/*  58 */     createDetailsViewer(panel);
/*     */ 
/*  60 */     return panel;
/*     */   }
/*     */ 
/*     */   protected Composite createProductInfoArea(Composite parent) {
/*  64 */     Composite composite = new Composite(parent, 0);
/*  65 */     composite.setLayoutData(new GridData());
/*  66 */     GridLayout layout = new GridLayout();
/*  67 */     layout.numColumns = 2;
/*  68 */     layout.marginWidth = convertHorizontalDLUsToPixels(7);
/*  69 */     composite.setLayout(layout);
/*     */ 
/*  71 */     new Label(composite, 0).setText("Provider:");
/*  72 */     new Label(composite, 0).setText("Quality Eclipse");
/*  73 */     new Label(composite, 0).setText("Plug-in Name:");
/*  74 */     new Label(composite, 0).setText(Activator.getDefault().getName());
/*  75 */     new Label(composite, 0).setText("Plug-in ID:");
/*  76 */     new Label(composite, 0).setText("com.qualityeclipse.book");
/*  77 */     new Label(composite, 0).setText("Version:");
/*  78 */     new Label(composite, 0).setText(Activator.getDefault().getVersion());
/*     */ 
/*  80 */     return composite;
/*     */   }
/*     */ 
/*     */   protected Control createDetailsViewer(Composite parent) {
/*  84 */     if (this.details == null) {
/*  85 */       return null;
/*     */     }
/*  87 */     Text text = new Text(parent, 2826);
/*  88 */     text.setLayoutData(new GridData(1808));
/*     */ 
/*  91 */     StringWriter writer = new StringWriter(1000);
/*  92 */     appendDetails(new PrintWriter(writer), this.details);
/*  93 */     text.setText(writer.toString());
/*     */ 
/*  95 */     return text;
/*     */   }
/*     */ 
/*     */   public static String getTitle(String title, Object details)
/*     */   {
/* 103 */     if (title != null)
/* 104 */       return title;
/* 105 */     if ((details instanceof Throwable)) {
/* 106 */       Throwable e = (Throwable)details;
/* 107 */       while ((e instanceof InvocationTargetException))
/* 108 */         e = ((InvocationTargetException)e).getTargetException();
/* 109 */       String name = e.getClass().getName();
/* 110 */       return name.substring(name.lastIndexOf('.') + 1);
/*     */     }
/* 112 */     return "Exception";
/*     */   }
/*     */ 
/*     */   public static Image getImage(Image image, Object details)
/*     */   {
/* 120 */     if (image != null)
/* 121 */       return image;
/* 122 */     Display display = Display.getDefault();
/* 123 */     if ((details instanceof IStatus))
/* 124 */       switch (((IStatus)details).getSeverity()) {
/*     */       case 4:
/* 126 */         return display.getSystemImage(1);
/*     */       case 2:
/* 128 */         return display.getSystemImage(8);
/*     */       case 1:
/* 130 */         return display.getSystemImage(2);
/*     */       case 0:
/* 132 */         return null;
/*     */       case 3:
/*     */       }
/* 135 */     return display.getSystemImage(1);
/*     */   }
/*     */ 
/*     */   public static String getMessage(String message, Object details)
/*     */   {
/* 143 */     if ((details instanceof Throwable)) {
/* 144 */       Throwable e = (Throwable)details;
/* 145 */       while ((e instanceof InvocationTargetException))
/* 146 */         e = ((InvocationTargetException)e).getTargetException();
/* 147 */       if (message == null)
/* 148 */         return e.toString();
/* 149 */       return MessageFormat.format(message, new Object[] { e.toString() });
/*     */     }
/* 151 */     if ((details instanceof IStatus)) {
/* 152 */       String statusMessage = ((IStatus)details).getMessage();
/* 153 */       if (message == null)
/* 154 */         return statusMessage;
/* 155 */       return MessageFormat.format(message, new Object[] { statusMessage });
/*     */     }
/* 157 */     if (message != null)
/* 158 */       return message;
/* 159 */     return "An Exception occurred.";
/*     */   }
/*     */ 
/*     */   public static void appendDetails(PrintWriter writer, Object details) {
/* 163 */     if ((details instanceof Throwable))
/* 164 */       appendException(writer, (Throwable)details);
/* 165 */     else if ((details instanceof IStatus))
/* 166 */       appendStatus(writer, (IStatus)details, 0);
/* 167 */     else if ((details instanceof Collection))
/* 168 */       appendList(writer, (Collection)details);
/* 169 */     else if (details != null)
/* 170 */       writer.println(details);
/*     */   }
/*     */ 
/*     */   private static void appendList(PrintWriter writer, Collection collection) {
/* 174 */     for (Iterator iter = collection.iterator(); iter.hasNext(); )
/* 175 */       appendDetails(writer, iter.next());
/*     */   }
/*     */ 
/*     */   public static void appendException(PrintWriter writer, Throwable ex) {
/* 179 */     if ((ex instanceof CoreException)) {
/* 180 */       appendStatus(writer, ((CoreException)ex).getStatus(), 0);
/* 181 */       writer.println();
/*     */     }
/* 183 */     appendStackTrace(writer, ex);
/* 184 */     if ((ex instanceof InvocationTargetException))
/* 185 */       appendException(writer, ((InvocationTargetException)ex).getTargetException());
/*     */   }
/*     */ 
/*     */   public static void appendStatus(PrintWriter writer, IStatus status, int nesting) {
/* 189 */     for (int i = 0; i < nesting; i++)
/* 190 */       writer.print("  ");
/* 191 */     writer.println(status.getMessage());
/* 192 */     IStatus[] children = status.getChildren();
/* 193 */     for (int i = 0; i < children.length; i++)
/* 194 */       appendStatus(writer, children[i], nesting + 1);
/*     */   }
/*     */ 
/*     */   public static void appendStackTrace(PrintWriter writer, Throwable ex) {
/* 198 */     ex.printStackTrace(writer);
/*     */   }
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     com.instantiations.book.dialogs.ExceptionDetailsDialog
 * JD-Core Version:    0.6.2
 */