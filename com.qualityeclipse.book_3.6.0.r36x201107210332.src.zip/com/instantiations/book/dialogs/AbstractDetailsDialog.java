/*     */ package com.instantiations.book.dialogs;
/*     */ 
/*     */ import org.eclipse.jface.dialogs.Dialog;
/*     */ import org.eclipse.jface.dialogs.IDialogConstants;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ public abstract class AbstractDetailsDialog extends Dialog
/*     */ {
/*     */   private final String title;
/*     */   private final String message;
/*     */   private final Image image;
/*     */   private Button detailsButton;
/*     */   private Control detailsArea;
/*     */   private Point cachedWindowSize;
/*     */ 
/*     */   public AbstractDetailsDialog(Shell parentShell, String title, Image image, String message)
/*     */   {
/*  38 */     super(parentShell);
/*     */ 
/*  40 */     this.title = title;
/*  41 */     this.image = image;
/*  42 */     this.message = message;
/*     */ 
/*  44 */     setShellStyle(
/*  45 */       67696);
/*     */   }
/*     */ 
/*     */   protected void buttonPressed(int id)
/*     */   {
/*  51 */     if (id == 13)
/*  52 */       toggleDetailsArea();
/*     */     else
/*  54 */       super.buttonPressed(id);
/*     */   }
/*     */ 
/*     */   protected void configureShell(Shell shell) {
/*  58 */     super.configureShell(shell);
/*  59 */     if (this.title != null)
/*  60 */       shell.setText(this.title);
/*     */   }
/*     */ 
/*     */   protected void createButtonsForButtonBar(Composite parent) {
/*  64 */     createButton(
/*  65 */       parent, 
/*  66 */       0, 
/*  67 */       IDialogConstants.OK_LABEL, 
/*  68 */       false);
/*  69 */     this.detailsButton = 
/*  70 */       createButton(
/*  71 */       parent, 
/*  72 */       13, 
/*  73 */       IDialogConstants.SHOW_DETAILS_LABEL, 
/*  74 */       false);
/*     */   }
/*     */ 
/*     */   protected Control createDialogArea(Composite parent) {
/*  78 */     Composite composite = 
/*  79 */       (Composite)super.createDialogArea(parent);
/*  80 */     composite.setLayoutData(
/*  81 */       new GridData(768));
/*     */ 
/*  83 */     if (this.image != null) {
/*  84 */       ((GridLayout)composite.getLayout()).numColumns = 
/*  85 */         2;
/*  86 */       Label label = new Label(composite, 0);
/*  87 */       this.image.setBackground(label.getBackground());
/*  88 */       label.setImage(this.image);
/*  89 */       label.setLayoutData(
/*  90 */         new GridData(
/*  91 */         66));
/*     */     }
/*     */ 
/*  95 */     Label label = new Label(composite, 64);
/*  96 */     if (this.message != null)
/*  97 */       label.setText(this.message);
/*  98 */     GridData data = 
/*  99 */       new GridData(
/* 100 */       772);
/*     */ 
/* 102 */     data.widthHint = 
/* 103 */       convertHorizontalDLUsToPixels(
/* 104 */       300);
/* 105 */     label.setLayoutData(data);
/* 106 */     label.setFont(parent.getFont());
/*     */ 
/* 108 */     return composite;
/*     */   }
/*     */ 
/*     */   protected void toggleDetailsArea()
/*     */   {
/* 116 */     Point oldWindowSize = getShell().getSize();
/* 117 */     Point newWindowSize = this.cachedWindowSize;
/* 118 */     this.cachedWindowSize = oldWindowSize;
/*     */ 
/* 121 */     if (this.detailsArea == null) {
/* 122 */       this.detailsArea = 
/* 123 */         createDetailsArea((Composite)getContents());
/* 124 */       this.detailsButton.setText(
/* 125 */         IDialogConstants.HIDE_DETAILS_LABEL);
/*     */     }
/*     */     else
/*     */     {
/* 130 */       this.detailsArea.dispose();
/* 131 */       this.detailsArea = null;
/* 132 */       this.detailsButton.setText(
/* 133 */         IDialogConstants.SHOW_DETAILS_LABEL);
/*     */     }
/*     */ 
/* 145 */     Point oldSize = getContents().getSize();
/* 146 */     Point newSize = 
/* 147 */       getContents().computeSize(
/* 148 */       -1, 
/* 149 */       -1);
/* 150 */     if (newWindowSize == null) {
/* 151 */       newWindowSize = 
/* 152 */         new Point(
/* 153 */         oldWindowSize.x, 
/* 154 */         oldWindowSize.y + (newSize.y - oldSize.y));
/*     */     }
/*     */ 
/* 157 */     Point windowLoc = getShell().getLocation();
/* 158 */     Rectangle screenArea = 
/* 159 */       getContents().getDisplay().getClientArea();
/*     */ 
/* 161 */     if (newWindowSize.y > 
/* 161 */       screenArea.height - (windowLoc.y - screenArea.y)) {
/* 162 */       newWindowSize.y = 
/* 163 */         (screenArea.height - (
/* 164 */         windowLoc.y - screenArea.y));
/*     */     }
/* 166 */     getShell().setSize(newWindowSize);
/* 167 */     ((Composite)getContents()).layout();
/*     */   }
/*     */ 
/*     */   protected abstract Control createDetailsArea(Composite paramComposite);
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     com.instantiations.book.dialogs.AbstractDetailsDialog
 * JD-Core Version:    0.6.2
 */