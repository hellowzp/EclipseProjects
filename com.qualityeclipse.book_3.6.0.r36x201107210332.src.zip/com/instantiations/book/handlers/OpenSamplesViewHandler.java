/*    */ package com.instantiations.book.handlers;
/*    */ 
/*    */ import org.eclipse.core.commands.AbstractHandler;
/*    */ import org.eclipse.core.commands.ExecutionEvent;
/*    */ import org.eclipse.core.commands.ExecutionException;
/*    */ import org.eclipse.jface.dialogs.MessageDialog;
/*    */ import org.eclipse.ui.IWorkbenchPage;
/*    */ import org.eclipse.ui.IWorkbenchWindow;
/*    */ import org.eclipse.ui.PartInitException;
/*    */ import org.eclipse.ui.handlers.HandlerUtil;
/*    */ import org.eclipsercp.book.tools.SamplesManagerView;
/*    */ 
/*    */ public class OpenSamplesViewHandler extends AbstractHandler
/*    */ {
/*    */   public Object execute(ExecutionEvent event)
/*    */     throws ExecutionException
/*    */   {
/* 17 */     IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindow(event);
/*    */     try
/*    */     {
/* 23 */       window.getActivePage().showView(SamplesManagerView.ID);
/*    */     }
/*    */     catch (PartInitException e) {
/* 26 */       MessageDialog.openError(window.getShell(), "Error", "Error opening the QualityEclipse Book Samples view. " + 
/* 27 */         e.getMessage());
/*    */     }
/* 29 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     com.instantiations.book.handlers.OpenSamplesViewHandler
 * JD-Core Version:    0.6.2
 */