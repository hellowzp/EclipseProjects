/*    */ package com.instantiations.book;
/*    */ 
/*    */ import org.eclipse.core.resources.ResourcesPlugin;
/*    */ import org.eclipse.core.runtime.ILog;
/*    */ import org.eclipse.core.runtime.IStatus;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ 
/*    */ public class BookLog
/*    */ {
/*    */   public static void logInfo(String message)
/*    */   {
/* 19 */     log(1, 0, message, null);
/*    */   }
/*    */ 
/*    */   public static void logError(Throwable exception)
/*    */   {
/* 29 */     logError("Unexpected Exception", exception);
/*    */   }
/*    */ 
/*    */   public static void logError(String message, Throwable exception)
/*    */   {
/* 42 */     log(4, 0, message, exception);
/*    */   }
/*    */ 
/*    */   public static void log(int severity, int code, String message, Throwable exception)
/*    */   {
/* 63 */     log(createStatus(severity, code, message, exception));
/*    */   }
/*    */ 
/*    */   public static IStatus createStatus(int severity, int code, String message, Throwable exception)
/*    */   {
/* 85 */     return new Status(severity, "com.qualityeclipse.book", code, message, exception);
/*    */   }
/*    */ 
/*    */   public static void log(IStatus status)
/*    */   {
/* 95 */     ResourcesPlugin.getPlugin().getLog().log(status);
/*    */   }
/*    */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     com.instantiations.book.BookLog
 * JD-Core Version:    0.6.2
 */