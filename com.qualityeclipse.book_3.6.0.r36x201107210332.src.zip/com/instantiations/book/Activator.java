/*    */ package com.instantiations.book;
/*    */ 
/*    */ import java.util.Dictionary;
/*    */ import org.eclipse.core.runtime.Platform;
/*    */ import org.eclipse.ui.plugin.AbstractUIPlugin;
/*    */ import org.osgi.framework.Bundle;
/*    */ import org.osgi.framework.BundleContext;
/*    */ 
/*    */ public class Activator extends AbstractUIPlugin
/*    */ {
/*    */   public static final String PLUGIN_ID = "com.qualityeclipse.book";
/*    */   private static Activator plugin;
/*    */ 
/*    */   public void start(BundleContext context)
/*    */     throws Exception
/*    */   {
/* 29 */     super.start(context);
/* 30 */     plugin = this;
/*    */   }
/*    */ 
/*    */   public void stop(BundleContext context)
/*    */     throws Exception
/*    */   {
/* 38 */     plugin = null;
/* 39 */     super.stop(context);
/*    */   }
/*    */ 
/*    */   public static Activator getDefault()
/*    */   {
/* 48 */     return plugin;
/*    */   }
/*    */ 
/*    */   public String getName() {
/*    */     try {
/* 53 */       return (String)Platform.getBundle("com.qualityeclipse.book").getHeaders().get("Bundle-Name");
/*    */     } catch (Exception e) {
/*    */     }
/* 56 */     return "???";
/*    */   }
/*    */ 
/*    */   public String getVersion()
/*    */   {
/*    */     try {
/* 62 */       return (String)Platform.getBundle("com.qualityeclipse.book").getHeaders().get("Bundle-Version");
/*    */     } catch (Exception e) {
/*    */     }
/* 65 */     return "???";
/*    */   }
/*    */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     com.instantiations.book.Activator
 * JD-Core Version:    0.6.2
 */