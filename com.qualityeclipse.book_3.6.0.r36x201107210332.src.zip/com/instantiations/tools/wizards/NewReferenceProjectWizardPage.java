/*     */ package com.instantiations.tools.wizards;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jface.viewers.ISelection;
/*     */ import org.eclipse.jface.wizard.WizardPage;
/*     */ import org.eclipse.swt.events.ModifyEvent;
/*     */ import org.eclipse.swt.events.ModifyListener;
/*     */ import org.eclipse.swt.events.MouseAdapter;
/*     */ import org.eclipse.swt.events.MouseEvent;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.List;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ public class NewReferenceProjectWizardPage extends WizardPage
/*     */ {
/*     */   private static final String ECLIPSE_HOME = "ECLIPSE_HOME";
/*     */   private List classPathVarList;
/*     */   private Text nameField;
/*     */   private String selectedVarName;
/*  36 */   private boolean includeCom = false;
/*  37 */   private boolean includeSrcRefs = true;
/*     */ 
/*     */   public NewReferenceProjectWizardPage(ISelection selection)
/*     */   {
/*  44 */     super("wizardPage");
/*  45 */     setTitle("New Reference Project");
/*  46 */     setDescription("This wizard creates a new reference project.");
/*     */   }
/*     */ 
/*     */   public void createControl(Composite parent)
/*     */   {
/*  54 */     Composite container = new Composite(parent, 0);
/*  55 */     GridLayout layout = new GridLayout();
/*  56 */     layout.numColumns = 3;
/*  57 */     container.setLayout(layout);
/*     */ 
/*  59 */     Label selectLabel = new Label(container, 0);
/*  60 */     GridData gridData_2 = new GridData();
/*  61 */     gridData_2.horizontalSpan = 2;
/*  62 */     selectLabel.setLayoutData(gridData_2);
/*  63 */     selectLabel.setText("Select the classpath variable pointing to the Eclipse installation to be referenced:");
/*     */ 
/*  65 */     Label includeComLabel = new Label(container, 0);
/*  66 */     includeComLabel.addMouseListener(new MouseAdapter() { private final Label val$includeComLabel;
/*     */ 
/*  68 */       public void mouseDoubleClick(MouseEvent e) { NewReferenceProjectWizardPage.this.includeCom = (!NewReferenceProjectWizardPage.this.includeCom);
/*  69 */         if (NewReferenceProjectWizardPage.this.includeCom)
/*  70 */           this.val$includeComLabel.setText("com");
/*     */         else
/*  72 */           this.val$includeComLabel.setText("           ");
/*     */       }
/*     */     });
/*  75 */     includeComLabel.setText("           ");
/*  76 */     includeComLabel.setLayoutData(new GridData(128));
/*     */ 
/*  78 */     this.classPathVarList = new List(container, 2048);
/*  79 */     this.classPathVarList.addSelectionListener(new SelectionAdapter() {
/*     */       public void widgetSelected(SelectionEvent e) {
/*  81 */         NewReferenceProjectWizardPage.this.updatePageComplete();
/*     */       }
/*     */     });
/*  84 */     GridData gridData_1 = new GridData(1808);
/*  85 */     gridData_1.horizontalSpan = 3;
/*  86 */     this.classPathVarList.setLayoutData(gridData_1);
/*     */ 
/*  88 */     Label nameLabel = new Label(container, 0);
/*  89 */     nameLabel.setLayoutData(new GridData(128));
/*  90 */     nameLabel.setText("Project Name:");
/*     */ 
/*  92 */     this.nameField = new Text(container, 2048);
/*  93 */     this.nameField.addModifyListener(new ModifyListener() {
/*     */       public void modifyText(ModifyEvent e) {
/*  95 */         NewReferenceProjectWizardPage.this.updatePageComplete();
/*     */       }
/*     */     });
/*  98 */     this.nameField.setToolTipText("Enter the name of the new project");
/*  99 */     GridData gridData = new GridData(768);
/* 100 */     gridData.horizontalSpan = 2;
/* 101 */     this.nameField.setLayoutData(gridData);
/*     */ 
/* 103 */     Button includeSrcRefsCheckbox = new Button(container, 32);
/* 104 */     includeSrcRefsCheckbox.addSelectionListener(new SelectionAdapter() { private final Button val$includeSrcRefsCheckbox;
/*     */ 
/* 106 */       public void widgetSelected(SelectionEvent e) { NewReferenceProjectWizardPage.this.includeSrcRefs = this.val$includeSrcRefsCheckbox.getSelection(); }
/*     */ 
/*     */     });
/* 109 */     includeSrcRefsCheckbox.setSelection(true);
/* 110 */     GridData gridData_3 = new GridData(128);
/* 111 */     gridData_3.horizontalSpan = 3;
/* 112 */     includeSrcRefsCheckbox.setLayoutData(gridData_3);
/* 113 */     includeSrcRefsCheckbox.setText("include souce code references where possible");
/*     */ 
/* 115 */     initContents();
/* 116 */     updatePageComplete();
/* 117 */     setControl(container);
/*     */   }
/*     */ 
/*     */   private void initContents()
/*     */   {
/* 125 */     String[] varNames = JavaCore.getClasspathVariableNames();
/* 126 */     Arrays.sort(varNames);
/* 127 */     this.classPathVarList.setItems(varNames);
/* 128 */     int index = this.classPathVarList.indexOf("ECLIPSE_HOME");
/* 129 */     if (index >= 0)
/* 130 */       this.classPathVarList.select(index);
/* 131 */     this.nameField.setText(newProjectName());
/*     */   }
/*     */ 
/*     */   private String newProjectName()
/*     */   {
/* 139 */     String baseName = "Reference";
/* 140 */     if (getProjectNamed(baseName) == null)
/* 141 */       return baseName;
/* 142 */     int index = 1;
/*     */     while (true) {
/* 144 */       String name = baseName + index;
/* 145 */       if (getProjectNamed(name) == null)
/* 146 */         return name;
/* 147 */       index++;
/*     */     }
/*     */   }
/*     */ 
/*     */   private Object getProjectNamed(String name)
/*     */   {
/* 158 */     IProject[] projects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
/* 159 */     for (int i = 0; i < projects.length; i++)
/* 160 */       if (projects[i].getName().equals(name))
/* 161 */         return projects[i];
/* 162 */     return null;
/*     */   }
/*     */ 
/*     */   private void updatePageComplete()
/*     */   {
/* 170 */     String errMsg = validateContent();
/* 171 */     setErrorMessage(errMsg);
/* 172 */     setPageComplete(errMsg == null);
/*     */   }
/*     */ 
/*     */   private String validateContent()
/*     */   {
/* 182 */     String text = getProjectName();
/* 183 */     if (text.length() == 0)
/* 184 */       return "Enter the name of the reference project to be created";
/* 185 */     if (getProjectNamed(text) != null) {
/* 186 */       return "Project named " + text + " already exists";
/*     */     }
/* 188 */     String varName = getClasspathVariable();
/* 189 */     if (varName == null)
/* 190 */       return "Select one classpath variable pointing to the Eclipse installation to be referenced.";
/* 191 */     if (!varName.equals(this.selectedVarName)) {
/* 192 */       this.selectedVarName = varName;
/* 193 */       IPath varPath = JavaCore.getClasspathVariable(this.selectedVarName);
/* 194 */       if (!varPath.append("plugins").toFile().exists()) {
/* 195 */         return "Cannot find plugins directory in " + varPath;
/*     */       }
/*     */     }
/* 198 */     return null;
/*     */   }
/*     */ 
/*     */   public String getProjectName() {
/* 202 */     return this.nameField.getText().trim();
/*     */   }
/*     */ 
/*     */   public String getClasspathVariable() {
/* 206 */     String[] varNames = this.classPathVarList.getSelection();
/* 207 */     if ((varNames == null) || (varNames.length != 1))
/* 208 */       return null;
/* 209 */     return varNames[0];
/*     */   }
/*     */ 
/*     */   public boolean getIncludeCom() {
/* 213 */     return this.includeCom;
/*     */   }
/*     */ 
/*     */   public boolean getIncludeSrcRefs() {
/* 217 */     return this.includeSrcRefs;
/*     */   }
/*     */ 
/*     */   public void setVisible(boolean visible) {
/* 221 */     if (visible) {
/* 222 */       getShell().getDisplay().asyncExec(new Runnable() {
/*     */         public void run() {
/* 224 */           NewReferenceProjectWizardPage.this.classPathVarList.setFocus();
/*     */         }
/*     */       });
/*     */     }
/* 228 */     super.setVisible(visible);
/*     */   }
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     com.instantiations.tools.wizards.NewReferenceProjectWizardPage
 * JD-Core Version:    0.6.2
 */