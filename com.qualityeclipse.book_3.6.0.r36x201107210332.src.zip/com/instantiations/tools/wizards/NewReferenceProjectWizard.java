/*     */ package com.instantiations.tools.wizards;
/*     */ 
/*     */ import com.instantiations.book.BookLog;
/*     */ import com.instantiations.book.dialogs.ExceptionDetailsDialog;
/*     */ import com.instantiations.book.util.ClasspathUtil;
/*     */ import com.instantiations.book.util.PathComparator;
/*     */ import java.io.File;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.TreeSet;
/*     */ import org.eclipse.core.resources.IFolder;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IProjectDescription;
/*     */ import org.eclipse.core.resources.IProjectNature;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.SubProgressMonitor;
/*     */ import org.eclipse.jdt.core.IClasspathEntry;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jface.viewers.ISelection;
/*     */ import org.eclipse.jface.viewers.IStructuredSelection;
/*     */ import org.eclipse.jface.wizard.IWizardContainer;
/*     */ import org.eclipse.jface.wizard.Wizard;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.ui.INewWizard;
/*     */ import org.eclipse.ui.IWorkbench;
/*     */ import org.eclipse.ui.actions.WorkspaceModifyOperation;
/*     */ 
/*     */ public class NewReferenceProjectWizard extends Wizard
/*     */   implements INewWizard
/*     */ {
/*     */   private NewReferenceProjectWizardPage page;
/*     */   private ISelection selection;
/*     */ 
/*     */   public NewReferenceProjectWizard()
/*     */   {
/*  51 */     setNeedsProgressMonitor(true);
/*     */   }
/*     */ 
/*     */   public void init(IWorkbench workbench, IStructuredSelection selection) {
/*  55 */     this.selection = selection;
/*     */   }
/*     */ 
/*     */   public void addPages() {
/*  59 */     this.page = new NewReferenceProjectWizardPage(this.selection);
/*  60 */     addPage(this.page);
/*     */   }
/*     */ 
/*     */   public boolean performFinish()
/*     */   {
/*  68 */     String varName = this.page.getClasspathVariable();
/*  69 */     String projName = this.page.getProjectName();
/*     */     try {
/*  71 */       getContainer().run(true, false, new WorkspaceModifyOperation() { private final String val$varName;
/*     */         private final String val$projName;
/*     */ 
/*  73 */         protected void execute(IProgressMonitor monitor) throws CoreException, InvocationTargetException, InterruptedException { NewReferenceProjectWizard.this.doFinish(this.val$varName, this.val$projName, monitor); }
/*     */       });
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/*  78 */       return false;
/*     */     }
/*     */     catch (InvocationTargetException e) {
/*  81 */       Throwable realException = e.getTargetException();
/*  82 */       BookLog.logError(realException);
/*  83 */       ExceptionDetailsDialog dialog = new ExceptionDetailsDialog(
/*  84 */         getShell(), 
/*  85 */         "Creation Failure", 
/*  86 */         getShell().getDisplay().getSystemImage(1), 
/*  87 */         "Failed to create reference project", 
/*  88 */         realException);
/*  89 */       dialog.open();
/*  90 */       return false;
/*     */     }
/*  92 */     return true;
/*     */   }
/*     */ 
/*     */   private void doFinish(String varName, String projName, IProgressMonitor monitor)
/*     */     throws CoreException
/*     */   {
/* 101 */     monitor.beginTask("Creating Reference Project", 8);
/* 102 */     IProject proj = createProject(projName, new SubProgressMonitor(monitor, 1));
/* 103 */     proj.open(new SubProgressMonitor(monitor, 1));
/* 104 */     IJavaProject javaProj = addJavaNature(proj, new SubProgressMonitor(monitor, 1));
/* 105 */     addPlugins(javaProj, new Path(varName).append("plugins"), new SubProgressMonitor(monitor, 5));
/* 106 */     monitor.done();
/*     */   }
/*     */ 
/*     */   private void addPlugins(IJavaProject javaProj, IPath pluginDirPath, IProgressMonitor monitor)
/*     */     throws JavaModelException
/*     */   {
/* 115 */     IPath resolvedPluginDirPath = JavaCore.getResolvedVariablePath(pluginDirPath);
/* 116 */     if (resolvedPluginDirPath == null) {
/* 117 */       BookLog.logInfo("Failed to resolve " + pluginDirPath);
/* 118 */       return;
/*     */     }
/* 120 */     monitor.beginTask("Adding Plug-ins", 3);
/* 121 */     Collection jarPaths = findPluginJarPaths(resolvedPluginDirPath, new SubProgressMonitor(monitor, 1));
/* 122 */     IClasspathEntry[] classpathEntries = appendClasspathEntries(
/* 123 */       javaProj.getRawClasspath(), 
/* 124 */       pluginDirPath, 
/* 125 */       resolvedPluginDirPath, 
/* 126 */       jarPaths, 
/* 127 */       new SubProgressMonitor(monitor, 1));
/* 128 */     javaProj.setRawClasspath(classpathEntries, new SubProgressMonitor(monitor, 1));
/* 129 */     monitor.done();
/*     */   }
/*     */ 
/*     */   private Collection findPluginJarPaths(IPath resolvedPath, IProgressMonitor monitor)
/*     */   {
/* 139 */     Collection jarPaths = new HashSet();
/* 140 */     File dir = resolvedPath.toFile();
/* 141 */     if (!dir.isDirectory()) {
/* 142 */       BookLog.logInfo("No jars in " + resolvedPath);
/* 143 */       return jarPaths;
/*     */     }
/* 145 */     boolean includeCom = this.page.getIncludeCom();
/* 146 */     String[] pluginDirNames = dir.list();
/* 147 */     monitor.beginTask("Scanning " + resolvedPath + " for jars", pluginDirNames.length);
/* 148 */     for (int i = 0; i < pluginDirNames.length; i++) {
/* 149 */       monitor.worked(1);
/* 150 */       String eachName = pluginDirNames[i];
/* 151 */       if ((includeCom) || (!eachName.startsWith("com.")))
/*     */       {
/* 154 */         IPath resolvedPluginPath = resolvedPath.append(eachName);
/* 155 */         if (eachName.endsWith(".jar"))
/* 156 */           jarPaths.add(resolvedPluginPath);
/*     */         else
/* 158 */           findJarPaths(resolvedPluginPath, jarPaths); 
/*     */       }
/*     */     }
/* 160 */     monitor.done();
/* 161 */     return jarPaths;
/*     */   }
/*     */ 
/*     */   private void findJarPaths(IPath path, Collection jarPaths)
/*     */   {
/* 170 */     File dir = path.toFile();
/* 171 */     if (!dir.isDirectory())
/* 172 */       return;
/* 173 */     String[] names = dir.list();
/* 174 */     for (int i = 0; i < names.length; i++) {
/* 175 */       String eachName = names[i];
/* 176 */       IPath subPath = path.append(eachName);
/* 177 */       if (eachName.endsWith(".jar"))
/* 178 */         jarPaths.add(subPath);
/*     */       else
/* 180 */         findJarPaths(subPath, jarPaths);
/*     */     }
/*     */   }
/*     */ 
/*     */   private IClasspathEntry[] appendClasspathEntries(IClasspathEntry[] oldEntries, IPath pluginDirPath, IPath resolvedPluginDirPath, Collection jarPaths, IProgressMonitor monitor)
/*     */   {
/* 193 */     IPath[] srcPathPrefixes = ClasspathUtil.getSrcPathPrefixes();
/*     */ 
/* 195 */     Collection newEntries = new ArrayList(oldEntries.length + jarPaths.size());
/* 196 */     newEntries.addAll(Arrays.asList(oldEntries));
/* 197 */     Collection sortedJarPaths = new TreeSet(new PathComparator());
/* 198 */     sortedJarPaths.addAll(jarPaths);
/*     */ 
/* 200 */     monitor.beginTask("Building claspath", sortedJarPaths.size());
/* 201 */     for (Iterator iter = sortedJarPaths.iterator(); iter.hasNext(); )
/*     */     {
/* 204 */       IPath resolvedJarPath = (IPath)iter.next();
/* 205 */       IPath jarPath = pluginDirPath.append(resolvedJarPath.removeFirstSegments(resolvedPluginDirPath.segmentCount()));
/*     */ 
/* 208 */       IPath srcPath = null;
/* 209 */       if (this.page.getIncludeSrcRefs()) {
/* 210 */         IPath[] expectedSrcPaths = ClasspathUtil.getExpectedSrcPaths(jarPath, srcPathPrefixes);
/* 211 */         if (expectedSrcPaths.length > 0) {
/* 212 */           srcPath = expectedSrcPaths[0];
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 219 */       IPath srcRoot = null;
/* 220 */       if ((srcPath != null) && (srcPath.lastSegment().endsWith("-source.zip"))) {
/* 221 */         String pluginId = srcPath.lastSegment();
/* 222 */         pluginId = pluginId.substring(0, pluginId.length() - 11);
/* 223 */         srcRoot = new Path("_COM_IBM_ETOOLS_SRCROOT").append(pluginId).append("src");
/*     */       }
/*     */ 
/* 226 */       IClasspathEntry newEntry = JavaCore.newVariableEntry(jarPath, srcPath, srcRoot);
/* 227 */       newEntries.add(newEntry);
/* 228 */       monitor.worked(1);
/*     */     }
/* 230 */     IClasspathEntry[] classpathEntries = (IClasspathEntry[])newEntries.toArray(new IClasspathEntry[newEntries.size()]);
/* 231 */     monitor.done();
/* 232 */     return classpathEntries;
/*     */   }
/*     */ 
/*     */   private IProject createProject(String name, IProgressMonitor monitor)
/*     */     throws CoreException
/*     */   {
/* 241 */     IWorkspace workspace = ResourcesPlugin.getWorkspace();
/* 242 */     IProjectDescription description = workspace.newProjectDescription(name);
/* 243 */     description.setNatureIds(new String[] { "org.eclipse.jdt.core.javanature" });
/* 244 */     IProject proj = workspace.getRoot().getProject(name);
/* 245 */     proj.create(description, monitor);
/* 246 */     return proj;
/*     */   }
/*     */ 
/*     */   private IJavaProject addJavaNature(IProject proj, SubProgressMonitor monitor)
/*     */     throws CoreException
/*     */   {
/* 254 */     monitor.beginTask("Adding Java Nature", 4);
/*     */ 
/* 257 */     IFolder srcDir = proj.getFolder("src");
/* 258 */     IFolder binDir = proj.getFolder("bin");
/* 259 */     if (!srcDir.exists())
/* 260 */       srcDir.create(false, true, new SubProgressMonitor(monitor, 1));
/* 261 */     if (!binDir.exists()) {
/* 262 */       binDir.create(false, true, new SubProgressMonitor(monitor, 1));
/*     */     }
/*     */ 
/* 265 */     addNature(proj, "org.eclipse.jdt.core.javanature", new SubProgressMonitor(monitor, 1));
/*     */ 
/* 268 */     IJavaProject javaProj = JavaCore.create(proj);
/* 269 */     javaProj.setRawClasspath(
/* 270 */       new IClasspathEntry[] { 
/* 271 */       JavaCore.newVariableEntry(new Path("JRE_LIB"), null, null), 
/* 272 */       JavaCore.newSourceEntry(srcDir.getFullPath()) }, 
/* 274 */       binDir.getFullPath(), 
/* 275 */       new SubProgressMonitor(monitor, 1));
/* 276 */     return javaProj;
/*     */   }
/*     */ 
/*     */   private void addNature(IProject proj, String natureId, IProgressMonitor monitor)
/*     */     throws CoreException
/*     */   {
/* 284 */     IProjectDescription description = proj.getDescription();
/* 285 */     List newNatures = new ArrayList();
/* 286 */     newNatures.addAll(Arrays.asList(description.getNatureIds()));
/* 287 */     newNatures.add(natureId);
/* 288 */     description.setNatureIds((String[])newNatures.toArray(new String[newNatures.size()]));
/* 289 */     proj.setDescription(description, monitor);
/* 290 */     proj.getNature(natureId).configure();
/*     */   }
/*     */ }

/* Location:           D:\my_documents\engineering_files\eclipse\eclipse_plugins\plugins\com.qualityeclipse.book_3.6.0.r36x201107210332.jar
 * Qualified Name:     com.instantiations.tools.wizards.NewReferenceProjectWizard
 * JD-Core Version:    0.6.2
 */